package com.alidinler.masaustu;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ComponentName;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Environment;
import android.os.Looper;
import android.os.Message;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.text.InputType;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebStorage;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.mozilla.geckoview.AllowOrDeny;
import org.mozilla.geckoview.BasicSelectionActionDelegate;
import org.mozilla.geckoview.ContentBlocking;
import org.mozilla.geckoview.GeckoResult;
import org.mozilla.geckoview.GeckoRuntime;
import org.mozilla.geckoview.GeckoRuntimeSettings;
import org.mozilla.geckoview.GeckoSession;
import org.mozilla.geckoview.GeckoSession.PromptDelegate.AlertPrompt;
import org.mozilla.geckoview.GeckoSession.PromptDelegate.AuthPrompt;
import org.mozilla.geckoview.GeckoSession.PromptDelegate.ButtonPrompt;
import org.mozilla.geckoview.GeckoSession.PromptDelegate.ChoicePrompt;
import org.mozilla.geckoview.GeckoSession.PromptDelegate.FilePrompt;
import org.mozilla.geckoview.GeckoSession.PromptDelegate.PromptResponse;
import org.mozilla.geckoview.GeckoSession.PromptDelegate.TextPrompt;
import org.mozilla.geckoview.GeckoSessionSettings;
import org.mozilla.geckoview.GeckoView;
import org.mozilla.geckoview.GeckoWebExecutor;
import org.mozilla.geckoview.StorageController;
import org.mozilla.geckoview.WebExtension;
import org.mozilla.geckoview.WebExtensionController;
import org.mozilla.geckoview.WebRequest;
import org.mozilla.geckoview.WebRequestError;
import org.mozilla.geckoview.WebResponse;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.regex.Pattern;

public class MainActivity extends Activity {

    static final int REQ_FILE = 11, REQ_BG = 12, REQ_FILE_WEB = 13;
    static final String CHROME_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
            + "(KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36";
    static final String HIDE_JS =
            "(function(){if(document.getElementById('__md_ab'))return;"
            + "var s=document.createElement('style');s.id='__md_ab';"
            + "s.textContent='ins.adsbygoogle,.adsbygoogle,[id^=\\\"div-gpt-ad\\\"],[id^=\\\"google_ads_iframe\\\"],"
            + "iframe[src*=\\\"doubleclick.net\\\"],iframe[src*=\\\"googlesyndication\\\"],[id^=\\\"taboola-\\\"],"
            + ".trc_rbox_container,.OUTBRAIN{display:none!important}';"
            + "(document.head||document.documentElement).appendChild(s);})();";
    static final HashSet<String> AD_HOSTS = new HashSet<>();

    static final int C_BAR = 0xFF1C1C1F, C_TOOL = 0xFF2B2B30, C_FIELD = 0xFF3B3B42,
            C_TEXT = 0xFFEDEDF0, C_DIM = 0xFF9C9CA5, C_ACCENT = 0xFFFFCC00;
    static final int[] TILE_COLORS = {0xFFE8453C, 0xFFF4A100, 0xFF1E88E5, 0xFF43A047, 0xFF8E24AA,
            0xFF00897B, 0xFFF4511E, 0xFF3949AB, 0xFFD81B60, 0xFF6D4C41};

    static final String DEFAULT_TILES = "["
            + "{\"t\":\"Google\",\"u\":\"https://www.google.com\"},"
            + "{\"t\":\"YouTube\",\"u\":\"https://www.youtube.com\"},"
            + "{\"t\":\"TradingView\",\"u\":\"https://www.tradingview.com\"},"
            + "{\"t\":\"Vikipedi\",\"u\":\"https://tr.wikipedia.org\"},"
            + "{\"t\":\"Yandex\",\"u\":\"https://yandex.com.tr\"},"
            + "{\"t\":\"GitHub\",\"u\":\"https://github.com\"},"
            + "{\"t\":\"Gmail\",\"u\":\"https://mail.google.com\"},"
            + "{\"t\":\"Hava durumu\",\"u\":\"https://www.mgm.gov.tr\"}"
            + "]";

    static final int[] ZOOMS = {67, 75, 80, 90, 100, 110, 125, 150};
    static final int ENG_WEB = 0, ENG_GECKO = 1;
    static final int AT_ON = ContentBlocking.AntiTracking.DEFAULT
            | ContentBlocking.AntiTracking.CRYPTOMINING
            | ContentBlocking.AntiTracking.FINGERPRINTING;

    // Motor işlem başına bir kez açılır.
    static GeckoRuntime runtime;
    static WebExtension adExt;
    static String desktopUa;
    static GeckoWebExecutor executor;

    final ArrayList<Tab> tabs = new ArrayList<>();
    final Handler ui = new Handler(Looper.getMainLooper());
    Tab current;
    SharedPreferences prefs;
    boolean adBlock;
    boolean spViewport, spPre, spGecko, spTimer;
    int zoom;

    LinearLayout mainLayout, tabBar, toolBar, tabStrip, bookmarkStrip;
    HorizontalScrollView tabScroll, bmScroll;
    FrameLayout webContainer;
    GeckoView geckoView;
    EditText address;
    TextView backBtn, fwdBtn, starBtn, shieldBtn;
    ProgressBar progress;

    FrameLayout ntRoot;
    ImageView ntBg;
    View ntShade;
    TextView ntClock, ntDate;
    EditText ntSearch;
    GridLayout ntGrid;
    Bitmap bgCache;
    boolean bgLoaded;

    FrameLayout fullContainer;
    View customView;
    WebChromeClient.CustomViewCallback customCb;
    ValueCallback<Uri[]> webFileCb;

    FilePrompt pendingFile;
    GeckoResult<PromptResponse> pendingFileResult;

    class Tab {
        GeckoSession session;      // Firefox motoru (Google hesap siteleri)
        WebView web;               // hızlı motor (diğer bütün siteler)
        boolean gecko;             // şu an hangi motor görünüyor
        Boolean backTo;            // motor değişince geri tuşu diğer motora döner
        String webUrl, geckoUrl, webTitle, geckoTitle;
        String url = "";
        String title = "Yeni sekme";
        String pendingUrl;
        boolean isNewTab = true;
        boolean canBack, canFwd, fullscreen;   // Firefox motorunun geri/ileri durumu
        int progress = 100;
        final AtomicInteger blocked = new AtomicInteger();
        long loadStart;
        LinearLayout view;
        TextView titleView;

        String url() {
            if (pendingUrl != null) return pendingUrl;
            if (isNewTab) return "";
            return url == null ? "" : url;
        }
    }

    // ------------------------------------------------------------------ yaşam döngüsü

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("tarayici", MODE_PRIVATE);
        adBlock = prefs.getBoolean("adblock", true);
        zoom = prefs.getInt("zoom_v2", 100);
        loadAdHosts();
        loadSpeedPrefs();
        getWindow().setStatusBarColor(C_BAR);
        getWindow().setNavigationBarColor(C_TOOL);
        buildUi();
        restoreSession();
        if (savedInstanceState == null) handleIntent(getIntent());
        ui.post(clockTick);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        handleIntent(intent);
    }

    void handleIntent(Intent in) {
        if (in != null && Intent.ACTION_VIEW.equals(in.getAction()) && in.getData() != null) {
            newTab(in.getData().toString(), true, false);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        saveSession();
        CookieManager.getInstance().flush();
    }

    @Override
    protected void onDestroy() {
        ui.removeCallbacks(clockTick);
        for (Tab t : tabs) {
            if (t.web != null) {
                try { t.web.destroy(); } catch (Exception ignored) { }
            }
        }
        try { geckoView.releaseSession(); } catch (Exception ignored) { }
        for (Tab t : tabs) {
            if (t.session != null) {
                try { t.session.close(); } catch (Exception ignored) { }
            }
        }
        super.onDestroy();
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        webContainer.postDelayed(this::applyViewportAll, 350);
        if (current != null && current.isNewTab) ui.postDelayed(this::refreshNewTab, 200);
    }

    void ensureRuntime() {
        if (runtime != null) return;
        float density = getResources().getDisplayMetrics().density;
        ContentBlocking.Settings cb = new ContentBlocking.Settings.Builder()
                .antiTracking(adBlock ? AT_ON : ContentBlocking.AntiTracking.NONE)
                .enhancedTrackingProtectionLevel(adBlock ? ContentBlocking.EtpLevel.DEFAULT
                        : ContentBlocking.EtpLevel.NONE)
                .cookieBehavior(ContentBlocking.CookieBehavior.ACCEPT_NON_TRACKERS)
                .build();
        GeckoRuntimeSettings.Builder b = new GeckoRuntimeSettings.Builder()
                .javaScriptEnabled(true)
                .consoleOutput(false)
                .remoteDebuggingEnabled(false)
                .fontInflation(false)
                .preferredColorScheme(GeckoRuntimeSettings.COLOR_SCHEME_SYSTEM)
                .locales(new String[]{"tr-TR", "tr", "en-US", "en"})
                .contentBlocking(cb);
        runtime = GeckoRuntime.create(getApplicationContext(), b.build());

        runtime.getWebExtensionController()
                .ensureBuiltIn("resource://android/assets/adblock/", "adblock@masaustu")
                .accept(ext -> {
                    adExt = ext;
                    if (!adBlock) setExtEnabled(false);
                }, e -> { });

        String def = GeckoSession.getDefaultUserAgent();
        Matcher m = Pattern.compile("rv:([0-9.]+)").matcher(def == null ? "" : def);
        String v = m.find() ? m.group(1) : "140.0";
        desktopUa = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:" + v + ") Gecko/20100101 Firefox/" + v;
    }

    void loadSpeedPrefs() {
        spViewport = prefs.getBoolean("sp_vp", true);
        spPre = prefs.getBoolean("sp_pre", true);
        spGecko = prefs.getBoolean("sp_gecko", true);
        spTimer = prefs.getBoolean("sp_timer", true);
    }

    boolean useGeckoFor(String url) {
        return spGecko && isGoogleAccountUrl(url);
    }

    void startTimer(Tab t) {
        t.loadStart = SystemClock.elapsedRealtime();
    }

    void stopTimer(Tab t, String engine) {
        if (t.loadStart == 0) return;
        long ms = SystemClock.elapsedRealtime() - t.loadStart;
        t.loadStart = 0;
        if (spTimer && t == current && !t.isNewTab) {
            toast("Açılış: " + String.format(new Locale("tr", "TR"), "%.1f", ms / 1000f) + " sn (" + engine + ")");
        }
    }

    /** Hız ayarları: her biri ayrı açılıp kapatılabilir, açılış süresi ekranda ölçülür. */
    void speedDialog() {
        final String[] labels = {
                "Masaüstü genişlik ayarı (sayfaya ek kod çalıştırır)",
                "Sayfayı önceden çiz (akıcı kaydırma, daha çok bellek)",
                "Gmail ve YouTube'u Firefox motorunda aç (hesaba giriş için)",
                "Her sayfanın açılış süresini göster"};
        final boolean[] on = {spViewport, spPre, spGecko, spTimer};
        dlg().setTitle("Hız ayarları")
                .setMultiChoiceItems(labels, on, (d, which, checked) -> on[which] = checked)
                .setPositiveButton("Kaydet", (d, w) -> saveSpeed(on[0], on[1], on[2], on[3]))
                .setNeutralButton("İlk sürümdeki gibi", (d, w) -> saveSpeed(false, false, false, true))
                .setNegativeButton("İptal", null)
                .show();
    }

    void saveSpeed(boolean vp, boolean pre, boolean gk, boolean tm) {
        prefs.edit().putBoolean("sp_vp", vp).putBoolean("sp_pre", pre)
                .putBoolean("sp_gecko", gk).putBoolean("sp_timer", tm).apply();
        loadSpeedPrefs();
        showContent();
        toast("Hız ayarları kaydedildi. Değişiklik yeni açılan sayfalarda geçerli.");
    }

    void loadAdHosts() {
        if (!AD_HOSTS.isEmpty()) return;
        try (InputStream in = getAssets().open("adblock/rules.json")) {
            java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            JSONArray rules = new JSONArray(bo.toString("UTF-8"));
            JSONArray d = rules.getJSONObject(0).getJSONObject("condition").getJSONArray("requestDomains");
            for (int i = 0; i < d.length(); i++) AD_HOSTS.add(d.getString(i));
        } catch (Exception ignored) { }
    }

    static boolean isAdHost(String host) {
        if (host == null) return false;
        String h = host.toLowerCase(Locale.ROOT);
        while (true) {
            if (AD_HOSTS.contains(h)) return true;
            int dot = h.indexOf('.');
            if (dot < 0 || dot == h.length() - 1) return false;
            h = h.substring(dot + 1);
        }
    }

    /** Google hesabı isteyen siteler Firefox motorunda açılır; Google bunlara başka motordan girişe izin vermiyor. */
    static boolean isGoogleAccountUrl(String url) {
        if (url == null || !url.startsWith("http")) return false;
        String h;
        try { h = Uri.parse(url).getHost(); } catch (Exception e) { return false; }
        if (h == null) return false;
        h = h.toLowerCase(Locale.ROOT);
        String[] exact = {"accounts.google.com", "mail.google.com", "myaccount.google.com", "drive.google.com",
                "docs.google.com", "photos.google.com", "calendar.google.com", "contacts.google.com",
                "keep.google.com", "meet.google.com", "chat.google.com", "play.google.com",
                "gemini.google.com", "notebooklm.google.com", "accounts.youtube.com"};
        for (String e : exact) if (h.equals(e)) return true;
        String[] suffix = {"youtube.com", "youtu.be", "gmail.com"};
        for (String sfx : suffix) if (h.equals(sfx) || h.endsWith("." + sfx)) return true;
        return false;
    }

    void setExtEnabled(boolean on) {
        if (adExt == null) return;
        try {
            WebExtensionController c = runtime.getWebExtensionController();
            GeckoResult<WebExtension> r = on
                    ? c.enable(adExt, WebExtensionController.EnableSource.USER)
                    : c.disable(adExt, WebExtensionController.EnableSource.USER);
            r.accept(ext -> { if (ext != null) adExt = ext; }, e -> { });
        } catch (Exception ignored) { }
    }

    // ------------------------------------------------------------------ arayüz yardımcıları

    int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    Drawable ripple(boolean borderless) {
        TypedValue tv = new TypedValue();
        getTheme().resolveAttribute(borderless
                ? android.R.attr.selectableItemBackgroundBorderless
                : android.R.attr.selectableItemBackground, tv, true);
        return getDrawable(tv.resourceId);
    }

    GradientDrawable round(int color, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    TextView iconBtn(String s, int sp) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(C_TEXT);
        t.setGravity(Gravity.CENTER);
        t.setBackground(ripple(true));
        t.setClickable(true);
        return t;
    }

    void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    AlertDialog.Builder dlg() {
        return new AlertDialog.Builder(this);
    }

    void hideKeyboard(View v) {
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
    }

    static String nz(String s, String d) {
        return (s == null || s.isEmpty()) ? d : s;
    }

    // ------------------------------------------------------------------ arayüz

    void buildUi() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(C_BAR);

        mainLayout = new LinearLayout(this);
        mainLayout.setOrientation(LinearLayout.VERTICAL);
        mainLayout.setBackgroundColor(C_TOOL);
        root.addView(mainLayout, new FrameLayout.LayoutParams(-1, -1));
        fullContainer = new FrameLayout(this);
        fullContainer.setBackgroundColor(Color.BLACK);
        fullContainer.setVisibility(View.GONE);
        root.addView(fullContainer, new FrameLayout.LayoutParams(-1, -1));

        // Sekme şeridi
        tabBar = new LinearLayout(this);
        tabBar.setOrientation(LinearLayout.HORIZONTAL);
        tabBar.setBackgroundColor(C_BAR);
        tabBar.setPadding(dp(6), dp(6), dp(6), 0);
        tabBar.setGravity(Gravity.BOTTOM);
        tabScroll = new HorizontalScrollView(this);
        tabScroll.setHorizontalScrollBarEnabled(false);
        tabStrip = new LinearLayout(this);
        tabStrip.setOrientation(LinearLayout.HORIZONTAL);
        tabScroll.addView(tabStrip, new FrameLayout.LayoutParams(-2, -1));
        tabBar.addView(tabScroll, new LinearLayout.LayoutParams(0, dp(38), 1f));
        TextView plus = iconBtn("+", 22);
        plus.setOnClickListener(v -> newTab(null, true, false));
        tabBar.addView(plus, new LinearLayout.LayoutParams(dp(44), dp(38)));
        mainLayout.addView(tabBar, new LinearLayout.LayoutParams(-1, -2));

        // Araç çubuğu
        toolBar = new LinearLayout(this);
        toolBar.setOrientation(LinearLayout.HORIZONTAL);
        toolBar.setBackgroundColor(C_TOOL);
        toolBar.setGravity(Gravity.CENTER_VERTICAL);
        toolBar.setPadding(dp(6), dp(5), dp(6), dp(5));
        backBtn = iconBtn("←", 20);
        backBtn.setOnClickListener(v -> goBack());
        fwdBtn = iconBtn("→", 20);
        fwdBtn.setOnClickListener(v -> goForward());
        TextView reload = iconBtn("↻", 20);
        reload.setOnClickListener(v -> reload());
        TextView home = iconBtn("⌂", 22);
        home.setOnClickListener(v -> goHome());
        for (TextView b : new TextView[]{backBtn, fwdBtn, reload, home}) {
            toolBar.addView(b, new LinearLayout.LayoutParams(dp(42), dp(40)));
        }

        address = new EditText(this);
        address.setSingleLine(true);
        address.setTextColor(C_TEXT);
        address.setHintTextColor(C_DIM);
        address.setHint("Arama yapın veya adres yazın");
        address.setTextSize(15);
        address.setBackground(round(C_FIELD, 20));
        address.setPadding(dp(16), 0, dp(16), 0);
        address.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        address.setImeOptions(EditorInfo.IME_ACTION_GO | EditorInfo.IME_FLAG_NO_EXTRACT_UI);
        address.setSelectAllOnFocus(true);
        address.setOnEditorActionListener((v, id, ev) -> {
            boolean enter = ev != null && ev.getKeyCode() == KeyEvent.KEYCODE_ENTER;
            if (id == EditorInfo.IME_ACTION_GO || (enter && ev.getAction() == KeyEvent.ACTION_DOWN)) {
                go(address.getText().toString());
                return true;
            }
            return enter;
        });
        address.setOnFocusChangeListener((v, has) -> { if (!has) updateToolbar(); });
        LinearLayout.LayoutParams alp = new LinearLayout.LayoutParams(0, dp(38), 1f);
        alp.leftMargin = dp(6);
        alp.rightMargin = dp(6);
        toolBar.addView(address, alp);

        shieldBtn = iconBtn("🛡", 15);
        shieldBtn.setOnClickListener(v -> adBlockDialog());
        toolBar.addView(shieldBtn, new LinearLayout.LayoutParams(dp(60), dp(40)));
        starBtn = iconBtn("☆", 22);
        starBtn.setOnClickListener(v -> toggleBookmark());
        toolBar.addView(starBtn, new LinearLayout.LayoutParams(dp(42), dp(40)));
        final TextView menu = iconBtn("⋮", 22);
        menu.setOnClickListener(v -> showMenu(menu));
        toolBar.addView(menu, new LinearLayout.LayoutParams(dp(42), dp(40)));
        mainLayout.addView(toolBar, new LinearLayout.LayoutParams(-1, -2));

        // Yer imleri çubuğu
        bmScroll = new HorizontalScrollView(this);
        bmScroll.setHorizontalScrollBarEnabled(false);
        bmScroll.setBackgroundColor(C_TOOL);
        bookmarkStrip = new LinearLayout(this);
        bookmarkStrip.setOrientation(LinearLayout.HORIZONTAL);
        bookmarkStrip.setGravity(Gravity.CENTER_VERTICAL);
        bookmarkStrip.setPadding(dp(8), 0, dp(8), dp(2));
        bmScroll.addView(bookmarkStrip, new FrameLayout.LayoutParams(-2, -1));
        mainLayout.addView(bmScroll, new LinearLayout.LayoutParams(-1, dp(34)));

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        progress.setProgressTintList(ColorStateList.valueOf(C_ACCENT));
        progress.setProgressBackgroundTintList(ColorStateList.valueOf(C_TOOL));
        progress.setVisibility(View.INVISIBLE);
        mainLayout.addView(progress, new LinearLayout.LayoutParams(-1, dp(3)));

        webContainer = new FrameLayout(this);
        webContainer.setBackgroundColor(Color.WHITE);
        geckoView = new GeckoView(this);
        geckoView.setVisibility(View.GONE);
        webContainer.addView(geckoView, new FrameLayout.LayoutParams(-1, -1));
        buildNewTabPage();
        webContainer.addView(ntRoot, new FrameLayout.LayoutParams(-1, -1));
        mainLayout.addView(webContainer, new LinearLayout.LayoutParams(-1, 0, 1f));

        setContentView(root);
        refreshBookmarkBar();
    }

    // ------------------------------------------------------------------ yeni sekme sayfası (uygulamanın içinde çizilir)

    void buildNewTabPage() {
        ntRoot = new FrameLayout(this);
        ntRoot.setBackgroundColor(0xFF16161B);
        ntRoot.setClickable(true);

        ntBg = new ImageView(this);
        ntBg.setScaleType(ImageView.ScaleType.CENTER_CROP);
        ntRoot.addView(ntBg, new FrameLayout.LayoutParams(-1, -1));

        ntShade = new View(this);
        ntShade.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0x47000000, 0x1F000000, 0x61000000}));
        ntRoot.addView(ntShade, new FrameLayout.LayoutParams(-1, -1));

        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER_HORIZONTAL);
        col.setPadding(dp(28), dp(64), dp(28), dp(60));

        ntClock = new TextView(this);
        ntClock.setTextColor(0xFFF6F6F8);
        ntClock.setTextSize(84);
        ntClock.setTypeface(Typeface.create("sans-serif-thin", Typeface.NORMAL));
        ntClock.setShadowLayer(24, 0, 2, 0x59000000);
        ntClock.setGravity(Gravity.CENTER_HORIZONTAL);
        ntClock.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        col.addView(ntClock, new LinearLayout.LayoutParams(-1, -2));

        ntDate = new TextView(this);
        ntDate.setTextColor(0xCCF6F6F8);
        ntDate.setTextSize(17);
        ntDate.setShadowLayer(10, 0, 1, 0x66000000);
        ntDate.setGravity(Gravity.CENTER_HORIZONTAL);
        ntDate.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        col.addView(ntDate, new LinearLayout.LayoutParams(-1, -2));

        ntSearch = new EditText(this);
        ntSearch.setSingleLine(true);
        ntSearch.setHint("Google’da ara veya adres yaz");
        ntSearch.setHintTextColor(0xFF7A7A84);
        ntSearch.setTextColor(0xFF1C1C1F);
        ntSearch.setTextSize(17);
        ntSearch.setBackground(round(0xF0FFFFFF, 27));
        ntSearch.setPadding(dp(24), 0, dp(24), 0);
        ntSearch.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        ntSearch.setImeOptions(EditorInfo.IME_ACTION_GO | EditorInfo.IME_FLAG_NO_EXTRACT_UI);
        ntSearch.setElevation(dp(6));
        ntSearch.setOnEditorActionListener((v, id, ev) -> {
            boolean enter = ev != null && ev.getKeyCode() == KeyEvent.KEYCODE_ENTER;
            if (id == EditorInfo.IME_ACTION_GO || (enter && ev.getAction() == KeyEvent.ACTION_DOWN)) {
                String q = ntSearch.getText().toString();
                ntSearch.setText("");
                hideKeyboard(ntSearch);
                go(q);
                return true;
            }
            return enter;
        });
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(dp(680), dp(54));
        slp.topMargin = dp(34);
        slp.bottomMargin = dp(40);
        col.addView(ntSearch, slp);

        ntGrid = new GridLayout(this);
        col.addView(ntGrid, new LinearLayout.LayoutParams(dp(1060), -2));

        sv.addView(col, new FrameLayout.LayoutParams(-1, -2));
        ntRoot.addView(sv, new FrameLayout.LayoutParams(-1, -1));

        TextView bgBtn = new TextView(this);
        bgBtn.setText("Arka plan");
        bgBtn.setTextColor(0xFFF6F6F8);
        bgBtn.setTextSize(14);
        bgBtn.setGravity(Gravity.CENTER);
        bgBtn.setPadding(dp(16), 0, dp(16), 0);
        GradientDrawable pill = round(0x6B18181E, 19);
        pill.setStroke(dp(1), 0x29FFFFFF);
        bgBtn.setBackground(pill);
        bgBtn.setForeground(ripple(false));
        bgBtn.setOnClickListener(v -> dlg().setTitle("Arka plan")
                .setItems(new String[]{"Galeriden görsel seç", "Varsayılan arka plan"}, (d, which) -> {
                    if (which == 0) pickBackground();
                    else {
                        //noinspection ResultOfMethodCallIgnored
                        new File(getFilesDir(), "bg.jpg").delete();
                        bgLoaded = false;
                        refreshNewTab();
                        toast("Varsayılan arka plana dönüldü");
                    }
                }).show());
        FrameLayout.LayoutParams blp = new FrameLayout.LayoutParams(-2, dp(38), Gravity.TOP | Gravity.END);
        blp.topMargin = dp(16);
        blp.rightMargin = dp(18);
        ntRoot.addView(bgBtn, blp);
    }

    Drawable defaultBg() {
        return new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{0xFF3A2D6E, 0xFF1A1724, 0xFF0D5A6B});
    }

    void refreshNewTab() {
        if (!bgLoaded) {
            bgLoaded = true;
            File f = new File(getFilesDir(), "bg.jpg");
            bgCache = f.exists() ? BitmapFactory.decodeFile(f.getAbsolutePath()) : null;
        }
        if (bgCache != null) {
            ntBg.setImageBitmap(bgCache);
            ntShade.setVisibility(View.VISIBLE);
        } else {
            ntBg.setImageDrawable(defaultBg());
            ntShade.setVisibility(View.GONE);
        }

        int avail = getResources().getDisplayMetrics().widthPixels - dp(56);
        int gridW = Math.min(avail, dp(1060));
        ViewGroupWidth(ntSearch, Math.min(avail, dp(680)));
        ViewGroupWidth(ntGrid, gridW);
        int cols = Math.max(2, Math.min(8, gridW / dp(164)));
        ntGrid.removeAllViews();
        ntGrid.setColumnCount(cols);

        JSONArray tiles = getTiles();
        for (int i = 0; i < tiles.length(); i++) {
            JSONObject o = tiles.optJSONObject(i);
            if (o == null) continue;
            ntGrid.addView(tileView(o.optString("t"), o.optString("u"), i), gridLp());
        }
        ntGrid.addView(tileView("Site ekle", null, -1), gridLp());
        tickClock();
    }

    void ViewGroupWidth(View v, int w) {
        android.view.ViewGroup.LayoutParams lp = v.getLayoutParams();
        if (lp != null && lp.width != w) {
            lp.width = w;
            v.setLayoutParams(lp);
        }
    }

    GridLayout.LayoutParams gridLp() {
        GridLayout.LayoutParams lp = new GridLayout.LayoutParams(
                GridLayout.spec(GridLayout.UNDEFINED), GridLayout.spec(GridLayout.UNDEFINED, 1f));
        lp.width = 0;
        lp.height = dp(124);
        lp.setMargins(dp(8), dp(8), dp(8), dp(8));
        return lp;
    }

    View tileView(String name, final String url, final int idx) {
        boolean add = url == null;
        LinearLayout v = new LinearLayout(this);
        v.setOrientation(LinearLayout.VERTICAL);
        v.setGravity(Gravity.CENTER);
        v.setPadding(dp(10), dp(10), dp(10), dp(10));
        GradientDrawable bg = round(add ? 0x3818181E : 0x6B18181E, 18);
        if (add) bg.setStroke(dp(1), 0x80FFFFFF, dp(6), dp(4));
        else bg.setStroke(dp(1), 0x29FFFFFF);
        v.setBackground(bg);
        v.setForeground(ripple(false));

        FrameLayout logoBox = new FrameLayout(this);
        TextView logo = new TextView(this);
        logo.setGravity(Gravity.CENTER);
        logo.setTextColor(Color.WHITE);
        logoBox.addView(logo, new FrameLayout.LayoutParams(-1, -1));
        if (add) {
            logo.setText("+");
            logo.setTextSize(30);
            GradientDrawable lb = round(0x00000000, 14);
            lb.setStroke(dp(1.5f), 0xCCF6F6F8, dp(5), dp(3));
            logo.setBackground(lb);
        } else {
            String host = hostOf(url);
            String letter = nz(name, nz(host, "?")).trim();
            logo.setText(letter.isEmpty() ? "?" : letter.substring(0, 1).toUpperCase(new Locale("tr")));
            logo.setTextSize(24);
            logo.setTypeface(Typeface.DEFAULT_BOLD);
            logo.setBackground(round(colorFor(nz(host, name)), 14));
            ImageView icon = new ImageView(this);
            icon.setScaleType(ImageView.ScaleType.FIT_CENTER);
            icon.setBackground(round(0xFFFFFFFF, 14));
            icon.setPadding(dp(6), dp(6), dp(6), dp(6));
            icon.setClipToOutline(true);
            icon.setVisibility(View.GONE);
            logoBox.addView(icon, new FrameLayout.LayoutParams(-1, -1));
            setIcon(host, icon);
        }
        v.addView(logoBox, new LinearLayout.LayoutParams(dp(54), dp(54)));

        TextView nm = new TextView(this);
        nm.setText(name);
        nm.setTextColor(0xFFF6F6F8);
        nm.setTextSize(14);
        nm.setSingleLine(true);
        nm.setEllipsize(TextUtils.TruncateAt.END);
        nm.setShadowLayer(8, 0, 1, 0x73000000);
        LinearLayout.LayoutParams nlp = new LinearLayout.LayoutParams(-2, -2);
        nlp.topMargin = dp(12);
        v.addView(nm, nlp);

        if (add) {
            v.setOnClickListener(c -> tileEditor(-1));
        } else {
            v.setOnTouchListener((c, ev) -> {
                if (ev.getAction() == MotionEvent.ACTION_DOWN) preconnect(url);
                return false;
            });
            v.setOnClickListener(c -> load(current, url));
            v.setOnLongClickListener(c -> { tileMenu(idx); return true; });
            v.setOnContextClickListener(c -> { tileMenu(idx); return true; });
        }
        return v;
    }

    final HashMap<String, Bitmap> iconMem = new HashMap<>();
    final HashSet<String> iconLoading = new HashSet<>();
    final HashSet<String> iconFailed = new HashSet<>();

    /** Sitenin kendi logosunu gösterir; ilk seferde internetten alıp telefona kaydeder. */
    void setIcon(final String host, final ImageView iv) {
        if (host == null || host.isEmpty()) return;
        Bitmap b = iconMem.get(host);
        final File dir = new File(getFilesDir(), "icons");
        final File f = new File(dir, host.replaceAll("[^a-zA-Z0-9.-]", "_") + ".png");
        if (b == null && f.exists()) {
            b = BitmapFactory.decodeFile(f.getAbsolutePath());
            if (b != null) iconMem.put(host, b);
        }
        if (b != null) {
            iv.setImageBitmap(b);
            iv.setVisibility(View.VISIBLE);
            return;
        }
        if (iconFailed.contains(host) || !iconLoading.add(host)) return;
        new Thread(() -> {
            Bitmap got = null;
            String[] sources = {
                    "https://" + host + "/apple-touch-icon.png",
                    "https://www." + host + "/apple-touch-icon.png",
                    "https://www.google.com/s2/favicons?sz=128&domain_url=https%3A%2F%2F" + host,
                    "https://icons.duckduckgo.com/ip3/" + host + ".ico"
            };
            for (String src : sources) {
                if (src.startsWith("https://www.www.")) continue;
                got = fetchIcon(src);
                if (got != null) break;
            }
            if (got != null) {
                try {
                    //noinspection ResultOfMethodCallIgnored
                    dir.mkdirs();
                    try (FileOutputStream out = new FileOutputStream(f)) {
                        got.compress(Bitmap.CompressFormat.PNG, 100, out);
                    }
                } catch (Exception ignored) { }
            }
            final Bitmap fb = got;
            ui.post(() -> {
                iconLoading.remove(host);
                if (fb == null) {
                    iconFailed.add(host);
                    return;
                }
                iconMem.put(host, fb);
                if (current != null && current.isNewTab) refreshNewTab();
            });
        }).start();
    }

    /** Bir adresten logo indirir; bulanık kalacak kadar küçük logoları kabul etmez. */
    Bitmap fetchIcon(String src) {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(src).openConnection();
            c.setInstanceFollowRedirects(true);
            c.setConnectTimeout(6000);
            c.setReadTimeout(8000);
            c.setRequestProperty("User-Agent", desktopUa != null ? desktopUa : "Mozilla/5.0");
            c.setRequestProperty("Accept", "image/*");
            if (c.getResponseCode() != 200) return null;
            try (InputStream in = c.getInputStream()) {
                Bitmap bm = BitmapFactory.decodeStream(in);
                return (bm != null && bm.getWidth() >= 32 && bm.getHeight() >= 32) ? bm : null;
            }
        } catch (Exception e) {
            return null;
        } finally {
            if (c != null) c.disconnect();
        }
    }

    int colorFor(String s) {
        int h = 0;
        for (int i = 0; i < s.length(); i++) h = h * 31 + s.charAt(i);
        return TILE_COLORS[Math.abs(h % TILE_COLORS.length)];
    }

    static String hostOf(String u) {
        try {
            String h = Uri.parse(u).getHost();
            if (h == null) return "";
            return h.startsWith("www.") ? h.substring(4) : h;
        } catch (Exception e) {
            return "";
        }
    }

    JSONArray getTiles() {
        try {
            return new JSONArray(prefs.getString("tiles", DEFAULT_TILES));
        } catch (JSONException e) {
            return new JSONArray();
        }
    }

    void tileMenu(final int idx) {
        final JSONObject o = getTiles().optJSONObject(idx);
        if (o == null) return;
        final String u = o.optString("u");
        dlg().setTitle(o.optString("t"))
                .setItems(new String[]{"Yeni sekmede aç", "Düzenle", "Sil"}, (d, which) -> {
                    if (which == 0) newTab(u, true, true);
                    else if (which == 1) tileEditor(idx);
                    else {
                        JSONArray a = getTiles();
                        a.remove(idx);
                        prefs.edit().putString("tiles", a.toString()).apply();
                        refreshNewTab();
                    }
                }).show();
    }

    void tileEditor(final int idx) {
        JSONObject o = idx >= 0 ? getTiles().optJSONObject(idx) : null;
        formDialog(idx >= 0 ? "Kutucuğu düzenle" : "Site ekle",
                o == null ? "" : o.optString("t"), o == null ? "" : o.optString("u"), (nm, u) -> {
                    JSONArray a = getTiles();
                    JSONObject n = new JSONObject();
                    try {
                        n.put("t", nm);
                        n.put("u", u);
                        if (idx >= 0 && idx < a.length()) a.put(idx, n); else a.put(n);
                    } catch (JSONException ignored) { }
                    prefs.edit().putString("tiles", a.toString()).apply();
                    refreshNewTab();
                });
    }

    interface FormSave {
        void save(String name, String url);
    }

    void formDialog(String title, String name, String url, final FormSave cb) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(8), dp(20), 0);
        final EditText n = new EditText(this);
        n.setHint("Ad");
        n.setSingleLine(true);
        n.setText(name);
        final EditText a = new EditText(this);
        a.setHint("Adres (örnek.com)");
        a.setSingleLine(true);
        a.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        a.setText(url);
        box.addView(n);
        box.addView(a);
        dlg().setTitle(title).setView(box)
                .setPositiveButton("Kaydet", (d, w) -> {
                    String u = a.getText().toString().trim();
                    if (u.isEmpty()) return;
                    if (!u.matches("^[a-zA-Z][a-zA-Z0-9+.-]*:.*")) u = "https://" + u;
                    String nm = n.getText().toString().trim();
                    if (nm.isEmpty()) nm = hostOf(u);
                    cb.save(nm, u);
                })
                .setNegativeButton("İptal", null).show();
    }

    final Runnable clockTick = new Runnable() {
        @Override
        public void run() {
            tickClock();
            ui.postDelayed(this, 15000);
        }
    };

    void tickClock() {
        if (ntClock == null || ntRoot.getVisibility() != View.VISIBLE) return;
        Date d = new Date();
        Locale tr = new Locale("tr", "TR");
        ntClock.setText(new SimpleDateFormat("HH:mm", tr).format(d));
        ntDate.setText(new SimpleDateFormat("d MMMM EEEE", tr).format(d));
    }

    void pickBackground() {
        Intent i = new Intent(Intent.ACTION_GET_CONTENT);
        i.setType("image/*");
        i.addCategory(Intent.CATEGORY_OPENABLE);
        try {
            startActivityForResult(Intent.createChooser(i, "Arka plan görseli seç"), REQ_BG);
        } catch (Exception e) {
            toast("Galeri açılamadı");
        }
    }

    void saveBackground(Uri u) {
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            try (InputStream in = getContentResolver().openInputStream(u)) {
                BitmapFactory.decodeStream(in, null, o);
            }
            int max = Math.max(o.outWidth, o.outHeight);
            int sample = 1;
            while (max / (sample * 2) >= 2560) sample *= 2;
            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = sample;
            Bitmap bm;
            try (InputStream in = getContentResolver().openInputStream(u)) {
                bm = BitmapFactory.decodeStream(in, null, o2);
            }
            if (bm == null) {
                toast("Bu görsel açılamadı");
                return;
            }
            int rot = 0;
            try (InputStream in = getContentResolver().openInputStream(u)) {
                if (in != null) {
                    ExifInterface ex = new ExifInterface(in);
                    int or = ex.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
                    if (or == ExifInterface.ORIENTATION_ROTATE_90) rot = 90;
                    else if (or == ExifInterface.ORIENTATION_ROTATE_180) rot = 180;
                    else if (or == ExifInterface.ORIENTATION_ROTATE_270) rot = 270;
                }
            } catch (Exception ignored) { }
            Matrix mx = new Matrix();
            float big = Math.max(bm.getWidth(), bm.getHeight());
            if (big > 2560) mx.postScale(2560f / big, 2560f / big);
            if (rot != 0) mx.postRotate(rot);
            if (!mx.isIdentity()) bm = Bitmap.createBitmap(bm, 0, 0, bm.getWidth(), bm.getHeight(), mx, true);
            try (FileOutputStream out = new FileOutputStream(new File(getFilesDir(), "bg.jpg"))) {
                bm.compress(Bitmap.CompressFormat.JPEG, 85, out);
            }
            bgCache = bm;
            bgLoaded = true;
            refreshNewTab();
            toast("Arka plan değiştirildi");
        } catch (Exception e) {
            toast("Görsel kaydedilemedi");
        }
    }

    // ------------------------------------------------------------------ sekmeler

    Tab newTab(String url, boolean select, boolean nextToCurrent) {
        Tab t = new Tab();
        int idx = (nextToCurrent && current != null) ? tabs.indexOf(current) + 1 : tabs.size();
        tabs.add(idx, t);
        buildTabView(t);
        tabStrip.addView(t.view, idx);
        if (url != null && !url.isEmpty()) {
            load(t, url);
            if (!select && t.gecko && t.session != null) t.session.setActive(false);
        }
        if (select || current == null) selectTab(t); else refreshTabViews();
        return t;
    }

    void buildTabView(final Tab t) {
        LinearLayout v = new LinearLayout(this);
        v.setOrientation(LinearLayout.HORIZONTAL);
        v.setGravity(Gravity.CENTER_VERTICAL);
        v.setPadding(dp(12), 0, dp(4), 0);
        TextView title = new TextView(this);
        title.setSingleLine(true);
        title.setEllipsize(TextUtils.TruncateAt.END);
        title.setTextSize(13);
        v.addView(title, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView x = new TextView(this);
        x.setText("✕");
        x.setTextSize(12);
        x.setTextColor(C_DIM);
        x.setGravity(Gravity.CENTER);
        x.setBackground(ripple(true));
        x.setOnClickListener(c -> closeTab(t));
        v.addView(x, new LinearLayout.LayoutParams(dp(28), dp(28)));
        v.setOnClickListener(c -> selectTab(t));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(210), -1);
        lp.rightMargin = dp(2);
        v.setLayoutParams(lp);
        t.view = v;
        t.titleView = title;
    }

    String tabTitle(Tab t) {
        if (t.isNewTab && t.pendingUrl == null) return "Yeni sekme";
        if (t.title != null && !t.title.trim().isEmpty()) return t.title;
        String u = t.url();
        return u.isEmpty() ? "Yeni sekme" : u;
    }

    void refreshTabViews() {
        float r = dp(10);
        for (Tab t : tabs) {
            boolean active = t == current;
            GradientDrawable g = new GradientDrawable();
            g.setColor(active ? C_TOOL : 0x00000000);
            g.setCornerRadii(new float[]{r, r, r, r, 0, 0, 0, 0});
            t.view.setBackground(g);
            t.titleView.setText(tabTitle(t));
            t.titleView.setTextColor(active ? C_TEXT : C_DIM);
        }
    }

    void selectTab(Tab t) {
        current = t;
        if (t.pendingUrl != null) {
            String u = t.pendingUrl;
            t.pendingUrl = null;
            load(t, u);
        }
        showContent();
        refreshTabViews();
        updateToolbar();
        final View v = t.view;
        tabScroll.post(() -> {
            int l = v.getLeft(), rr = v.getRight(), sx = tabScroll.getScrollX(), w = tabScroll.getWidth();
            if (l < sx) tabScroll.smoothScrollTo(l, 0);
            else if (rr > sx + w) tabScroll.smoothScrollTo(rr - w, 0);
        });
    }

    /** Görünen sekmeye göre doğru motoru veya yeni sekme sayfasını gösterir; diğer sekmeleri uyutur. */
    void showContent() {
        Tab t = current;
        if (t == null) return;
        boolean nt = t.isNewTab;
        ntRoot.setVisibility(nt ? View.VISIBLE : View.GONE);
        if (nt) refreshNewTab();
        for (Tab o : tabs) {
            if (o.web == null) continue;
            boolean vis = o == t && !nt && !t.gecko;
            o.web.setVisibility(vis ? View.VISIBLE : View.GONE);
            o.web.getSettings().setOffscreenPreRaster(vis && spPre);
        }
        geckoView.setVisibility(!nt && t.gecko ? View.VISIBLE : View.GONE);
        showSession(t);
        applyChrome();
    }

    void showSession(final Tab t) {
        GeckoSession want = (t.isNewTab || !t.gecko || t.session == null) ? null : t.session;
        GeckoSession have = geckoView.getSession();
        if (want == have) return;
        if (want != null && !want.isOpen()) {
            ui.postDelayed(() -> { if (current == t) showSession(t); }, 120);
            return;
        }
        if (have != null) {
            have.setActive(false);
            geckoView.releaseSession();
        }
        if (want != null) {
            geckoView.setSession(want);
            want.setActive(true);
            geckoView.requestFocus();
        }
    }

    void closeTab(Tab t) {
        int i = tabs.indexOf(t);
        if (i < 0) return;
        if (customView != null && t == current) hideFullscreen();
        tabs.remove(i);
        tabStrip.removeView(t.view);
        if (t.session != null) {
            if (geckoView.getSession() == t.session) geckoView.releaseSession();
            try { t.session.close(); } catch (Exception ignored) { }
            t.session = null;
        }
        if (t.web != null) {
            webContainer.removeView(t.web);
            try { t.web.destroy(); } catch (Exception ignored) { }
            t.web = null;
        }
        if (tabs.isEmpty()) {
            current = null;
            newTab(null, true, false);
            return;
        }
        if (t == current) {
            current = null;
            selectTab(tabs.get(Math.min(i, tabs.size() - 1)));
        } else {
            refreshTabViews();
        }
    }

    void recreateSession(Tab t) {
        if (!tabs.contains(t)) return;
        String u = t.geckoUrl;
        if (t.session != null) {
            if (geckoView.getSession() == t.session) geckoView.releaseSession();
            try { t.session.close(); } catch (Exception ignored) { }
            t.session = null;
        }
        if (!t.gecko || u == null || u.isEmpty()) return;
        if (t == current) load(t, u); else t.pendingUrl = u;
    }

    void recreateWeb(Tab t) {
        if (!tabs.contains(t) || t.web == null) return;
        String u = t.webUrl;
        webContainer.removeView(t.web);
        try { t.web.destroy(); } catch (Exception ignored) { }
        t.web = null;
        if (t.gecko || u == null || u.isEmpty()) return;
        if (t == current) load(t, u); else t.pendingUrl = u;
    }

    boolean hasPage(Tab t, boolean geckoEngine) {
        return geckoEngine ? (t.session != null && t.geckoUrl != null)
                : (t.web != null && t.webUrl != null);
    }

    void load(Tab t, String url) {
        if (t == null) return;
        if (url == null || url.isEmpty()) {
            t.isNewTab = true;
            if (t == current) { showContent(); updateToolbar(); refreshTabViews(); }
            return;
        }
        t.pendingUrl = null;
        boolean useGecko = useGeckoFor(url);
        if (useGecko != t.gecko) {
            t.backTo = (!t.isNewTab && hasPage(t, t.gecko)) ? t.gecko : null;
        }
        t.isNewTab = false;
        t.gecko = useGecko;
        t.url = url;
        if (useGecko) {
            if (t.session == null) t.session = createSession(t, true);
            t.geckoUrl = url;
            t.session.loadUri(url);
        } else {
            if (t.web == null) createWebView(t);
            t.webUrl = url;
            t.web.loadUrl(url);
        }
        if (t == current) { showContent(); updateToolbar(); refreshTabViews(); }
    }

    /** Parmak dokunduğu anda siteyle bağlantıyı açmaya başlar; sayfa birkaç yüz milisaniye erken gelir. */
    void preconnect(String url) {
        if (url == null || !isGoogleAccountUrl(url)) return;
        try {
            if (runtime == null) return;
            if (executor == null) executor = new GeckoWebExecutor(runtime);
            executor.speculativeConnect(url);
        } catch (Exception ignored) { }
    }

    void go(String input) {
        String s = input.trim();
        if (s.isEmpty() || current == null) return;
        String url;
        if (s.matches("^[a-zA-Z][a-zA-Z0-9+.-]*://.*") || s.startsWith("about:")) {
            url = s;
        } else if (!s.contains(" ") && (s.matches("^[^\\s/]+\\.[a-zA-Z]{2,}(:\\d+)?(/.*)?$")
                || s.matches("^\\d{1,3}(\\.\\d{1,3}){3}(:\\d+)?(/.*)?$")
                || s.startsWith("localhost"))) {
            url = "https://" + s;
        } else {
            String q;
            try { q = URLEncoder.encode(s, "UTF-8"); } catch (Exception e) { q = s; }
            url = "https://www.google.com/search?q=" + q;
        }
        address.clearFocus();
        hideKeyboard(address);
        load(current, url);
    }

    boolean canGoBack(Tab t) {
        if (t == null) return false;
        if (t.isNewTab) return t.url != null && !t.url.isEmpty() && (t.session != null || t.web != null);
        if (t.gecko ? t.canBack : (t.web != null && t.web.canGoBack())) return true;
        return t.backTo != null && hasPage(t, t.backTo);
    }

    void goBack() {
        Tab t = current;
        if (t == null) return;
        if (t.isNewTab) {
            if (canGoBack(t)) {
                t.isNewTab = false;
                showContent();
                updateToolbar();
                refreshTabViews();
            }
            return;
        }
        if (t.gecko && t.canBack && t.session != null) { t.session.goBack(); return; }
        if (!t.gecko && t.web != null && t.web.canGoBack()) { t.web.goBack(); return; }
        if (t.backTo != null && hasPage(t, t.backTo)) {
            t.gecko = t.backTo;
            t.backTo = null;
            t.url = t.gecko ? t.geckoUrl : t.webUrl;
            t.title = nz(t.gecko ? t.geckoTitle : t.webTitle, t.url);
            showContent();
            updateToolbar();
            refreshTabViews();
        }
    }

    void goForward() {
        Tab t = current;
        if (t == null || t.isNewTab) return;
        if (t.gecko) { if (t.canFwd && t.session != null) t.session.goForward(); }
        else if (t.web != null && t.web.canGoForward()) t.web.goForward();
    }

    void reload() {
        if (current == null) return;
        if (current.isNewTab) refreshNewTab();
        else if (current.gecko && current.session != null) current.session.reload();
        else if (!current.gecko && current.web != null) current.web.reload();
    }

    void goHome() {
        if (current == null) return;
        current.isNewTab = true;
        showContent();
        updateToolbar();
        refreshTabViews();
    }

    void updateToolbar() {
        Tab t = current;
        if (t == null) return;
        if (!address.hasFocus()) address.setText(t.url());
        backBtn.setAlpha(canGoBack(t) ? 1f : 0.35f);
        boolean fwd = !t.isNewTab && (t.gecko ? t.canFwd : (t.web != null && t.web.canGoForward()));
        fwdBtn.setAlpha(fwd ? 1f : 0.35f);
        String u = t.url();
        boolean bm = !u.isEmpty() && bookmarkIndex(u) >= 0;
        starBtn.setText(bm ? "★" : "☆");
        starBtn.setTextColor(bm ? C_ACCENT : C_TEXT);
        updateShield();
        progress.setProgress(t.progress);
        progress.setVisibility(!t.isNewTab && t.progress < 100 ? View.VISIBLE : View.INVISIBLE);
    }

    void updateShield() {
        if (current == null) return;
        int n = current.isNewTab ? 0 : current.blocked.get();
        shieldBtn.setText(adBlock && n > 0 ? "🛡 " + n : "🛡");
        shieldBtn.setAlpha(adBlock ? 1f : 0.35f);
    }

    void applyChrome() {
        boolean fs = current != null && current.fullscreen && !current.isNewTab;
        int vis = fs ? View.GONE : View.VISIBLE;
        tabBar.setVisibility(vis);
        toolBar.setVisibility(vis);
        bmScroll.setVisibility(vis);
        progress.setVisibility(fs ? View.GONE : (current != null && !current.isNewTab
                && current.progress < 100 ? View.VISIBLE : View.INVISIBLE));
        setSystemBars(!fs);
    }

    @SuppressWarnings("deprecation")
    void setSystemBars(boolean show) {
        if (Build.VERSION.SDK_INT >= 30) {
            WindowInsetsController c = getWindow().getInsetsController();
            if (c == null) return;
            if (show) {
                c.show(WindowInsets.Type.systemBars());
            } else {
                c.hide(WindowInsets.Type.systemBars());
                c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        } else {
            getWindow().getDecorView().setSystemUiVisibility(show ? 0
                    : (View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY));
        }
    }

    // ------------------------------------------------------------------ motor oturumu

    // ------------------------------------------------------------------ hızlı motor (Android'in kendi motoru)

    WebView createWebView(final Tab t) {
        WebView w = new WebView(this);
        WebSettings st = w.getSettings();
        st.setJavaScriptEnabled(true);
        st.setDomStorageEnabled(true);
        st.setDatabaseEnabled(true);
        st.setUserAgentString(CHROME_UA);
        st.setUseWideViewPort(true);
        st.setLoadWithOverviewMode(true);
        st.setSupportZoom(true);
        st.setBuiltInZoomControls(true);
        st.setDisplayZoomControls(false);
        st.setSupportMultipleWindows(true);
        st.setJavaScriptCanOpenWindowsAutomatically(true);
        st.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        st.setLayoutAlgorithm(WebSettings.LayoutAlgorithm.NORMAL);
        st.setTextZoom(100);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(w, true);
        w.setBackgroundColor(Color.WHITE);
        w.setScrollbarFadingEnabled(false);

        w.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                String u = r.getUrl().toString();
                if (r.isForMainFrame() && useGeckoFor(u)) {
                    ui.post(() -> load(t, u));
                    return true;
                }
                String sc = r.getUrl().getScheme();
                if (sc == null) return false;
                sc = sc.toLowerCase(Locale.ROOT);
                if (sc.equals("http") || sc.equals("https") || sc.equals("about") || sc.equals("data")
                        || sc.equals("blob") || sc.equals("javascript") || sc.equals("file")) {
                    return false;
                }
                final Uri uri = r.getUrl();
                ui.post(() -> openSpecial(uri));
                return true;
            }

            @Override
            public void onPageStarted(WebView v, String url, Bitmap favicon) {
                if (url != null) t.webUrl = url;
                if (t.gecko) return;
                t.blocked.set(0);
                t.progress = 5;
                if (url != null) t.url = url;
                startTimer(t);
                if (spViewport) v.evaluateJavascript(viewportJs(), null);
                if (t == current) updateToolbar();
            }

            @Override
            public void onPageCommitVisible(WebView v, String url) {
                if (spViewport) v.evaluateJavascript(viewportJs(), null);
            }

            @Override
            public void onPageFinished(WebView v, String url) {
                if (t.gecko) return;
                t.progress = 100;
                stopTimer(t, "hızlı motor");
                if (url != null && url.startsWith("http")) {
                    if (spViewport) v.evaluateJavascript(viewportJs(), null);
                    if (adBlock) v.evaluateJavascript(HIDE_JS, null);
                    addHistory(v.getTitle(), url);
                }
                if (t == current) updateToolbar();
                CookieManager.getInstance().flush();
            }

            @Override
            public void doUpdateVisitedHistory(WebView v, String url, boolean isReload) {
                if (url != null) t.webUrl = url;
                if (t.gecko) return;
                if (url != null) t.url = url;
                if (t == current) updateToolbar();
            }

            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                if (adBlock && !r.isForMainFrame() && isAdHost(r.getUrl().getHost())) {
                    t.blocked.incrementAndGet();
                    ui.post(() -> { if (t == current && !t.gecko) updateShield(); });
                    return new WebResourceResponse("text/plain", "utf-8",
                            new ByteArrayInputStream(new byte[0]));
                }
                return null;
            }

            @Override
            public boolean onRenderProcessGone(WebView v, RenderProcessGoneDetail detail) {
                ui.post(() -> recreateWeb(t));
                return true;
            }
        });

        w.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView v, int p) {
                if (t.gecko) return;
                t.progress = p;
                if (t == current && !t.isNewTab) {
                    progress.setProgress(p);
                    progress.setVisibility(p < 100 ? View.VISIBLE : View.INVISIBLE);
                }
            }

            @Override
            public void onReceivedTitle(WebView v, String title) {
                t.webTitle = title;
                if (t.gecko) return;
                t.title = title;
                refreshTabViews();
            }

            @Override
            public boolean onCreateWindow(WebView v, boolean isDialog, boolean isUserGesture, Message msg) {
                if (adBlock && !isUserGesture) return false;
                Tab nt = new Tab();
                nt.isNewTab = false;
                createWebView(nt);
                int idx = current != null ? tabs.indexOf(current) + 1 : tabs.size();
                tabs.add(idx, nt);
                buildTabView(nt);
                tabStrip.addView(nt.view, idx);
                WebView.WebViewTransport tr = (WebView.WebViewTransport) msg.obj;
                tr.setWebView(nt.web);
                msg.sendToTarget();
                selectTab(nt);
                return true;
            }

            @Override
            public void onCloseWindow(WebView v) {
                ui.post(() -> closeTab(t));
            }

            @Override
            public void onShowCustomView(View view, CustomViewCallback callback) {
                showFullscreen(view, callback);
            }

            @Override
            public void onHideCustomView() {
                hideFullscreen();
            }

            @Override
            public Bitmap getDefaultVideoPoster() {
                return Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888);
            }

            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams params) {
                if (webFileCb != null) webFileCb.onReceiveValue(null);
                webFileCb = cb;
                try {
                    Intent i = params.createIntent();
                    if (params.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE) {
                        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                    }
                    startActivityForResult(i, REQ_FILE_WEB);
                } catch (Exception e) {
                    webFileCb = null;
                    return false;
                }
                return true;
            }
        });

        w.setDownloadListener((url, ua, cd, mime, len) -> startDmDownload(url, ua, cd, mime));
        w.setOnLongClickListener(v -> onWebLongPress(t));
        w.setOnContextClickListener(v -> onWebLongPress(t));
        w.setVisibility(View.GONE);
        t.web = w;
        webContainer.addView(w, 0, new FrameLayout.LayoutParams(-1, -1));
        return w;
    }

    boolean onWebLongPress(Tab t) {
        if (t.web == null) return false;
        WebView.HitTestResult r = t.web.getHitTestResult();
        if (r == null) return false;
        int type = r.getType();
        String extra = r.getExtra();
        if (extra == null) return false;
        if (type == WebView.HitTestResult.SRC_ANCHOR_TYPE) {
            linkMenu(extra, null);
            return true;
        }
        if (type == WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE) {
            Message m = ui.obtainMessage();
            t.web.requestFocusNodeHref(m);
            String link = m.getData().getString("url");
            linkMenu(link != null && !link.isEmpty() ? link : extra, extra);
            return true;
        }
        if (type == WebView.HitTestResult.IMAGE_TYPE) {
            linkMenu(null, extra);
            return true;
        }
        return false;
    }

    /** Sayfaya bilgisayar ekranı genişliği verir (yakınlaştırma ayarıyla). */
    String viewportJs() {
        float d = getResources().getDisplayMetrics().density;
        int px = webContainer.getWidth();
        if (px <= 0) px = getResources().getDisplayMetrics().widthPixels;
        int css = Math.max(320, Math.round(px / d));
        int w = Math.round(css * 100f / zoom);
        String sc = String.format(Locale.US, "%.4f", css / (float) w);
        return "(function(){window.__mdvpC='width=" + w + ", initial-scale=" + sc
                + ", minimum-scale=" + sc + ", user-scalable=yes';"
                + "function ap(){var c=window.__mdvpC;var h=document.head;if(!h)return;"
                + "var ms=document.querySelectorAll('meta[name=\"viewport\"]');"
                + "if(!ms.length){var m=document.createElement('meta');m.name='viewport';h.appendChild(m);ms=[m];}"
                + "for(var i=0;i<ms.length;i++){if(ms[i].getAttribute('content')!==c)ms[i].setAttribute('content',c);}"
                + "if(!window.__mdvpO){try{window.__mdvpO=new MutationObserver(ap);"
                + "window.__mdvpO.observe(h,{childList:true});}catch(e){}}}"
                + "ap();setTimeout(ap,60);setTimeout(ap,600);"
                + "if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',ap);})();";
    }

    void applyViewportAll() {
        if (!spViewport) return;
        String js = viewportJs();
        for (Tab t : tabs) {
            if (t.web != null && t.webUrl != null) t.web.evaluateJavascript(js, null);
        }
    }

    void showFullscreen(View v, WebChromeClient.CustomViewCallback cb) {
        if (customView != null) {
            cb.onCustomViewHidden();
            return;
        }
        customView = v;
        customCb = cb;
        fullContainer.addView(v, new FrameLayout.LayoutParams(-1, -1));
        fullContainer.setVisibility(View.VISIBLE);
        mainLayout.setVisibility(View.GONE);
        setSystemBars(false);
    }

    void hideFullscreen() {
        if (customView == null) return;
        fullContainer.removeView(customView);
        fullContainer.setVisibility(View.GONE);
        mainLayout.setVisibility(View.VISIBLE);
        customView = null;
        setSystemBars(true);
        WebChromeClient.CustomViewCallback cb = customCb;
        customCb = null;
        if (cb != null) cb.onCustomViewHidden();
    }

    /** Hızlı motordaki indirmeler Android'in indirme yöneticisiyle yapılır. */
    void startDmDownload(String url, String ua, String cd, String mime) {
        if (url == null || !(url.startsWith("http://") || url.startsWith("https://"))) {
            toast("Bu dosya bu şekilde indirilemiyor");
            return;
        }
        try {
            String name = URLUtil.guessFileName(url, cd, mime);
            DownloadManager.Request req = new DownloadManager.Request(Uri.parse(url));
            if (mime != null && !mime.isEmpty()) req.setMimeType(mime);
            String cookie = CookieManager.getInstance().getCookie(url);
            if (cookie != null) req.addRequestHeader("Cookie", cookie);
            req.addRequestHeader("User-Agent", ua != null ? ua : CHROME_UA);
            req.setTitle(name);
            req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name);
            DownloadManager dm = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
            long dmId = dm.enqueue(req);
            long id = System.currentTimeMillis();
            addDownload(id, name, mime);
            JSONArray a = getArr("downloads");
            JSONObject o = a.optJSONObject(0);
            if (o != null && o.optLong("id") == id) {
                o.put("dm", dmId);
                putArr("downloads", a);
            }
            toast("İndiriliyor: " + name);
        } catch (Exception e) {
            toast("İndirme başlatılamadı");
        }
    }

    int dmStatus(long dmId) {
        DownloadManager dm = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
        try (Cursor c = dm.query(new DownloadManager.Query().setFilterById(dmId))) {
            if (c != null && c.moveToFirst()) {
                int st = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS));
                if (st == DownloadManager.STATUS_SUCCESSFUL) return 1;
                if (st == DownloadManager.STATUS_FAILED) return 2;
                return 0;
            }
        } catch (Exception ignored) { }
        return 2;
    }

    GeckoSession createSession(final Tab t, boolean open) {
        ensureRuntime();
        GeckoSessionSettings ss = new GeckoSessionSettings.Builder()
                .usePrivateMode(false)
                .useTrackingProtection(adBlock)
                .userAgentMode(GeckoSessionSettings.USER_AGENT_MODE_DESKTOP)
                .userAgentOverride(desktopUa)
                .viewportMode(GeckoSessionSettings.VIEWPORT_MODE_MOBILE)
                .allowJavascript(true)
                .build();
        GeckoSession s = new GeckoSession(ss);
        s.setNavigationDelegate(new Nav(t));
        s.setProgressDelegate(new Prog(t));
        s.setContentDelegate(new Content(t));
        s.setPromptDelegate(new Prompts());
        s.setPermissionDelegate(new Perms());
        s.setContentBlockingDelegate(new Blocking(t));
        s.setSelectionActionDelegate(new BasicSelectionActionDelegate(this));
        if (open) s.open(runtime);
        return s;
    }

    void locationChanged(Tab t, String url) {
        if (url == null) return;
        if (url.equals("about:blank") && t.geckoUrl != null && !t.geckoUrl.isEmpty()) return;
        t.geckoUrl = url;
        if (!t.gecko) return;
        t.url = url;
        if (t == current) updateToolbar();
    }

    class Nav implements GeckoSession.NavigationDelegate {
        final Tab t;

        Nav(Tab t) { this.t = t; }

        public void onLocationChange(GeckoSession s, String url,
                                     List<GeckoSession.PermissionDelegate.ContentPermission> perms) {
            locationChanged(t, url);
        }

        public void onLocationChange(GeckoSession s, String url,
                                     List<GeckoSession.PermissionDelegate.ContentPermission> perms,
                                     Boolean hasUserGesture) {
            locationChanged(t, url);
        }

        public void onCanGoBack(GeckoSession s, boolean can) {
            t.canBack = can;
            if (t == current) updateToolbar();
        }

        public void onCanGoForward(GeckoSession s, boolean can) {
            t.canFwd = can;
            if (t == current) updateToolbar();
        }

        public GeckoResult<AllowOrDeny> onLoadRequest(GeckoSession s, LoadRequest r) {
            final Uri u = Uri.parse(r.uri);
            String sc = u.getScheme();
            if (sc == null) return GeckoResult.fromValue(AllowOrDeny.ALLOW);
            sc = sc.toLowerCase(Locale.ROOT);
            // Google dışı bir siteye tıklanınca o sekme hızlı motora geçer.
            if ((sc.equals("http") || sc.equals("https")) && r.hasUserGesture && !r.isRedirect
                    && r.target == TARGET_WINDOW_CURRENT && !isGoogleAccountUrl(r.uri)) {
                final String target = r.uri;
                ui.post(() -> load(t, target));
                return GeckoResult.fromValue(AllowOrDeny.DENY);
            }
            switch (sc) {
                case "http": case "https": case "about": case "data": case "blob": case "file":
                case "resource": case "moz-extension": case "javascript": case "view-source":
                    return GeckoResult.fromValue(AllowOrDeny.ALLOW);
                default:
                    ui.post(() -> openSpecial(u));
                    return GeckoResult.fromValue(AllowOrDeny.DENY);
            }
        }

        public GeckoResult<GeckoSession> onNewSession(GeckoSession s, String uri) {
            Tab nt = new Tab();
            nt.isNewTab = false;
            nt.gecko = true;
            nt.url = uri;
            nt.geckoUrl = uri;
            nt.session = createSession(nt, false);
            int idx = current != null ? tabs.indexOf(current) + 1 : tabs.size();
            tabs.add(idx, nt);
            buildTabView(nt);
            tabStrip.addView(nt.view, idx);
            selectTab(nt);
            return GeckoResult.fromValue(nt.session);
        }

        public GeckoResult<String> onLoadError(GeckoSession s, String uri, WebRequestError error) {
            String html = "<!DOCTYPE html><html lang='tr'><head><meta charset='utf-8'>"
                    + "<meta name='viewport' content='width=device-width,initial-scale=1'>"
                    + "<title>Sayfa açılamadı</title><style>body{font-family:sans-serif;background:#1c1c1f;"
                    + "color:#ededf0;display:flex;align-items:center;justify-content:center;height:90vh;margin:0}"
                    + "div{max-width:560px;padding:24px}h1{font-weight:300;font-size:34px}"
                    + "p{color:#9c9ca5;line-height:1.5}</style></head><body><div><h1>Sayfa açılamadı</h1>"
                    + "<p>İnternet bağlantını ve adresi kontrol edip ↻ düğmesiyle yeniden dene.</p></div></body></html>";
            return GeckoResult.fromValue("data:text/html;charset=utf-8," + Uri.encode(html));
        }
    }

    class Prog implements GeckoSession.ProgressDelegate {
        final Tab t;

        Prog(Tab t) { this.t = t; }

        public void onPageStart(GeckoSession s, String url) {
            if (url != null && !url.equals("about:blank")) t.geckoUrl = url;
            if (!t.gecko) return;
            t.blocked.set(0);
            t.progress = 5;
            startTimer(t);
            if (url != null && !url.equals("about:blank")) t.url = url;
            if (t == current) updateToolbar();
        }

        public void onPageStop(GeckoSession s, boolean success) {
            if (!t.gecko) return;
            t.progress = 100;
            stopTimer(t, "Firefox motoru");
            if (success && t.url != null && t.url.startsWith("http")) addHistory(t.title, t.url);
            if (t == current) updateToolbar();
        }

        public void onProgressChange(GeckoSession s, int p) {
            if (!t.gecko) return;
            t.progress = p;
            if (t == current && !t.isNewTab) {
                progress.setProgress(p);
                progress.setVisibility(p < 100 ? View.VISIBLE : View.INVISIBLE);
            }
        }
    }

    class Content implements GeckoSession.ContentDelegate {
        final Tab t;

        Content(Tab t) { this.t = t; }

        public void onTitleChange(GeckoSession s, String title) {
            t.geckoTitle = title;
            if (!t.gecko) return;
            t.title = title;
            refreshTabViews();
            if (t.url != null && t.url.startsWith("http") && title != null && !title.isEmpty()) {
                addHistory(title, t.url);
            }
        }

        public void onFullScreen(GeckoSession s, boolean fullScreen) {
            t.fullscreen = fullScreen;
            if (t == current) applyChrome();
        }

        public void onContextMenu(GeckoSession s, int screenX, int screenY, ContextElement e) {
            String link = e.linkUri;
            String img = e.type == ContextElement.TYPE_IMAGE ? e.srcUri : null;
            if (link != null || img != null) linkMenu(link, img);
        }

        public void onExternalResponse(GeckoSession s, WebResponse response) {
            saveResponse(response);
        }

        public void onCloseRequest(GeckoSession s) {
            ui.post(() -> closeTab(t));
        }

        public void onCrash(GeckoSession s) {
            ui.post(() -> recreateSession(t));
        }

        public void onKill(GeckoSession s) {
            ui.post(() -> recreateSession(t));
        }
    }

    class Blocking implements ContentBlocking.Delegate {
        final Tab t;

        Blocking(Tab t) { this.t = t; }

        public void onContentBlocked(GeckoSession s, ContentBlocking.BlockEvent event) {
            if (!t.gecko) return;
            t.blocked.incrementAndGet();
            if (t == current) updateShield();
        }
    }

    class Perms implements GeckoSession.PermissionDelegate {
        public GeckoResult<Integer> onContentPermissionRequest(GeckoSession s, ContentPermission perm) {
            int p = perm.permission;
            boolean allow = p == PERMISSION_AUTOPLAY_AUDIBLE || p == PERMISSION_AUTOPLAY_INAUDIBLE
                    || p == PERMISSION_PERSISTENT_STORAGE || p == PERMISSION_STORAGE_ACCESS
                    || p == PERMISSION_MEDIA_KEY_SYSTEM_ACCESS;
            return GeckoResult.fromValue(allow ? ContentPermission.VALUE_ALLOW : ContentPermission.VALUE_DENY);
        }
    }

    // ------------------------------------------------------------------ sitelerin açtığı pencereler (seçim kutuları, uyarılar…)

    static class Once {
        final GeckoResult<PromptResponse> r;
        boolean done;

        Once(GeckoResult<PromptResponse> r) { this.r = r; }

        void finish(PromptResponse v) {
            if (done) return;
            done = true;
            r.complete(v);
        }
    }

    class Prompts implements GeckoSession.PromptDelegate {

        public GeckoResult<PromptResponse> onAlertPrompt(GeckoSession s, AlertPrompt p) {
            GeckoResult<PromptResponse> r = new GeckoResult<>();
            final Once o = new Once(r);
            dlg().setTitle(nz(p.title, "Sayfadan mesaj"))
                    .setMessage(nz(p.message, ""))
                    .setPositiveButton("Tamam", (d, w) -> o.finish(p.dismiss()))
                    .setOnDismissListener(d -> o.finish(p.dismiss()))
                    .show();
            return r;
        }

        public GeckoResult<PromptResponse> onButtonPrompt(GeckoSession s, ButtonPrompt p) {
            GeckoResult<PromptResponse> r = new GeckoResult<>();
            final Once o = new Once(r);
            dlg().setTitle(nz(p.title, "Sayfadan soru"))
                    .setMessage(nz(p.message, ""))
                    .setPositiveButton("Tamam", (d, w) -> o.finish(p.confirm(ButtonPrompt.Type.POSITIVE)))
                    .setNegativeButton("İptal", (d, w) -> o.finish(p.confirm(ButtonPrompt.Type.NEGATIVE)))
                    .setOnDismissListener(d -> o.finish(p.dismiss()))
                    .show();
            return r;
        }

        public GeckoResult<PromptResponse> onTextPrompt(GeckoSession s, TextPrompt p) {
            GeckoResult<PromptResponse> r = new GeckoResult<>();
            final Once o = new Once(r);
            final EditText et = new EditText(MainActivity.this);
            et.setSingleLine(true);
            et.setText(nz(p.defaultValue, ""));
            FrameLayout box = new FrameLayout(MainActivity.this);
            box.setPadding(dp(20), dp(8), dp(20), 0);
            box.addView(et);
            dlg().setTitle(nz(p.title, "Sayfadan soru"))
                    .setMessage(nz(p.message, ""))
                    .setView(box)
                    .setPositiveButton("Tamam", (d, w) -> o.finish(p.confirm(et.getText().toString())))
                    .setNegativeButton("İptal", (d, w) -> o.finish(p.dismiss()))
                    .setOnDismissListener(d -> o.finish(p.dismiss()))
                    .show();
            return r;
        }

        public GeckoResult<PromptResponse> onAuthPrompt(GeckoSession s, AuthPrompt p) {
            GeckoResult<PromptResponse> r = new GeckoResult<>();
            final Once o = new Once(r);
            LinearLayout box = new LinearLayout(MainActivity.this);
            box.setOrientation(LinearLayout.VERTICAL);
            box.setPadding(dp(20), dp(8), dp(20), 0);
            final EditText user = new EditText(MainActivity.this);
            user.setHint("Kullanıcı adı");
            user.setSingleLine(true);
            final EditText pass = new EditText(MainActivity.this);
            pass.setHint("Şifre");
            pass.setSingleLine(true);
            pass.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
            box.addView(user);
            box.addView(pass);
            dlg().setTitle(nz(p.title, "Giriş gerekli"))
                    .setMessage(nz(p.message, ""))
                    .setView(box)
                    .setPositiveButton("Giriş", (d, w) -> o.finish(
                            p.confirm(user.getText().toString(), pass.getText().toString())))
                    .setNegativeButton("İptal", (d, w) -> o.finish(p.dismiss()))
                    .setOnDismissListener(d -> o.finish(p.dismiss()))
                    .show();
            return r;
        }

        public GeckoResult<PromptResponse> onChoicePrompt(GeckoSession s, ChoicePrompt p) {
            GeckoResult<PromptResponse> r = new GeckoResult<>();
            final Once o = new Once(r);
            final ArrayList<ChoicePrompt.Choice> flat = new ArrayList<>();
            flatten(p.choices, flat, "");
            if (flat.isEmpty()) {
                o.finish(p.dismiss());
                return r;
            }
            String[] labels = new String[flat.size()];
            for (int i = 0; i < flat.size(); i++) labels[i] = nz(flat.get(i).label, " ");
            AlertDialog.Builder b = dlg();
            if (p.title != null && !p.title.isEmpty()) b.setTitle(p.title);
            if (p.type == ChoicePrompt.Type.MULTIPLE) {
                final boolean[] checked = new boolean[flat.size()];
                for (int i = 0; i < flat.size(); i++) checked[i] = flat.get(i).selected;
                b.setMultiChoiceItems(labels, checked, (d, which, isChecked) -> checked[which] = isChecked)
                        .setPositiveButton("Tamam", (d, w) -> {
                            ArrayList<String> ids = new ArrayList<>();
                            for (int i = 0; i < flat.size(); i++) if (checked[i]) ids.add(flat.get(i).id);
                            o.finish(p.confirm(ids.toArray(new String[0])));
                        })
                        .setNegativeButton("İptal", (d, w) -> o.finish(p.dismiss()));
            } else {
                int sel = -1;
                for (int i = 0; i < flat.size(); i++) if (flat.get(i).selected) sel = i;
                b.setSingleChoiceItems(labels, sel, (d, which) -> {
                    o.finish(p.confirm(flat.get(which).id));
                    d.dismiss();
                });
            }
            b.setOnDismissListener(d -> o.finish(p.dismiss())).show();
            return r;
        }

        public GeckoResult<PromptResponse> onFilePrompt(GeckoSession s, FilePrompt p) {
            GeckoResult<PromptResponse> r = new GeckoResult<>();
            if (pendingFile != null && pendingFileResult != null) {
                pendingFileResult.complete(pendingFile.dismiss());
            }
            Intent i = new Intent(Intent.ACTION_GET_CONTENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            String[] mimes = p.mimeTypes;
            if (mimes != null && mimes.length == 1 && mimes[0] != null && !mimes[0].isEmpty()) {
                i.setType(mimes[0]);
            } else {
                i.setType("*/*");
                if (mimes != null && mimes.length > 1) i.putExtra(Intent.EXTRA_MIME_TYPES, mimes);
            }
            if (p.type == FilePrompt.Type.MULTIPLE) i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
            pendingFile = p;
            pendingFileResult = r;
            try {
                startActivityForResult(i, REQ_FILE);
            } catch (Exception e) {
                pendingFile = null;
                pendingFileResult = null;
                r.complete(p.dismiss());
            }
            return r;
        }
    }

    void flatten(ChoicePrompt.Choice[] in, ArrayList<ChoicePrompt.Choice> out, String prefix) {
        if (in == null) return;
        for (ChoicePrompt.Choice c : in) {
            if (c == null || c.separator) continue;
            if (c.items != null && c.items.length > 0) {
                flatten(c.items, out, prefix);
            } else if (!c.disabled) {
                out.add(c);
            }
        }
    }

    void openSpecial(Uri u) {
        try {
            String sc = u.getScheme() == null ? "" : u.getScheme().toLowerCase(Locale.ROOT);
            if (sc.equals("intent")) {
                Intent in = Intent.parseUri(u.toString(), Intent.URI_INTENT_SCHEME);
                in.addCategory(Intent.CATEGORY_BROWSABLE);
                in.setComponent(null);
                in.setSelector(null);
                try {
                    startActivity(in);
                } catch (Exception e) {
                    String fb = in.getStringExtra("browser_fallback_url");
                    if (fb != null && fb.startsWith("http")) load(current, fb);
                    else toast("Bu bağlantıyı açacak uygulama yok");
                }
                return;
            }
            Intent in = new Intent(Intent.ACTION_VIEW, u);
            in.addCategory(Intent.CATEGORY_BROWSABLE);
            startActivity(in);
        } catch (Exception e) {
            toast("Bu bağlantıyı açacak uygulama yok");
        }
    }

    void linkMenu(final String link, final String img) {
        ArrayList<String> labels = new ArrayList<>();
        ArrayList<Runnable> acts = new ArrayList<>();
        if (link != null) {
            labels.add("Yeni sekmede aç");
            acts.add(() -> newTab(link, true, true));
            labels.add("Arka planda yeni sekmede aç");
            acts.add(() -> newTab(link, false, true));
            labels.add("Bağlantıyı kopyala");
            acts.add(() -> copy(link));
        }
        if (img != null) {
            labels.add("Resmi yeni sekmede aç");
            acts.add(() -> newTab(img, true, true));
            labels.add("Resmi indir");
            acts.add(() -> {
                if (current != null && !current.gecko) startDmDownload(img, CHROME_UA, null, null);
                else downloadUrl(img);
            });
        }
        String title = link != null ? link : img;
        if (title.length() > 90) title = title.substring(0, 90) + "…";
        dlg().setTitle(title)
                .setItems(labels.toArray(new String[0]), (d, which) -> acts.get(which).run())
                .show();
    }

    void copy(String s) {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("bağlantı", s));
        toast("Kopyalandı");
    }

    void openExternal(String url) {
        if (url == null || url.isEmpty()) {
            toast("Açılacak bir sayfa yok");
            return;
        }
        Intent chooser = Intent.createChooser(new Intent(Intent.ACTION_VIEW, Uri.parse(url)),
                "Hangi tarayıcıda açılsın?");
        chooser.putExtra(Intent.EXTRA_EXCLUDE_COMPONENTS,
                new ComponentName[]{new ComponentName(this, MainActivity.class)});
        try {
            startActivity(chooser);
        } catch (Exception e) {
            toast("Başka bir tarayıcı bulunamadı");
        }
    }

    // ------------------------------------------------------------------ menü

    void showMenu(View anchor) {
        PopupMenu pm = new PopupMenu(this, anchor);
        Menu m = pm.getMenu();
        m.add(0, 1, 0, "Yeni sekme");
        m.add(0, 2, 1, "Yer imleri");
        m.add(0, 3, 2, "Geçmiş");
        m.add(0, 4, 3, "İndirilenler");
        MenuItem ab = m.add(0, 5, 4, "Reklam engelleyici");
        ab.setCheckable(true);
        ab.setChecked(adBlock);
        m.add(0, 8, 5, "Sayfa yakınlaştırma (%" + zoom + ")");
        m.add(0, 10, 5, "Hız ayarları");
        m.add(0, 9, 6, "Bu sayfayı başka tarayıcıda aç");
        m.add(0, 6, 7, "Çerezleri ve site verilerini temizle");
        m.add(0, 7, 8, "Klavye kısayolları");
        pm.setOnMenuItemClickListener(it -> {
            switch (it.getItemId()) {
                case 1: newTab(null, true, false); break;
                case 2: bookmarksDialog(); break;
                case 3: historyDialog(); break;
                case 4: downloadsDialog(); break;
                case 5: setAdBlock(!adBlock); break;
                case 6: clearDataDialog(); break;
                case 7: shortcutsDialog(); break;
                case 8: zoomDialog(); break;
                case 9: openExternal(current == null ? "" : current.url()); break;
                case 10: speedDialog(); break;
                default: break;
            }
            return true;
        });
        pm.show();
    }

    void shortcutsDialog() {
        dlg().setTitle("Klavye kısayolları")
                .setMessage("Ctrl+T  Yeni sekme\nCtrl+W  Sekmeyi kapat\nCtrl+Tab  Sonraki sekme\n"
                        + "Ctrl+Shift+Tab  Önceki sekme\nCtrl+L  Adres çubuğu\nCtrl+R veya F5  Yenile\n"
                        + "Ctrl+D  Yer imi ekle/kaldır\nCtrl+H  Geçmiş\nCtrl+J  İndirilenler\n"
                        + "Alt+Sol/Sağ ok  Geri/İleri")
                .setPositiveButton("Tamam", null).show();
    }

    void clearDataDialog() {
        dlg().setTitle("Çerezleri ve site verilerini temizle")
                .setMessage("Tüm sitelerden çıkış yapılır ve kayıtlı site verileri silinir. Yer imleri, "
                        + "geçmiş ve yeni sekme kutucukları korunur.")
                .setPositiveButton("Temizle", (d, w) -> {
                    if (runtime != null) runtime.getStorageController().clearData(StorageController.ClearFlags.ALL);
                    CookieManager.getInstance().removeAllCookies(null);
                    WebStorage.getInstance().deleteAllData();
                    for (Tab t : tabs) if (t.web != null) t.web.clearCache(true);
                    toast("Çerezler ve site verileri temizlendi");
                })
                .setNegativeButton("İptal", null).show();
    }

    void zoomDialog() {
        String[] labels = new String[ZOOMS.length];
        int checked = 0;
        for (int i = 0; i < ZOOMS.length; i++) {
            labels[i] = "%" + ZOOMS[i] + (ZOOMS[i] == 100 ? "  (önerilen)" : "");
            if (ZOOMS[i] == zoom) checked = i;
        }
        dlg().setTitle("Sayfa yakınlaştırma")
                .setSingleChoiceItems(labels, checked, (d, which) -> {
                    d.dismiss();
                    zoom = ZOOMS[which];
                    prefs.edit().putInt("zoom_v2", zoom).apply();
                    applyViewportAll();
                    toast("Yakınlaştırma: %" + zoom);
                })
                .setNegativeButton("Kapat", null).show();
    }

    // ------------------------------------------------------------------ reklam engelleyici

    void adBlockDialog() {
        int n = current == null ? 0 : current.blocked.get();
        dlg().setTitle("Reklam engelleyici")
                .setMessage(adBlock
                        ? "Açık. Bu sayfada " + n + " reklam ve izleyici engellendi."
                        : "Kapalı. Reklamlar ve izleyiciler engellenmiyor.")
                .setPositiveButton(adBlock ? "Kapat" : "Aç", (d, w) -> setAdBlock(!adBlock))
                .setNegativeButton("Tamam", null).show();
    }

    void setAdBlock(boolean on) {
        adBlock = on;
        prefs.edit().putBoolean("adblock", on).apply();
        if (runtime != null) try {
            ContentBlocking.Settings cb = runtime.getSettings().getContentBlocking();
            cb.setAntiTracking(on ? AT_ON : ContentBlocking.AntiTracking.NONE);
            cb.setEnhancedTrackingProtectionLevel(on ? ContentBlocking.EtpLevel.DEFAULT
                    : ContentBlocking.EtpLevel.NONE);
        } catch (Exception ignored) { }
        for (Tab t : tabs) {
            if (t.session != null) t.session.getSettings().setUseTrackingProtection(on);
        }
        setExtEnabled(on);
        toast(on ? "Reklam engelleyici açıldı" : "Reklam engelleyici kapatıldı");
        if (current != null && !current.isNewTab) reload();
        updateShield();
    }

    // ------------------------------------------------------------------ kayıtlı veriler

    JSONArray getArr(String key) {
        try {
            return new JSONArray(prefs.getString(key, "[]"));
        } catch (JSONException e) {
            return new JSONArray();
        }
    }

    void putArr(String key, JSONArray a) {
        prefs.edit().putString(key, a.toString()).apply();
    }

    String fmtTime(long ms) {
        return new SimpleDateFormat("d MMM HH:mm", new Locale("tr", "TR")).format(new Date(ms));
    }

    void saveSession() {
        JSONArray a = new JSONArray();
        int sel = 0;
        for (Tab t : tabs) {
            String u = t.url();
            if (u.isEmpty()) u = "newtab";
            if (t == current) sel = a.length();
            JSONObject o = new JSONObject();
            try {
                o.put("u", u);
                o.put("t", t.title == null ? "" : t.title);
            } catch (JSONException ignored) { }
            a.put(o);
        }
        prefs.edit().putString("session", a.toString()).putInt("sessionIdx", sel).apply();
    }

    void restoreSession() {
        JSONArray a = getArr("session");
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o == null) continue;
            String u = o.optString("u");
            if (u.isEmpty()) continue;
            Tab t = newTab(null, false, false);
            if (!u.equals("newtab") && !u.startsWith("https://accounts.google.com/")) {
                t.pendingUrl = u;
                t.isNewTab = false;
                t.url = u;
                t.title = o.optString("t", u);
            }
        }
        if (tabs.isEmpty()) {
            newTab(null, true, false);
        } else {
            int idx = Math.min(Math.max(prefs.getInt("sessionIdx", 0), 0), tabs.size() - 1);
            selectTab(tabs.get(idx));
        }
    }

    // Geçmiş

    void addHistory(String title, String url) {
        JSONArray a = getArr("history");
        JSONArray n = new JSONArray();
        JSONObject o = new JSONObject();
        try {
            o.put("t", (title == null || title.isEmpty()) ? url : title);
            o.put("u", url);
            o.put("time", System.currentTimeMillis());
        } catch (JSONException ignored) { }
        n.put(o);
        for (int i = 0; i < a.length() && n.length() < 500; i++) {
            JSONObject x = a.optJSONObject(i);
            if (x != null && !url.equals(x.optString("u"))) n.put(x);
        }
        putArr("history", n);
    }

    void historyDialog() {
        final JSONArray a = getArr("history");
        if (a.length() == 0) {
            toast("Geçmiş boş");
            return;
        }
        String[] items = new String[a.length()];
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            items[i] = o == null ? "" : o.optString("t") + "\n" + fmtTime(o.optLong("time"))
                    + "   " + o.optString("u");
        }
        dlg().setTitle("Geçmiş")
                .setItems(items, (d, which) -> {
                    JSONObject o = a.optJSONObject(which);
                    if (o != null) load(current, o.optString("u"));
                })
                .setNeutralButton("Geçmişi temizle", (d, w) -> {
                    putArr("history", new JSONArray());
                    toast("Geçmiş temizlendi");
                })
                .setNegativeButton("Kapat", null).show();
    }

    // Yer imleri

    int bookmarkIndex(String url) {
        JSONArray a = getArr("bookmarks");
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o != null && url.equals(o.optString("u"))) return i;
        }
        return -1;
    }

    void toggleBookmark() {
        if (current == null) return;
        String url = current.url();
        if (url.isEmpty()) {
            toast("Yeni sekme sayfası yer imlerine eklenemez");
            return;
        }
        int idx = bookmarkIndex(url);
        if (idx >= 0) {
            removeBookmark(idx);
            toast("Yer imi kaldırıldı");
            return;
        }
        editBookmark(-1, tabTitle(current), url);
    }

    void removeBookmark(int idx) {
        JSONArray a = getArr("bookmarks");
        if (idx >= 0 && idx < a.length()) a.remove(idx);
        putArr("bookmarks", a);
        refreshBookmarkBar();
        updateToolbar();
    }

    void editBookmark(final int idx, String title, String url) {
        formDialog(idx < 0 ? "Yer imi ekle" : "Yer imini düzenle", title, url, (nm, u) -> {
            JSONArray a = getArr("bookmarks");
            JSONObject o = new JSONObject();
            try {
                o.put("t", nm);
                o.put("u", u);
                if (idx >= 0 && idx < a.length()) a.put(idx, o); else a.put(o);
            } catch (JSONException ignored) { }
            putArr("bookmarks", a);
            refreshBookmarkBar();
            updateToolbar();
            toast(idx < 0 ? "Yer imlerine eklendi" : "Yer imi kaydedildi");
        });
    }

    void bookmarkMenu(final int idx) {
        final JSONObject o = getArr("bookmarks").optJSONObject(idx);
        if (o == null) return;
        final String u = o.optString("u");
        dlg().setTitle(o.optString("t"))
                .setItems(new String[]{"Aç", "Yeni sekmede aç", "Düzenle", "Sil"}, (d, which) -> {
                    if (which == 0) load(current, u);
                    else if (which == 1) newTab(u, true, true);
                    else if (which == 2) editBookmark(idx, o.optString("t"), u);
                    else removeBookmark(idx);
                }).show();
    }

    void bookmarksDialog() {
        JSONArray a = getArr("bookmarks");
        if (a.length() == 0) {
            toast("Henüz yer imi yok. Eklemek için ☆ simgesine dokunun.");
            return;
        }
        String[] items = new String[a.length()];
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            items[i] = o == null ? "" : o.optString("t") + "\n" + o.optString("u");
        }
        dlg().setTitle("Yer imleri")
                .setItems(items, (d, which) -> bookmarkMenu(which))
                .setNegativeButton("Kapat", null).show();
    }

    void refreshBookmarkBar() {
        bookmarkStrip.removeAllViews();
        JSONArray a = getArr("bookmarks");
        if (a.length() == 0) {
            TextView h = new TextView(this);
            h.setText("Yer imi eklemek için adres çubuğundaki ☆ simgesine dokunun");
            h.setTextColor(C_DIM);
            h.setTextSize(12);
            h.setPadding(dp(6), 0, 0, 0);
            bookmarkStrip.addView(h);
            return;
        }
        for (int i = 0; i < a.length(); i++) {
            final JSONObject o = a.optJSONObject(i);
            if (o == null) continue;
            final int idx = i;
            TextView c = new TextView(this);
            c.setText(o.optString("t"));
            c.setTextColor(C_TEXT);
            c.setTextSize(13);
            c.setSingleLine(true);
            c.setEllipsize(TextUtils.TruncateAt.END);
            c.setMaxWidth(dp(180));
            c.setGravity(Gravity.CENTER_VERTICAL);
            c.setPadding(dp(10), 0, dp(10), 0);
            c.setBackground(ripple(false));
            c.setOnTouchListener((v, ev) -> {
                if (ev.getAction() == MotionEvent.ACTION_DOWN) preconnect(o.optString("u"));
                return false;
            });
            c.setOnClickListener(v -> load(current, o.optString("u")));
            c.setOnLongClickListener(v -> { bookmarkMenu(idx); return true; });
            c.setOnContextClickListener(v -> { bookmarkMenu(idx); return true; });
            bookmarkStrip.addView(c, new LinearLayout.LayoutParams(-2, dp(28)));
        }
    }

    // İndirmeler (İndirilenler klasörüne kaydedilir)

    static String header(Map<String, String> h, String key) {
        if (h == null) return null;
        for (Map.Entry<String, String> e : h.entrySet()) {
            if (e.getKey() != null && e.getKey().equalsIgnoreCase(key)) return e.getValue();
        }
        return null;
    }

    void downloadUrl(String url) {
        if (url == null || !(url.startsWith("http://") || url.startsWith("https://"))) {
            toast("Bu dosya bu şekilde indirilemiyor");
            return;
        }
        try {
            ensureRuntime();
            new GeckoWebExecutor(runtime).fetch(new WebRequest(url))
                    .accept(this::saveResponse, e -> toast("İndirme başlatılamadı"));
        } catch (Exception e) {
            toast("İndirme başlatılamadı");
        }
    }

    void saveResponse(final WebResponse resp) {
        if (resp == null || resp.body == null) {
            toast("İndirme başlatılamadı");
            return;
        }
        String cd = header(resp.headers, "Content-Disposition");
        String ct = header(resp.headers, "Content-Type");
        final String mime = ct == null ? null : ct.split(";")[0].trim();
        final String name = URLUtil.guessFileName(resp.uri, cd, mime);
        final long id = System.currentTimeMillis();
        addDownload(id, name, mime);
        toast("İndiriliyor: " + name);
        final InputStream in = resp.body;
        new Thread(() -> {
            Uri item = null;
            boolean ok = false;
            try {
                ContentValues cv = new ContentValues();
                cv.put(MediaStore.Downloads.DISPLAY_NAME, name);
                if (mime != null && !mime.isEmpty()) cv.put(MediaStore.Downloads.MIME_TYPE, mime);
                cv.put(MediaStore.Downloads.IS_PENDING, 1);
                item = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                if (item != null) {
                    try (OutputStream out = getContentResolver().openOutputStream(item)) {
                        byte[] buf = new byte[65536];
                        int n;
                        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                    }
                    ContentValues done = new ContentValues();
                    done.put(MediaStore.Downloads.IS_PENDING, 0);
                    getContentResolver().update(item, done, null, null);
                    ok = true;
                }
            } catch (Exception e) {
                if (item != null) {
                    try { getContentResolver().delete(item, null, null); } catch (Exception ignored) { }
                }
            } finally {
                try { in.close(); } catch (Exception ignored) { }
            }
            final boolean fok = ok;
            final Uri fitem = item;
            ui.post(() -> {
                finishDownload(id, fok ? fitem : null);
                toast(fok ? "İndirme tamamlandı: " + name : "İndirme başarısız: " + name);
            });
        }).start();
    }

    void addDownload(long id, String name, String mime) {
        JSONArray a = getArr("downloads");
        JSONArray n = new JSONArray();
        JSONObject o = new JSONObject();
        try {
            o.put("id", id);
            o.put("n", name);
            o.put("m", mime == null ? "" : mime);
            o.put("st", 0);
            o.put("time", id);
        } catch (JSONException ignored) { }
        n.put(o);
        for (int i = 0; i < a.length() && n.length() < 200; i++) n.put(a.opt(i));
        putArr("downloads", n);
    }

    void finishDownload(long id, Uri uri) {
        JSONArray a = getArr("downloads");
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o != null && o.optLong("id") == id) {
                try {
                    o.put("st", uri != null ? 1 : 2);
                    if (uri != null) o.put("u", uri.toString());
                } catch (JSONException ignored) { }
            }
        }
        putArr("downloads", a);
    }

    void openDownload(JSONObject o) {
        if (o.has("dm")) {
            long dmId = o.optLong("dm");
            int st = dmStatus(dmId);
            if (st != 1) {
                toast(st == 0 ? "Dosya henüz iniyor" : "Bu indirme başarısız oldu veya silinmiş");
                return;
            }
            DownloadManager dm = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
            Uri u = dm.getUriForDownloadedFile(dmId);
            if (u == null) {
                toast("Dosya bulunamadı");
                return;
            }
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(u, dm.getMimeTypeForDownloadedFile(dmId));
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            try { startActivity(i); } catch (Exception e) { toast("Bu dosyayı açacak uygulama yok"); }
            return;
        }
        if (o.optInt("st") != 1) {
            toast(o.optInt("st") == 0 ? "Dosya henüz iniyor" : "Bu indirme başarısız oldu");
            return;
        }
        Intent i = new Intent(Intent.ACTION_VIEW);
        String m = o.optString("m");
        i.setDataAndType(Uri.parse(o.optString("u")), m.isEmpty() ? "*/*" : m);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            startActivity(i);
        } catch (Exception e) {
            toast("Bu dosyayı açacak uygulama yok");
        }
    }

    void downloadsDialog() {
        final JSONArray a = getArr("downloads");
        AlertDialog.Builder b = dlg().setTitle("İndirilenler")
                .setNeutralButton("Klasörü aç", (d, w) -> {
                    try {
                        startActivity(new Intent(DownloadManager.ACTION_VIEW_DOWNLOADS)
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                    } catch (Exception e) {
                        toast("İndirilenler klasörü açılamadı");
                    }
                })
                .setNegativeButton("Kapat", null);
        if (a.length() == 0) {
            b.setMessage("Henüz bir şey indirmediniz.");
        } else {
            String[] items = new String[a.length()];
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.optJSONObject(i);
                if (o == null) { items[i] = ""; continue; }
                int st = o.has("dm") ? dmStatus(o.optLong("dm")) : o.optInt("st");
                String status = st == 1 ? "✓" : st == 2 ? "✕ Başarısız" : "⏳ İniyor";
                items[i] = o.optString("n") + "\n" + status + "   " + fmtTime(o.optLong("time"));
            }
            b.setItems(items, (d, which) -> {
                JSONObject o = a.optJSONObject(which);
                if (o != null) openDownload(o);
            });
            b.setPositiveButton("Listeyi temizle", (d, w) -> putArr("downloads", new JSONArray()));
        }
        b.show();
    }

    // ------------------------------------------------------------------ sonuçlar

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_FILE_WEB) {
            if (webFileCb == null) return;
            Uri[] out = null;
            if (resultCode == RESULT_OK && data != null) {
                if (data.getClipData() != null) {
                    int n = data.getClipData().getItemCount();
                    out = new Uri[n];
                    for (int i = 0; i < n; i++) out[i] = data.getClipData().getItemAt(i).getUri();
                } else if (data.getData() != null) {
                    out = new Uri[]{data.getData()};
                }
            }
            webFileCb.onReceiveValue(out);
            webFileCb = null;
            return;
        }
        if (requestCode == REQ_FILE) {
            FilePrompt p = pendingFile;
            GeckoResult<PromptResponse> r = pendingFileResult;
            pendingFile = null;
            pendingFileResult = null;
            if (p == null || r == null) return;
            if (resultCode != RESULT_OK || data == null) {
                r.complete(p.dismiss());
                return;
            }
            try {
                if (data.getClipData() != null && data.getClipData().getItemCount() > 0) {
                    int n = data.getClipData().getItemCount();
                    Uri[] uris = new Uri[n];
                    for (int i = 0; i < n; i++) uris[i] = data.getClipData().getItemAt(i).getUri();
                    r.complete(n == 1 && p.type != FilePrompt.Type.MULTIPLE
                            ? p.confirm(this, uris[0]) : p.confirm(this, uris));
                } else if (data.getData() != null) {
                    r.complete(p.type == FilePrompt.Type.MULTIPLE
                            ? p.confirm(this, new Uri[]{data.getData()}) : p.confirm(this, data.getData()));
                } else {
                    r.complete(p.dismiss());
                }
            } catch (Exception e) {
                r.complete(p.dismiss());
            }
        } else if (requestCode == REQ_BG && resultCode == RESULT_OK && data != null && data.getData() != null) {
            saveBackground(data.getData());
        }
    }

    // ------------------------------------------------------------------ tuşlar

    @Override
    public boolean dispatchKeyEvent(KeyEvent e) {
        if (e.getAction() == KeyEvent.ACTION_DOWN && current != null) {
            int k = e.getKeyCode();
            if (e.isCtrlPressed()) {
                switch (k) {
                    case KeyEvent.KEYCODE_T: newTab(null, true, false); return true;
                    case KeyEvent.KEYCODE_W: closeTab(current); return true;
                    case KeyEvent.KEYCODE_L:
                        address.requestFocus();
                        address.selectAll();
                        return true;
                    case KeyEvent.KEYCODE_R: reload(); return true;
                    case KeyEvent.KEYCODE_D: toggleBookmark(); return true;
                    case KeyEvent.KEYCODE_H: historyDialog(); return true;
                    case KeyEvent.KEYCODE_J: downloadsDialog(); return true;
                    case KeyEvent.KEYCODE_TAB: {
                        int i = tabs.indexOf(current), n = tabs.size();
                        selectTab(tabs.get(e.isShiftPressed() ? (i - 1 + n) % n : (i + 1) % n));
                        return true;
                    }
                    default: break;
                }
            }
            if (k == KeyEvent.KEYCODE_F5) {
                reload();
                return true;
            }
            if (e.isAltPressed() && k == KeyEvent.KEYCODE_DPAD_LEFT) {
                goBack();
                return true;
            }
            if (e.isAltPressed() && k == KeyEvent.KEYCODE_DPAD_RIGHT) {
                goForward();
                return true;
            }
        }
        return super.dispatchKeyEvent(e);
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (customView != null) {
            hideFullscreen();
            return;
        }
        if (current != null && current.fullscreen && current.session != null) {
            current.session.exitFullScreen();
            return;
        }
        if (address.hasFocus()) {
            address.clearFocus();
            hideKeyboard(address);
            updateToolbar();
            return;
        }
        if (current != null) {
            boolean back = canGoBack(current);
            if (back) {
                goBack();
                return;
            }
        }
        super.onBackPressed();
    }
}
