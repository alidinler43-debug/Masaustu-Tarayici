package com.alidinler.masaustu;

import java.util.HashSet;
import java.util.Locale;

/** Bilinen reklam ve izleyici sunucularını engeller. */
final class AdBlock {

    private static final HashSet<String> HOSTS = new HashSet<>();

    static {
        String[] list = {
            // Google reklam ağları
            "doubleclick.net", "googlesyndication.com", "googleadservices.com",
            "googletagservices.com", "adservice.google.com", "adservice.google.com.tr",
            "google-analytics.com", "pagead2.googlesyndication.com",
            // Büyük reklam borsaları
            "adnxs.com", "adsrvr.org", "amazon-adsystem.com", "criteo.com", "criteo.net",
            "taboola.com", "outbrain.com", "pubmatic.com", "rubiconproject.com", "openx.net",
            "casalemedia.com", "advertising.com", "yieldmo.com", "smartadserver.com",
            "adform.net", "teads.tv", "3lift.com", "sharethrough.com", "bidswitch.net",
            "mathtag.com", "rlcdn.com", "adsafeprotected.com", "doubleverify.com",
            "moatads.com", "scorecardresearch.com", "quantserve.com", "quantcount.com",
            "zedo.com", "media.net", "contextweb.com", "lijit.com", "sovrn.com",
            "indexww.com", "gumgum.com", "undertone.com", "spotxchange.com", "spotx.tv",
            "springserve.com", "adcolony.com", "unityads.unity3d.com", "applovin.com",
            "inmobi.com", "smaato.net", "mopub.com", "vungle.com", "chartboost.com",
            "adroll.com", "serving-sys.com", "flashtalking.com", "eyeota.net",
            "bluekai.com", "demdex.net", "everesttech.net", "agkn.com", "tapad.com",
            "crwdcntrl.net", "exelator.com", "krxd.net", "adsymptotic.com",
            "onetag-sys.com", "seedtag.com", "connatix.com", "primis.tech",
            "imrworldwide.com", "hotjar.com", "mouseflow.com", "clarity.ms",
            // Açılır pencere ve agresif reklam ağları
            "popads.net", "popcash.net", "propellerads.com", "adsterra.com",
            "exoclick.com", "juicyads.com", "trafficjunky.net", "mgid.com",
            "revcontent.com", "admaven.com", "hilltopads.net", "clickadu.com",
            "onclkds.com", "adcash.com", "realsrv.com", "a-ads.com", "bidvertiser.com",
            // Rus / Yandex reklamları
            "an.yandex.ru", "yandexadexchange.net", "adfox.ru", "adfox.yandex.ru",
            "adriver.ru", "begun.ru", "admixer.net",
            // Türkiye'deki reklam ağları
            "admatic.com.tr", "reklamstore.com", "medyanetads.com", "adhood.com",
            "adnet.com.tr", "rtbhouse.com", "mediaimpact.com.tr", "gemius.pl",
            "hit.gemius.pl", "tr.hit.gemius.pl", "effectivemeasure.net",
            // Ek reklam sunucuları
            "33across.com", "adtelligent.com", "smartclip.net", "yieldlab.net",
            "improvedigital.com", "richaudience.com", "e-planning.net", "adkernel.com",
            "betweendigital.com", "otm-r.com", "buzzoola.com", "id5-sync.com", "liadm.com",
            "pubmine.com", "adthrive.com", "freestar.io", "carbonads.net", "buysellads.com",
            "infolinks.com", "kargo.com", "nativo.com", "zemanta.com", "dianomi.com",
            "ligatus.com", "plista.com", "yieldlove.com", "adup-tech.com", "permutive.com",
            "adsco.re", "admanmedia.com", "aniview.com", "vidoomy.com", "adpushup.com",
            "adyoulike.com", "omnitagjs.com", "adhese.com", "adition.com", "stroeerdigitalmedia.de",
            "yieldbird.com", "ad.gt", "audienceproject.com", "bidr.io", "sitescout.com",
            "simpli.fi", "turn.com", "adgrx.com", "dotomi.com", "conversantmedia.com",
            "media6degrees.com", "w55c.net", "rfihub.com", "ipredictive.com", "zqtk.net",
            "adsymptotic.com", "tremorhub.com", "lkqd.net", "innovid.com", "ib-ibi.com",
            "ad-score.com", "adlightning.com", "confiant-integrations.net", "cootlogix.com",
            // İzleyiciler (sayfayı yavaşlatan analiz betikleri)
            "app-measurement.com", "bat.bing.com", "analytics.tiktok.com", "ads.linkedin.com",
            "px.ads.linkedin.com", "snap.licdn.com", "analytics.twitter.com", "ads-twitter.com",
            "static.ads-twitter.com", "tr.snapchat.com", "sc-static.net", "mc.yandex.ru",
            "mc.yandex.com", "top-fwz1.mail.ru", "counter.yadro.ru", "pixel.wp.com",
            "stats.wp.com", "cloudflareinsights.com", "fullstory.com", "nr-data.net",
            "mixpanel.com", "chartbeat.com", "chartbeat.net", "parsely.com", "cxense.com",
            "tiqcdn.com", "omtrdc.net", "2o7.net", "segment.io", "heapanalytics.com",
            "luckyorange.com", "crazyegg.com", "inspectlet.com", "smartlook.com",
            "onesignal.com", "pushwoosh.com", "izooto.com", "pushengage.com", "webpushr.com",
            "sendpulse.com", "ads.yahoo.com", "analytics.yahoo.com", "adtech.de",
            "adtechus.com", "yieldmanager.com", "browser-intake-datadoghq.com"
        };
        for (String h : list) HOSTS.add(h);
    }

    private AdBlock() { }

    static boolean isAd(String host) {
        if (host == null) return false;
        String h = host.toLowerCase(Locale.ROOT);
        while (true) {
            if (HOSTS.contains(h)) return true;
            int dot = h.indexOf('.');
            if (dot < 0 || dot == h.length() - 1) return false;
            h = h.substring(dot + 1);
        }
    }

    /** Engellenen reklamların sayfada bıraktığı boş kutuları gizler. */
    static final String HIDE_JS =
        "(function(){if(document.getElementById('__md_ab'))return;"
        + "var s=document.createElement('style');s.id='__md_ab';"
        + "s.textContent='ins.adsbygoogle,.adsbygoogle,[id^=\"div-gpt-ad\"],[id^=\"google_ads_iframe\"],"
        + "iframe[src*=\"doubleclick.net\"],iframe[src*=\"googlesyndication\"],[id^=\"taboola-\"],"
        + ".trc_rbox_container,.OUTBRAIN,[data-widget-id^=\"outbrain\"]{display:none!important}';"
        + "(document.head||document.documentElement).appendChild(s);})();";
}
