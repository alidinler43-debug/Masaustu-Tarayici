package com.alidinler.masaustu;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.text.InputType;
import android.text.TextUtils;
import android.util.Base64;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebStorage;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicInteger;

public class MainActivity extends Activity {

    static final String NEWTAB = "file:///android_asset/newtab.html";
    static final String UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
            + "(KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36";
    static final int REQ_FILE = 11, REQ_BG = 12;

    static final int C_BAR = 0xFF1C1C1F, C_TOOL = 0xFF2B2B30, C_FIELD = 0xFF3B3B42,
            C_TEXT = 0xFFEDEDF0, C_DIM = 0xFF9C9CA5, C_ACCENT = 0xFFFFCC00;

    static final String DEFAULT_TILES = "["
            + "{\"t\":\"Google\",\"u\":\"https://www.google.com\"},"
            + "{\"t\":\"YouTube\",\"u\":\"https://www.youtube.com\"},"
            + "{\"t\":\"TradingView\",\"u\":\"https://www.tradingview.com\"},"
            + "{\"t\":\"Vikipedi\",\"u\":\"https://tr.wikipedia.org\"},"
            + "{\"t\":\"Yandex\",\"u\":\"https://yandex.com.tr\"},"
            + "{\"t\":\"GitHub\",\"u\":\"https://github.com\"},"
            + "{\"t\":\"Gmail\",\"u\":\"https://mail.google.com\"},"
            + "{\"t\":\"Hava durumu\",\"u\":\"https://www.mgm.gov.tr\"}"
            + "]";

    final ArrayList<Tab> tabs = new ArrayList<>();
    final Handler ui = new Handler(Looper.getMainLooper());
    Tab current;
    SharedPreferences prefs;
    volatile boolean adBlock;
    int zoom;
    static final int[] ZOOMS = {50, 67, 75, 80, 90, 100, 110, 125, 150};

    LinearLayout mainLayout, tabStrip, bookmarkStrip;
    HorizontalScrollView tabScroll;
    FrameLayout webContainer, fullContainer;
    EditText address;
    TextView backBtn, fwdBtn, starBtn, shieldBtn;
    ProgressBar progress;

    View customView;
    WebChromeClient.CustomViewCallback customCb;
    ValueCallback<Uri[]> fileCb;

    class Tab {
        WebView web;
        String title = "Yeni sekme";
        String pendingUrl;
        String lastUrl;
        long googleAsk;
        volatile boolean isNewTab;
        final AtomicInteger blocked = new AtomicInteger();
        LinearLayout view;
        TextView titleView;

        String url() {
            if (pendingUrl != null) return pendingUrl;
            if (isNewTab) return "";
            String u = web.getUrl();
            return u == null ? "" : u;
        }
    }

    // ------------------------------------------------------------------ yaşam döngüsü

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("tarayici", MODE_PRIVATE);
        adBlock = prefs.getBoolean("adblock", true);
        zoom = prefs.getInt("zoom_v2", 100);
        getWindow().setStatusBarColor(C_BAR);
        getWindow().setNavigationBarColor(C_TOOL);
        buildUi();
        restoreSession();
        if (savedInstanceState == null) handleIntent(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        handleIntent(intent);
    }

    void handleIntent(Intent in) {
        if (in != null && Intent.ACTION_VIEW.equals(in.getAction()) && in.getData() != null) {
            newTab(in.getData().toString(), true, false);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        saveSession();
        CookieManager.getInstance().flush();
    }

    @Override
    protected void onDestroy() {
        for (Tab t : tabs) {
            try { t.web.destroy(); } catch (Exception ignored) { }
        }
        super.onDestroy();
    }

    // ------------------------------------------------------------------ arayüz

    int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    Drawable ripple(boolean borderless) {
        TypedValue tv = new TypedValue();
        getTheme().resolveAttribute(borderless
                ? android.R.attr.selectableItemBackgroundBorderless
                : android.R.attr.selectableItemBackground, tv, true);
        return getDrawable(tv.resourceId);
    }

    GradientDrawable round(int color, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    TextView iconBtn(String s, int sp) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(C_TEXT);
        t.setGravity(Gravity.CENTER);
        t.setBackground(ripple(true));
        t.setClickable(true);
        return t;
    }

    void buildUi() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(C_BAR);

        mainLayout = new LinearLayout(this);
        mainLayout.setOrientation(LinearLayout.VERTICAL);
        mainLayout.setBackgroundColor(C_TOOL);
        root.addView(mainLayout, new FrameLayout.LayoutParams(-1, -1));

        fullContainer = new FrameLayout(this);
        fullContainer.setBackgroundColor(Color.BLACK);
        fullContainer.setVisibility(View.GONE);
        root.addView(fullContainer, new FrameLayout.LayoutParams(-1, -1));

        // Sekme şeridi
        LinearLayout tabBar = new LinearLayout(this);
        tabBar.setOrientation(LinearLayout.HORIZONTAL);
        tabBar.setBackgroundColor(C_BAR);
        tabBar.setPadding(dp(6), dp(6), dp(6), 0);
        tabBar.setGravity(Gravity.BOTTOM);

        tabScroll = new HorizontalScrollView(this);
        tabScroll.setHorizontalScrollBarEnabled(false);
        tabStrip = new LinearLayout(this);
        tabStrip.setOrientation(LinearLayout.HORIZONTAL);
        tabScroll.addView(tabStrip, new FrameLayout.LayoutParams(-2, -1));
        tabBar.addView(tabScroll, new LinearLayout.LayoutParams(0, dp(38), 1f));

        TextView plus = iconBtn("+", 22);
        plus.setOnClickListener(v -> newTab(NEWTAB, true, false));
        tabBar.addView(plus, new LinearLayout.LayoutParams(dp(44), dp(38)));
        mainLayout.addView(tabBar, new LinearLayout.LayoutParams(-1, -2));

        // Araç çubuğu
        LinearLayout tool = new LinearLayout(this);
        tool.setOrientation(LinearLayout.HORIZONTAL);
        tool.setBackgroundColor(C_TOOL);
        tool.setGravity(Gravity.CENTER_VERTICAL);
        tool.setPadding(dp(6), dp(5), dp(6), dp(5));

        backBtn = iconBtn("←", 20);
        backBtn.setOnClickListener(v -> { if (current.web.canGoBack()) current.web.goBack(); });
        fwdBtn = iconBtn("→", 20);
        fwdBtn.setOnClickListener(v -> { if (current.web.canGoForward()) current.web.goForward(); });
        TextView reload = iconBtn("↻", 20);
        reload.setOnClickListener(v -> current.web.reload());
        TextView home = iconBtn("⌂", 22);
        home.setOnClickListener(v -> load(current, NEWTAB));
        for (TextView b : new TextView[]{backBtn, fwdBtn, reload, home}) {
            tool.addView(b, new LinearLayout.LayoutParams(dp(42), dp(40)));
        }

        address = new EditText(this);
        address.setSingleLine(true);
        address.setTextColor(C_TEXT);
        address.setHintTextColor(C_DIM);
        address.setHint("Arama yapın veya adres yazın");
        address.setTextSize(15);
        address.setBackground(round(C_FIELD, 20));
        address.setPadding(dp(16), 0, dp(16), 0);
        address.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        address.setImeOptions(EditorInfo.IME_ACTION_GO | EditorInfo.IME_FLAG_NO_EXTRACT_UI);
        address.setSelectAllOnFocus(true);
        address.setOnEditorActionListener((v, id, ev) -> {
            boolean enter = ev != null && ev.getKeyCode() == KeyEvent.KEYCODE_ENTER
                    && ev.getAction() == KeyEvent.ACTION_DOWN;
            if (id == EditorInfo.IME_ACTION_GO || enter) {
                go(address.getText().toString());
                return true;
            }
            return ev != null && ev.getKeyCode() == KeyEvent.KEYCODE_ENTER;
        });
        address.setOnFocusChangeListener((v, has) -> { if (!has) updateToolbar(); });
        LinearLayout.LayoutParams alp = new LinearLayout.LayoutParams(0, dp(38), 1f);
        alp.leftMargin = dp(6);
        alp.rightMargin = dp(6);
        tool.addView(address, alp);

        shieldBtn = iconBtn("🛡", 15);
        shieldBtn.setOnClickListener(v -> adBlockDialog());
        tool.addView(shieldBtn, new LinearLayout.LayoutParams(dp(60), dp(40)));

        starBtn = iconBtn("☆", 22);
        starBtn.setOnClickListener(v -> toggleBookmark());
        tool.addView(starBtn, new LinearLayout.LayoutParams(dp(42), dp(40)));

        final TextView menu = iconBtn("⋮", 22);
        menu.setOnClickListener(v -> showMenu(menu));
        tool.addView(menu, new LinearLayout.LayoutParams(dp(42), dp(40)));
        mainLayout.addView(tool, new LinearLayout.LayoutParams(-1, -2));

        // Yer imleri çubuğu
        HorizontalScrollView bmScroll = new HorizontalScrollView(this);
        bmScroll.setHorizontalScrollBarEnabled(false);
        bmScroll.setBackgroundColor(C_TOOL);
        bookmarkStrip = new LinearLayout(this);
        bookmarkStrip.setOrientation(LinearLayout.HORIZONTAL);
        bookmarkStrip.setGravity(Gravity.CENTER_VERTICAL);
        bookmarkStrip.setPadding(dp(8), 0, dp(8), dp(2));
        bmScroll.addView(bookmarkStrip, new FrameLayout.LayoutParams(-2, -1));
        mainLayout.addView(bmScroll, new LinearLayout.LayoutParams(-1, dp(34)));

        // Yükleme çubuğu
        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        progress.setIndeterminate(false);
        progress.setProgressTintList(ColorStateList.valueOf(C_ACCENT));
        progress.setProgressBackgroundTintList(ColorStateList.valueOf(C_TOOL));
        progress.setVisibility(View.INVISIBLE);
        mainLayout.addView(progress, new LinearLayout.LayoutParams(-1, dp(3)));

        webContainer = new FrameLayout(this);
        webContainer.setBackgroundColor(Color.WHITE);
        mainLayout.addView(webContainer, new LinearLayout.LayoutParams(-1, 0, 1f));

        setContentView(root);
        refreshBookmarkBar();
    }

    void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    AlertDialog.Builder dlg() {
        return new AlertDialog.Builder(this);
    }

    void hideKeyboard() {
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(address.getWindowToken(), 0);
    }

    // ------------------------------------------------------------------ sekmeler

    Tab newTab(String url, boolean select, boolean nextToCurrent) {
        Tab t = new Tab();
        t.web = createWebView(t);
        t.web.setVisibility(View.GONE);
        webContainer.addView(t.web, new FrameLayout.LayoutParams(-1, -1));
        int idx = (nextToCurrent && current != null) ? tabs.indexOf(current) + 1 : tabs.size();
        tabs.add(idx, t);
        buildTabView(t);
        tabStrip.addView(t.view, idx);
        if (url != null) load(t, url);
        if (select || current == null) selectTab(t); else refreshTabViews();
        return t;
    }

    void buildTabView(final Tab t) {
        LinearLayout v = new LinearLayout(this);
        v.setOrientation(LinearLayout.HORIZONTAL);
        v.setGravity(Gravity.CENTER_VERTICAL);
        v.setPadding(dp(12), 0, dp(4), 0);

        TextView title = new TextView(this);
        title.setSingleLine(true);
        title.setEllipsize(TextUtils.TruncateAt.END);
        title.setTextSize(13);
        v.addView(title, new LinearLayout.LayoutParams(0, -2, 1f));

        TextView x = new TextView(this);
        x.setText("✕");
        x.setTextSize(12);
        x.setTextColor(C_DIM);
        x.setGravity(Gravity.CENTER);
        x.setBackground(ripple(true));
        x.setOnClickListener(c -> closeTab(t));
        v.addView(x, new LinearLayout.LayoutParams(dp(28), dp(28)));

        v.setOnClickListener(c -> selectTab(t));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(210), -1);
        lp.rightMargin = dp(2);
        v.setLayoutParams(lp);
        t.view = v;
        t.titleView = title;
    }

    void refreshTabViews() {
        float r = dp(10);
        for (Tab t : tabs) {
            boolean active = t == current;
            GradientDrawable g = new GradientDrawable();
            g.setColor(active ? C_TOOL : 0x00000000);
            g.setCornerRadii(new float[]{r, r, r, r, 0, 0, 0, 0});
            t.view.setBackground(g);
            String title = (t.title == null || t.title.trim().isEmpty()) ? "Yeni sekme" : t.title;
            t.titleView.setText(title);
            t.titleView.setTextColor(active ? C_TEXT : C_DIM);
        }
    }

    void selectTab(Tab t) {
        if (current != null && current != t) {
            current.web.setVisibility(View.GONE);
            current.web.getSettings().setOffscreenPreRaster(false);
        }
        current = t;
        t.web.setVisibility(View.VISIBLE);
        t.web.getSettings().setOffscreenPreRaster(true);
        if (t.pendingUrl != null) {
            String u = t.pendingUrl;
            t.pendingUrl = null;
            load(t, u);
        }
        refreshTabViews();
        updateToolbar();
        final View v = t.view;
        tabScroll.post(() -> {
            int l = v.getLeft(), rr = v.getRight(), sx = tabScroll.getScrollX(), w = tabScroll.getWidth();
            if (l < sx) tabScroll.smoothScrollTo(l, 0);
            else if (rr > sx + w) tabScroll.smoothScrollTo(rr - w, 0);
        });
    }

    void closeTab(Tab t) {
        int i = tabs.indexOf(t);
        if (i < 0) return;
        if (customView != null && t == current) hideFullscreen();
        tabs.remove(i);
        tabStrip.removeView(t.view);
        webContainer.removeView(t.web);
        try { t.web.destroy(); } catch (Exception ignored) { }
        if (tabs.isEmpty()) {
            current = null;
            newTab(NEWTAB, true, false);
            return;
        }
        if (t == current) {
            current = null;
            selectTab(tabs.get(Math.min(i, tabs.size() - 1)));
        } else {
            refreshTabViews();
        }
    }

    void recreateTab(Tab t) {
        if (!tabs.contains(t)) return;
        String u = t.lastUrl != null ? t.lastUrl : NEWTAB;
        int pos = webContainer.indexOfChild(t.web);
        webContainer.removeView(t.web);
        try { t.web.destroy(); } catch (Exception ignored) { }
        t.web = createWebView(t);
        t.web.setVisibility(t == current ? View.VISIBLE : View.GONE);
        webContainer.addView(t.web, Math.max(0, pos), new FrameLayout.LayoutParams(-1, -1));
        if (t == current) load(t, u); else t.pendingUrl = u;
    }

    void load(Tab t, String url) {
        t.pendingUrl = null;
        t.isNewTab = url.startsWith(NEWTAB);
        t.web.loadUrl(url);
        if (t == current) updateToolbar();
    }

    void go(String input) {
        String s = input.trim();
        if (s.isEmpty() || current == null) return;
        String url;
        if (s.matches("^[a-zA-Z][a-zA-Z0-9+.-]*://.*") || s.startsWith("about:")) {
            url = s;
        } else if (!s.contains(" ") && (s.matches("^[^\\s/]+\\.[a-zA-Z]{2,}(:\\d+)?(/.*)?$")
                || s.matches("^\\d{1,3}(\\.\\d{1,3}){3}(:\\d+)?(/.*)?$")
                || s.startsWith("localhost"))) {
            url = "https://" + s;
        } else {
            String q;
            try { q = URLEncoder.encode(s, "UTF-8"); } catch (Exception e) { q = s; }
            url = "https://www.google.com/search?q=" + q;
        }
        load(current, url);
        address.clearFocus();
        hideKeyboard();
        current.web.requestFocus();
    }

    void updateToolbar() {
        if (current == null) return;
        if (!address.hasFocus()) address.setText(current.url());
        backBtn.setAlpha(current.web.canGoBack() ? 1f : 0.35f);
        fwdBtn.setAlpha(current.web.canGoForward() ? 1f : 0.35f);
        String u = current.url();
        boolean bm = !u.isEmpty() && bookmarkIndex(u) >= 0;
        starBtn.setText(bm ? "★" : "☆");
        starBtn.setTextColor(bm ? C_ACCENT : C_TEXT);
        updateShield();
        int p = current.web.getProgress();
        progress.setProgress(p);
        progress.setVisibility(p < 100 && current.pendingUrl == null ? View.VISIBLE : View.INVISIBLE);
    }

    void updateShield() {
        if (current == null) return;
        int n = current.blocked.get();
        if (adBlock) {
            shieldBtn.setText(n > 0 ? "🛡 " + n : "🛡");
            shieldBtn.setAlpha(1f);
        } else {
            shieldBtn.setText("🛡");
            shieldBtn.setAlpha(0.35f);
        }
    }

    // ------------------------------------------------------------------ WebView

    WebView createWebView(final Tab t) {
        WebView w = new WebView(this);
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setUserAgentString(UA);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setSupportMultipleWindows(true);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        s.setLayoutAlgorithm(WebSettings.LayoutAlgorithm.NORMAL);
        s.setTextZoom(100);
        s.setLoadsImagesAutomatically(true);
        w.setScrollbarFadingEnabled(false);
        w.setVerticalScrollBarEnabled(true);
        w.setHorizontalScrollBarEnabled(true);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(w, true);
        w.setBackgroundColor(Color.WHITE);
        w.addJavascriptInterface(new Bridge(t), "Tarayici");

        w.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                return handleSpecialUrl(v, r.getUrl());
            }

            @Override
            public void onPageStarted(WebView v, String url, Bitmap favicon) {
                t.isNewTab = url != null && url.startsWith(NEWTAB);
                if (url != null) t.lastUrl = url;
                t.blocked.set(0);
                maybeGoogleSignin(t, url);
                if (!t.isNewTab) v.evaluateJavascript(viewportJs(), null);
                if (t == current) updateToolbar();
            }

            @Override
            public void onPageCommitVisible(WebView v, String url) {
                if (!t.isNewTab) v.evaluateJavascript(viewportJs(), null);
            }

            @Override
            public void onPageFinished(WebView v, String url) {
                if (url != null && url.startsWith("http") && !t.isNewTab) {
                    v.evaluateJavascript(viewportJs(), null);
                    addHistory(v.getTitle(), url);
                    if (adBlock) v.evaluateJavascript(AdBlock.HIDE_JS, null);
                }
                if (t == current) updateToolbar();
                CookieManager.getInstance().flush();
            }

            @Override
            public void doUpdateVisitedHistory(WebView v, String url, boolean isReload) {
                if (url != null && !url.startsWith(NEWTAB)) t.lastUrl = url;
                maybeGoogleSignin(t, url);
                if (t == current) updateToolbar();
            }

            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                if (adBlock && !r.isForMainFrame() && AdBlock.isAd(r.getUrl().getHost())) {
                    t.blocked.incrementAndGet();
                    ui.post(() -> { if (t == current) updateShield(); });
                    return new WebResourceResponse("text/plain", "utf-8",
                            new ByteArrayInputStream(new byte[0]));
                }
                return null;
            }

            @Override
            public boolean onRenderProcessGone(WebView v, RenderProcessGoneDetail detail) {
                ui.post(() -> recreateTab(t));
                return true;
            }
        });

        w.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView v, int p) {
                if (t == current) {
                    progress.setProgress(p);
                    progress.setVisibility(p < 100 ? View.VISIBLE : View.INVISIBLE);
                }
            }

            @Override
            public void onReceivedTitle(WebView v, String title) {
                t.title = title;
                refreshTabViews();
            }

            @Override
            public boolean onCreateWindow(WebView v, boolean isDialog, boolean isUserGesture, Message msg) {
                if (adBlock && !isUserGesture) return false;
                Tab nt = newTab(null, true, true);
                WebView.WebViewTransport tr = (WebView.WebViewTransport) msg.obj;
                tr.setWebView(nt.web);
                msg.sendToTarget();
                return true;
            }

            @Override
            public void onCloseWindow(WebView v) {
                ui.post(() -> closeTab(t));
            }

            @Override
            public void onShowCustomView(View view, CustomViewCallback callback) {
                showFullscreen(view, callback);
            }

            @Override
            public void onHideCustomView() {
                hideFullscreen();
            }

            @Override
            public Bitmap getDefaultVideoPoster() {
                return Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888);
            }

            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams params) {
                if (fileCb != null) fileCb.onReceiveValue(null);
                fileCb = cb;
                try {
                    Intent i = params.createIntent();
                    if (params.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE) {
                        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                    }
                    startActivityForResult(i, REQ_FILE);
                } catch (Exception e) {
                    fileCb = null;
                    return false;
                }
                return true;
            }
        });

        w.setDownloadListener((url, ua, cd, mime, len) -> startDownload(url, ua, cd, mime));
        w.setOnLongClickListener(v -> onWebLongPress(t));
        w.setOnContextClickListener(v -> onWebLongPress(t));
        return w;
    }

    boolean handleSpecialUrl(WebView v, Uri u) {
        String sc = u.getScheme();
        if (sc == null) return false;
        sc = sc.toLowerCase(Locale.ROOT);
        if (sc.equals("http") || sc.equals("https") || sc.equals("file") || sc.equals("about")
                || sc.equals("data") || sc.equals("blob") || sc.equals("javascript")) {
            return false;
        }
        try {
            if (sc.equals("intent")) {
                Intent in = Intent.parseUri(u.toString(), Intent.URI_INTENT_SCHEME);
                in.addCategory(Intent.CATEGORY_BROWSABLE);
                in.setComponent(null);
                in.setSelector(null);
                try {
                    startActivity(in);
                } catch (Exception e) {
                    String fb = in.getStringExtra("browser_fallback_url");
                    if (fb != null && fb.startsWith("http")) v.loadUrl(fb);
                    else toast("Bu bağlantıyı açacak uygulama yok");
                }
                return true;
            }
            Intent in = new Intent(Intent.ACTION_VIEW, u);
            in.addCategory(Intent.CATEGORY_BROWSABLE);
            startActivity(in);
        } catch (Exception e) {
            toast("Bu bağlantıyı açacak uygulama yok");
        }
        return true;
    }

    boolean onWebLongPress(Tab t) {
        WebView.HitTestResult r = t.web.getHitTestResult();
        if (r == null) return false;
        int type = r.getType();
        String extra = r.getExtra();
        if (extra == null) return false;
        if (type == WebView.HitTestResult.SRC_ANCHOR_TYPE) {
            linkMenu(extra, null);
            return true;
        }
        if (type == WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE) {
            Message m = ui.obtainMessage();
            t.web.requestFocusNodeHref(m);
            String link = m.getData().getString("url");
            linkMenu(link != null && !link.isEmpty() ? link : extra, extra);
            return true;
        }
        if (type == WebView.HitTestResult.IMAGE_TYPE) {
            linkMenu(null, extra);
            return true;
        }
        return false;
    }

    void linkMenu(final String link, final String img) {
        ArrayList<String> labels = new ArrayList<>();
        ArrayList<Runnable> acts = new ArrayList<>();
        if (link != null) {
            labels.add("Yeni sekmede aç");
            acts.add(() -> newTab(link, true, true));
            labels.add("Arka planda yeni sekmede aç");
            acts.add(() -> newTab(link, false, true));
            labels.add("Bağlantıyı kopyala");
            acts.add(() -> copy(link));
        }
        if (img != null) {
            labels.add("Resmi yeni sekmede aç");
            acts.add(() -> newTab(img, true, true));
            labels.add("Resmi indir");
            acts.add(() -> startDownload(img, UA, null, null));
        }
        String title = link != null ? link : img;
        if (title.length() > 90) title = title.substring(0, 90) + "…";
        dlg().setTitle(title)
                .setItems(labels.toArray(new String[0]), (d, which) -> acts.get(which).run())
                .show();
    }

    void copy(String s) {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("bağlantı", s));
        toast("Kopyalandı");
    }

    // ------------------------------------------------------------------ tam ekran video

    void showFullscreen(View v, WebChromeClient.CustomViewCallback cb) {
        if (customView != null) {
            cb.onCustomViewHidden();
            return;
        }
        customView = v;
        customCb = cb;
        fullContainer.addView(v, new FrameLayout.LayoutParams(-1, -1));
        fullContainer.setVisibility(View.VISIBLE);
        mainLayout.setVisibility(View.GONE);
        setSystemBars(false);
    }

    void hideFullscreen() {
        if (customView == null) return;
        fullContainer.removeView(customView);
        fullContainer.setVisibility(View.GONE);
        mainLayout.setVisibility(View.VISIBLE);
        customView = null;
        setSystemBars(true);
        WebChromeClient.CustomViewCallback cb = customCb;
        customCb = null;
        if (cb != null) cb.onCustomViewHidden();
    }

    @SuppressWarnings("deprecation")
    void setSystemBars(boolean show) {
        if (Build.VERSION.SDK_INT >= 30) {
            WindowInsetsController c = getWindow().getInsetsController();
            if (c == null) return;
            if (show) {
                c.show(WindowInsets.Type.systemBars());
            } else {
                c.hide(WindowInsets.Type.systemBars());
                c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        } else {
            getWindow().getDecorView().setSystemUiVisibility(show ? 0
                    : (View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY));
        }
    }

    // ------------------------------------------------------------------ menü

    void showMenu(View anchor) {
        PopupMenu pm = new PopupMenu(this, anchor);
        Menu m = pm.getMenu();
        m.add(0, 1, 0, "Yeni sekme");
        m.add(0, 2, 1, "Yer imleri");
        m.add(0, 3, 2, "Geçmiş");
        m.add(0, 4, 3, "İndirilenler");
        MenuItem ab = m.add(0, 5, 4, "Reklam engelleyici");
        ab.setCheckable(true);
        ab.setChecked(adBlock);
        m.add(0, 8, 5, "Sayfa yakınlaştırma (%" + zoom + ")");
        m.add(0, 6, 6, "Çerezleri ve önbelleği temizle");
        m.add(0, 9, 7, "Bu sayfayı Chrome'da aç");
        m.add(0, 7, 8, "Klavye kısayolları");
        pm.setOnMenuItemClickListener(it -> {
            switch (it.getItemId()) {
                case 1: newTab(NEWTAB, true, false); break;
                case 2: bookmarksDialog(); break;
                case 3: historyDialog(); break;
                case 4: downloadsDialog(); break;
                case 5: setAdBlock(!adBlock); break;
                case 6: clearDataDialog(); break;
                case 7: shortcutsDialog(); break;
                case 8: zoomDialog(); break;
                case 9: openExternal(current == null ? "" : current.url()); break;
                default: break;
            }
            return true;
        });
        pm.show();
    }

    void shortcutsDialog() {
        dlg().setTitle("Klavye kısayolları")
                .setMessage("Ctrl+T  Yeni sekme\nCtrl+W  Sekmeyi kapat\nCtrl+Tab  Sonraki sekme\n"
                        + "Ctrl+Shift+Tab  Önceki sekme\nCtrl+L  Adres çubuğu\nCtrl+R veya F5  Yenile\n"
                        + "Ctrl+D  Yer imi ekle/kaldır\nCtrl+H  Geçmiş\nCtrl+J  İndirilenler\n"
                        + "Alt+Sol/Sağ ok  Geri/İleri\nCtrl + / Ctrl -  Yakınlaştır/Uzaklaştır\n"
                        + "Ctrl+0  Yakınlaştırmayı sıfırla (%100)\nCtrl + fare tekerleği  Yakınlaştır/Uzaklaştır")
                .setPositiveButton("Tamam", null).show();
    }

    void clearDataDialog() {
        dlg().setTitle("Çerezleri ve önbelleği temizle")
                .setMessage("Tüm sitelerden çıkış yapılır ve kayıtlı site verileri silinir. Yer imleri, "
                        + "geçmiş ve yeni sekme kutucukları korunur.")
                .setPositiveButton("Temizle", (d, w) -> {
                    CookieManager.getInstance().removeAllCookies(null);
                    WebStorage.getInstance().deleteAllData();
                    if (current != null) current.web.clearCache(true);
                    toast("Çerezler ve önbellek temizlendi");
                })
                .setNegativeButton("İptal", null).show();
    }

    // ------------------------------------------------------------------ Google girişi

    /** Google, uygulama içi tarayıcılarda girişe izin vermiyor; giriş sayfası açılınca Chrome'a yönlendirmeyi önerir. */
    void maybeGoogleSignin(final Tab t, String url) {
        if (url == null || !url.startsWith("https://accounts.google.com/")) return;
        Uri u = Uri.parse(url);
        String path = u.getPath() == null ? "" : u.getPath();
        boolean signin = path.startsWith("/v3/signin") || path.startsWith("/ServiceLogin")
                || path.startsWith("/signin") || path.startsWith("/AccountChooser")
                || path.startsWith("/o/oauth2");
        if (!signin || t != current) return;
        long now = System.currentTimeMillis();
        if (now - t.googleAsk < 20000) return;
        t.googleAsk = now;
        String cont = null;
        try { cont = u.getQueryParameter("continue"); } catch (Exception ignored) { }
        final String target = (path.startsWith("/o/oauth2") || cont == null || !cont.startsWith("http")) ? url : cont;
        ui.post(() -> dlg().setTitle("Google girişi bu tarayıcıda yapılamıyor")
                .setMessage("Google; Gmail, YouTube ve diğer Google hesaplarına uygulama içi tarayıcılardan "
                        + "girişe izin vermiyor. Bu sayfayı Chrome'da açıp orada giriş yapabilirsin.\n\n"
                        + "Hepsiburada, TradingView gibi sitelere kendi e-posta ve şifrenle girersen burada çalışır.")
                .setPositiveButton("Chrome'da aç", (d, w) -> openExternal(target))
                .setNegativeButton("Kapat", null).show());
    }

    void openExternal(String url) {
        if (url == null || url.isEmpty()) {
            toast("Açılacak bir sayfa yok");
            return;
        }
        Uri u = Uri.parse(url);
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, u).setPackage("com.android.chrome")
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
            return;
        } catch (Exception ignored) { }
        Intent chooser = Intent.createChooser(new Intent(Intent.ACTION_VIEW, u), "Hangi tarayıcıda açılsın?");
        chooser.putExtra(Intent.EXTRA_EXCLUDE_COMPONENTS,
                new ComponentName[]{new ComponentName(this, MainActivity.class)});
        try {
            startActivity(chooser);
        } catch (Exception e) {
            toast("Başka bir tarayıcı bulunamadı");
        }
    }

    // ------------------------------------------------------------------ sayfa yakınlaştırma

    /** Sayfaya bilgisayar ekranı genişliği verir; yakınlaştırma düştükçe sayfa genişler ve küçülür. */
    String viewportJs() {
        float d = getResources().getDisplayMetrics().density;
        int px = webContainer.getWidth();
        if (px <= 0) px = getResources().getDisplayMetrics().widthPixels;
        int css = Math.max(320, Math.round(px / d));
        int w = Math.round(css * 100f / zoom);
        String sc = String.format(Locale.US, "%.4f", css / (float) w);
        return "(function(){window.__mdvpC='width=" + w + ", initial-scale=" + sc
                + ", minimum-scale=" + sc + ", user-scalable=yes';"
                + "function ap(){var c=window.__mdvpC;var h=document.head;if(!h)return;"
                + "var ms=document.querySelectorAll('meta[name=\"viewport\"]');"
                + "if(!ms.length){var m=document.createElement('meta');m.name='viewport';h.appendChild(m);ms=[m];}"
                + "for(var i=0;i<ms.length;i++){if(ms[i].getAttribute('content')!==c)ms[i].setAttribute('content',c);}"
                + "if(!window.__mdvpO){try{window.__mdvpO=new MutationObserver(ap);"
                + "window.__mdvpO.observe(h,{childList:true});}catch(e){}}}"
                + "ap();setTimeout(ap,60);setTimeout(ap,600);"
                + "if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',ap);})();";
    }

    void applyViewportAll() {
        String js = viewportJs();
        for (Tab t : tabs) {
            if (!t.isNewTab && t.pendingUrl == null) t.web.evaluateJavascript(js, null);
        }
    }

    void setZoom(int z) {
        zoom = z;
        prefs.edit().putInt("zoom_v2", z).apply();
        applyViewportAll();
        toast("Yakınlaştırma: %" + z);
    }

    void stepZoom(int dir) {
        int idx = 0;
        for (int i = 0; i < ZOOMS.length; i++) if (ZOOMS[i] <= zoom) idx = i;
        idx = Math.max(0, Math.min(ZOOMS.length - 1, idx + dir));
        if (ZOOMS[idx] != zoom) setZoom(ZOOMS[idx]);
    }

    void zoomDialog() {
        String[] labels = new String[ZOOMS.length];
        int checked = 0;
        for (int i = 0; i < ZOOMS.length; i++) {
            labels[i] = "%" + ZOOMS[i] + (ZOOMS[i] == 100 ? "  (önerilen)" : "");
            if (ZOOMS[i] == zoom) checked = i;
        }
        dlg().setTitle("Sayfa yakınlaştırma")
                .setSingleChoiceItems(labels, checked, (d, which) -> {
                    setZoom(ZOOMS[which]);
                    d.dismiss();
                })
                .setNegativeButton("Kapat", null).show();
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        webContainer.postDelayed(this::applyViewportAll, 350);
    }

    @Override
    public boolean dispatchGenericMotionEvent(MotionEvent ev) {
        if (ev.getAction() == MotionEvent.ACTION_SCROLL
                && (ev.getMetaState() & KeyEvent.META_CTRL_ON) != 0) {
            float v = ev.getAxisValue(MotionEvent.AXIS_VSCROLL);
            if (v != 0) {
                stepZoom(v > 0 ? 1 : -1);
                return true;
            }
        }
        return super.dispatchGenericMotionEvent(ev);
    }

    // ------------------------------------------------------------------ reklam engelleyici

    void adBlockDialog() {
        int n = current == null ? 0 : current.blocked.get();
        dlg().setTitle("Reklam engelleyici")
                .setMessage(adBlock
                        ? "Açık. Bu sayfada " + n + " reklam ve izleyici engellendi."
                        : "Kapalı. Reklamlar ve izleyiciler engellenmiyor.")
                .setPositiveButton(adBlock ? "Kapat" : "Aç", (d, w) -> setAdBlock(!adBlock))
                .setNegativeButton("Tamam", null).show();
    }

    void setAdBlock(boolean on) {
        adBlock = on;
        prefs.edit().putBoolean("adblock", on).apply();
        toast(on ? "Reklam engelleyici açıldı" : "Reklam engelleyici kapatıldı");
        if (current != null && !current.isNewTab) current.web.reload();
        updateShield();
    }

    // ------------------------------------------------------------------ kayıtlı veriler

    JSONArray getArr(String key) {
        try {
            return new JSONArray(prefs.getString(key, "[]"));
        } catch (JSONException e) {
            return new JSONArray();
        }
    }

    void putArr(String key, JSONArray a) {
        prefs.edit().putString(key, a.toString()).apply();
    }

    String fmtTime(long ms) {
        return new SimpleDateFormat("d MMM HH:mm", Locale.forLanguageTag("tr")).format(new Date(ms));
    }

    // Oturum (açık sekmeler)

    void saveSession() {
        JSONArray a = new JSONArray();
        int sel = 0;
        for (Tab t : tabs) {
            String u = t.isNewTab ? "newtab" : t.url();
            if (u.isEmpty()) continue;
            if (t == current) sel = a.length();
            JSONObject o = new JSONObject();
            try {
                o.put("u", u);
                o.put("t", t.title == null ? "" : t.title);
            } catch (JSONException ignored) { }
            a.put(o);
        }
        prefs.edit().putString("session", a.toString()).putInt("sessionIdx", sel).apply();
    }

    void restoreSession() {
        JSONArray a = getArr("session");
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o == null) continue;
            String u = o.optString("u");
            if (u.isEmpty()) continue;
            if (u.equals("newtab")) {
                newTab(NEWTAB, false, false);
            } else {
                Tab t = newTab(null, false, false);
                t.pendingUrl = u;
                t.title = o.optString("t", u);
            }
        }
        if (tabs.isEmpty()) {
            newTab(NEWTAB, true, false);
        } else {
            int idx = Math.min(Math.max(prefs.getInt("sessionIdx", 0), 0), tabs.size() - 1);
            Tab sel = tabs.get(idx);
            current = null;
            for (Tab t : tabs) t.web.setVisibility(View.GONE);
            selectTab(sel);
        }
    }

    // Geçmiş

    void addHistory(String title, String url) {
        JSONArray a = getArr("history");
        JSONArray n = new JSONArray();
        JSONObject o = new JSONObject();
        try {
            o.put("t", (title == null || title.isEmpty()) ? url : title);
            o.put("u", url);
            o.put("time", System.currentTimeMillis());
        } catch (JSONException ignored) { }
        n.put(o);
        for (int i = 0; i < a.length() && n.length() < 500; i++) {
            JSONObject x = a.optJSONObject(i);
            if (x != null && !url.equals(x.optString("u"))) n.put(x);
        }
        putArr("history", n);
    }

    void historyDialog() {
        final JSONArray a = getArr("history");
        if (a.length() == 0) {
            toast("Geçmiş boş");
            return;
        }
        String[] items = new String[a.length()];
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            items[i] = o == null ? "" : o.optString("t") + "\n" + fmtTime(o.optLong("time"))
                    + "   " + o.optString("u");
        }
        dlg().setTitle("Geçmiş")
                .setItems(items, (d, which) -> {
                    JSONObject o = a.optJSONObject(which);
                    if (o != null) load(current, o.optString("u"));
                })
                .setNeutralButton("Geçmişi temizle", (d, w) -> {
                    putArr("history", new JSONArray());
                    toast("Geçmiş temizlendi");
                })
                .setNegativeButton("Kapat", null).show();
    }

    // Yer imleri

    int bookmarkIndex(String url) {
        JSONArray a = getArr("bookmarks");
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o != null && url.equals(o.optString("u"))) return i;
        }
        return -1;
    }

    void toggleBookmark() {
        if (current == null) return;
        String url = current.url();
        if (url.isEmpty()) {
            toast("Yeni sekme sayfası yer imlerine eklenemez");
            return;
        }
        int idx = bookmarkIndex(url);
        if (idx >= 0) {
            removeBookmark(idx);
            toast("Yer imi kaldırıldı");
            return;
        }
        editBookmarkDialog(-1, current.title, url);
    }

    void removeBookmark(int idx) {
        JSONArray a = getArr("bookmarks");
        if (idx >= 0 && idx < a.length()) a.remove(idx);
        putArr("bookmarks", a);
        refreshBookmarkBar();
        updateToolbar();
    }

    void editBookmarkDialog(final int idx, String title, String url) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(8), dp(20), 0);
        final EditText name = new EditText(this);
        name.setHint("Ad");
        name.setSingleLine(true);
        name.setText(title);
        final EditText adr = new EditText(this);
        adr.setHint("Adres");
        adr.setSingleLine(true);
        adr.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        adr.setText(url);
        box.addView(name);
        box.addView(adr);
        dlg().setTitle(idx < 0 ? "Yer imi ekle" : "Yer imini düzenle")
                .setView(box)
                .setPositiveButton("Kaydet", (d, w) -> {
                    String nm = name.getText().toString().trim();
                    String u = adr.getText().toString().trim();
                    if (u.isEmpty()) return;
                    if (!u.matches("^[a-zA-Z][a-zA-Z0-9+.-]*:.*")) u = "https://" + u;
                    if (nm.isEmpty()) nm = u;
                    JSONArray a = getArr("bookmarks");
                    JSONObject o = new JSONObject();
                    try {
                        o.put("t", nm);
                        o.put("u", u);
                        if (idx >= 0 && idx < a.length()) a.put(idx, o); else a.put(o);
                    } catch (JSONException ignored) { }
                    putArr("bookmarks", a);
                    refreshBookmarkBar();
                    updateToolbar();
                    toast(idx < 0 ? "Yer imlerine eklendi" : "Yer imi kaydedildi");
                })
                .setNegativeButton("İptal", null).show();
    }

    void bookmarkMenu(final int idx) {
        final JSONObject o = getArr("bookmarks").optJSONObject(idx);
        if (o == null) return;
        final String u = o.optString("u");
        dlg().setTitle(o.optString("t"))
                .setItems(new String[]{"Aç", "Yeni sekmede aç", "Düzenle", "Sil"}, (d, which) -> {
                    if (which == 0) load(current, u);
                    else if (which == 1) newTab(u, true, true);
                    else if (which == 2) editBookmarkDialog(idx, o.optString("t"), u);
                    else removeBookmark(idx);
                }).show();
    }

    void bookmarksDialog() {
        JSONArray a = getArr("bookmarks");
        if (a.length() == 0) {
            toast("Henüz yer imi yok. Eklemek için ☆ simgesine dokunun.");
            return;
        }
        String[] items = new String[a.length()];
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            items[i] = o == null ? "" : o.optString("t") + "\n" + o.optString("u");
        }
        dlg().setTitle("Yer imleri")
                .setItems(items, (d, which) -> bookmarkMenu(which))
                .setNegativeButton("Kapat", null).show();
    }

    void refreshBookmarkBar() {
        bookmarkStrip.removeAllViews();
        JSONArray a = getArr("bookmarks");
        if (a.length() == 0) {
            TextView h = new TextView(this);
            h.setText("Yer imi eklemek için adres çubuğundaki ☆ simgesine dokunun");
            h.setTextColor(C_DIM);
            h.setTextSize(12);
            h.setPadding(dp(6), 0, 0, 0);
            bookmarkStrip.addView(h);
            return;
        }
        for (int i = 0; i < a.length(); i++) {
            final JSONObject o = a.optJSONObject(i);
            if (o == null) continue;
            final int idx = i;
            TextView c = new TextView(this);
            c.setText(o.optString("t"));
            c.setTextColor(C_TEXT);
            c.setTextSize(13);
            c.setSingleLine(true);
            c.setEllipsize(TextUtils.TruncateAt.END);
            c.setMaxWidth(dp(180));
            c.setGravity(Gravity.CENTER_VERTICAL);
            c.setPadding(dp(10), 0, dp(10), 0);
            c.setBackground(ripple(false));
            c.setOnClickListener(v -> load(current, o.optString("u")));
            c.setOnLongClickListener(v -> { bookmarkMenu(idx); return true; });
            c.setOnContextClickListener(v -> { bookmarkMenu(idx); return true; });
            bookmarkStrip.addView(c, new LinearLayout.LayoutParams(-2, dp(28)));
        }
    }

    // İndirmeler

    void startDownload(String url, String ua, String cd, String mime) {
        if (url == null || !(url.startsWith("http://") || url.startsWith("https://"))) {
            toast("Bu dosya bu tarayıcıyla indirilemiyor");
            return;
        }
        try {
            String name = URLUtil.guessFileName(url, cd, mime);
            DownloadManager.Request req = new DownloadManager.Request(Uri.parse(url));
            if (mime != null && !mime.isEmpty()) req.setMimeType(mime);
            String cookie = CookieManager.getInstance().getCookie(url);
            if (cookie != null) req.addRequestHeader("Cookie", cookie);
            req.addRequestHeader("User-Agent", ua != null ? ua : UA);
            req.setTitle(name);
            req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name);
            DownloadManager dm = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
            long id = dm.enqueue(req);

            JSONArray a = getArr("downloads");
            JSONArray n = new JSONArray();
            JSONObject o = new JSONObject();
            o.put("id", id);
            o.put("n", name);
            o.put("time", System.currentTimeMillis());
            n.put(o);
            for (int i = 0; i < a.length() && n.length() < 200; i++) n.put(a.opt(i));
            putArr("downloads", n);
            toast("İndiriliyor: " + name);
        } catch (Exception e) {
            toast("İndirme başlatılamadı");
        }
    }

    String dlStatus(DownloadManager dm, long id) {
        try (Cursor c = dm.query(new DownloadManager.Query().setFilterById(id))) {
            if (c != null && c.moveToFirst()) {
                int st = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS));
                if (st == DownloadManager.STATUS_SUCCESSFUL) return "✓";
                if (st == DownloadManager.STATUS_FAILED) return "✕ Başarısız";
                if (st == DownloadManager.STATUS_PAUSED) return "⏸ Duraklatıldı";
                return "⏳ İniyor";
            }
        } catch (Exception ignored) { }
        return "Silinmiş";
    }

    void openDownload(DownloadManager dm, long id) {
        Uri u = dm.getUriForDownloadedFile(id);
        if (u == null) {
            toast("Dosya henüz hazır değil veya silinmiş");
            return;
        }
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setDataAndType(u, dm.getMimeTypeForDownloadedFile(id));
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            startActivity(i);
        } catch (Exception e) {
            toast("Bu dosyayı açacak uygulama yok");
        }
    }

    void downloadsDialog() {
        final JSONArray a = getArr("downloads");
        final DownloadManager dm = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
        AlertDialog.Builder b = dlg().setTitle("İndirilenler")
                .setNeutralButton("Klasörü aç", (d, w) -> {
                    try {
                        startActivity(new Intent(DownloadManager.ACTION_VIEW_DOWNLOADS)
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                    } catch (Exception e) {
                        toast("İndirilenler klasörü açılamadı");
                    }
                })
                .setNegativeButton("Kapat", null);
        if (a.length() == 0) {
            b.setMessage("Henüz bir şey indirmediniz.");
        } else {
            String[] items = new String[a.length()];
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.optJSONObject(i);
                items[i] = o == null ? "" : o.optString("n") + "\n" + dlStatus(dm, o.optLong("id"))
                        + "   " + fmtTime(o.optLong("time"));
            }
            b.setItems(items, (d, which) -> {
                JSONObject o = a.optJSONObject(which);
                if (o != null) openDownload(dm, o.optLong("id"));
            });
            b.setPositiveButton("Listeyi temizle", (d, w) -> putArr("downloads", new JSONArray()));
        }
        b.show();
    }

    // ------------------------------------------------------------------ yeni sekme köprüsü

    class Bridge {
        final Tab t;

        Bridge(Tab t) {
            this.t = t;
        }

        @JavascriptInterface
        public String getTiles() {
            if (!t.isNewTab) return "[]";
            return prefs.getString("tiles", DEFAULT_TILES);
        }

        @JavascriptInterface
        public void saveTiles(String json) {
            if (!t.isNewTab || json == null) return;
            prefs.edit().putString("tiles", json).apply();
        }

        @JavascriptInterface
        public String getBackground() {
            if (!t.isNewTab) return "";
            return readBackground();
        }

        @JavascriptInterface
        public void pickBackground() {
            if (!t.isNewTab) return;
            ui.post(() -> {
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.setType("image/*");
                i.addCategory(Intent.CATEGORY_OPENABLE);
                try {
                    startActivityForResult(Intent.createChooser(i, "Arka plan görseli seç"), REQ_BG);
                } catch (Exception e) {
                    toast("Galeri açılamadı");
                }
            });
        }

        @JavascriptInterface
        public void resetBackground() {
            if (!t.isNewTab) return;
            //noinspection ResultOfMethodCallIgnored
            new File(getFilesDir(), "bg.jpg").delete();
            ui.post(MainActivity.this::reloadNewTabs);
        }
    }

    String readBackground() {
        File f = new File(getFilesDir(), "bg.jpg");
        if (!f.exists()) return "";
        try (FileInputStream in = new FileInputStream(f)) {
            byte[] b = new byte[(int) f.length()];
            int off = 0;
            while (off < b.length) {
                int n = in.read(b, off, b.length - off);
                if (n < 0) break;
                off += n;
            }
            return "data:image/jpeg;base64," + Base64.encodeToString(b, Base64.NO_WRAP);
        } catch (Exception e) {
            return "";
        }
    }

    void saveBackground(Uri u) {
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            try (InputStream in = getContentResolver().openInputStream(u)) {
                BitmapFactory.decodeStream(in, null, o);
            }
            int max = Math.max(o.outWidth, o.outHeight);
            int sample = 1;
            while (max / (sample * 2) >= 2560) sample *= 2;
            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = sample;
            Bitmap bm;
            try (InputStream in = getContentResolver().openInputStream(u)) {
                bm = BitmapFactory.decodeStream(in, null, o2);
            }
            if (bm == null) {
                toast("Bu görsel açılamadı");
                return;
            }
            int rot = 0;
            try (InputStream in = getContentResolver().openInputStream(u)) {
                if (in != null) {
                    ExifInterface ex = new ExifInterface(in);
                    int or = ex.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
                    if (or == ExifInterface.ORIENTATION_ROTATE_90) rot = 90;
                    else if (or == ExifInterface.ORIENTATION_ROTATE_180) rot = 180;
                    else if (or == ExifInterface.ORIENTATION_ROTATE_270) rot = 270;
                }
            } catch (Exception ignored) { }
            Matrix mx = new Matrix();
            float big = Math.max(bm.getWidth(), bm.getHeight());
            if (big > 2560) mx.postScale(2560f / big, 2560f / big);
            if (rot != 0) mx.postRotate(rot);
            if (!mx.isIdentity()) {
                bm = Bitmap.createBitmap(bm, 0, 0, bm.getWidth(), bm.getHeight(), mx, true);
            }
            try (FileOutputStream out = new FileOutputStream(new File(getFilesDir(), "bg.jpg"))) {
                bm.compress(Bitmap.CompressFormat.JPEG, 82, out);
            }
            reloadNewTabs();
            toast("Arka plan değiştirildi");
        } catch (Exception e) {
            toast("Görsel kaydedilemedi");
        }
    }

    void reloadNewTabs() {
        for (Tab t : tabs) if (t.isNewTab) t.web.reload();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_FILE) {
            if (fileCb == null) return;
            Uri[] out = null;
            if (resultCode == RESULT_OK && data != null) {
                if (data.getClipData() != null) {
                    int n = data.getClipData().getItemCount();
                    out = new Uri[n];
                    for (int i = 0; i < n; i++) out[i] = data.getClipData().getItemAt(i).getUri();
                } else if (data.getData() != null) {
                    out = new Uri[]{data.getData()};
                }
            }
            fileCb.onReceiveValue(out);
            fileCb = null;
        } else if (requestCode == REQ_BG && resultCode == RESULT_OK && data != null && data.getData() != null) {
            saveBackground(data.getData());
        }
    }

    // ------------------------------------------------------------------ tuşlar

    @Override
    public boolean dispatchKeyEvent(KeyEvent e) {
        if (e.getAction() == KeyEvent.ACTION_DOWN && current != null) {
            int k = e.getKeyCode();
            if (e.isCtrlPressed()) {
                switch (k) {
                    case KeyEvent.KEYCODE_T: newTab(NEWTAB, true, false); return true;
                    case KeyEvent.KEYCODE_W: closeTab(current); return true;
                    case KeyEvent.KEYCODE_L:
                        address.requestFocus();
                        address.selectAll();
                        return true;
                    case KeyEvent.KEYCODE_R: current.web.reload(); return true;
                    case KeyEvent.KEYCODE_D: toggleBookmark(); return true;
                    case KeyEvent.KEYCODE_H: historyDialog(); return true;
                    case KeyEvent.KEYCODE_J: downloadsDialog(); return true;
                    case KeyEvent.KEYCODE_EQUALS:
                    case KeyEvent.KEYCODE_PLUS:
                    case KeyEvent.KEYCODE_NUMPAD_ADD: stepZoom(1); return true;
                    case KeyEvent.KEYCODE_MINUS:
                    case KeyEvent.KEYCODE_NUMPAD_SUBTRACT: stepZoom(-1); return true;
                    case KeyEvent.KEYCODE_0:
                    case KeyEvent.KEYCODE_NUMPAD_0: setZoom(100); return true;
                    case KeyEvent.KEYCODE_TAB: {
                        int i = tabs.indexOf(current), n = tabs.size();
                        selectTab(tabs.get(e.isShiftPressed() ? (i - 1 + n) % n : (i + 1) % n));
                        return true;
                    }
                    default: break;
                }
            }
            if (k == KeyEvent.KEYCODE_F5) {
                current.web.reload();
                return true;
            }
            if (e.isAltPressed() && k == KeyEvent.KEYCODE_DPAD_LEFT) {
                if (current.web.canGoBack()) current.web.goBack();
                return true;
            }
            if (e.isAltPressed() && k == KeyEvent.KEYCODE_DPAD_RIGHT) {
                if (current.web.canGoForward()) current.web.goForward();
                return true;
            }
        }
        return super.dispatchKeyEvent(e);
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (customView != null) {
            hideFullscreen();
            return;
        }
        if (address.hasFocus()) {
            address.clearFocus();
            hideKeyboard();
            updateToolbar();
            return;
        }
        if (current != null && current.web.canGoBack()) {
            current.web.goBack();
            return;
        }
        super.onBackPressed();
    }
}
