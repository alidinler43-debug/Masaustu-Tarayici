package com.alidinler.masaustu;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ComponentName;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.media.ExifInterface;
import android.media.MediaCodec;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Environment;
import android.os.Looper;
import android.os.Message;
import android.os.SystemClock;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.text.InputType;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebStorage;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;
import org.mozilla.geckoview.AllowOrDeny;
import org.mozilla.geckoview.BasicSelectionActionDelegate;
import org.mozilla.geckoview.ContentBlocking;
import org.mozilla.geckoview.GeckoResult;
import org.mozilla.geckoview.GeckoRuntime;
import org.mozilla.geckoview.GeckoRuntimeSettings;
import org.mozilla.geckoview.GeckoSession;
import org.mozilla.geckoview.GeckoSession.PromptDelegate.AlertPrompt;
import org.mozilla.geckoview.GeckoSession.PromptDelegate.AuthPrompt;
import org.mozilla.geckoview.GeckoSession.PromptDelegate.ButtonPrompt;
import org.mozilla.geckoview.GeckoSession.PromptDelegate.ChoicePrompt;
import org.mozilla.geckoview.GeckoSession.PromptDelegate.FilePrompt;
import org.mozilla.geckoview.GeckoSession.PromptDelegate.PromptResponse;
import org.mozilla.geckoview.GeckoSession.PromptDelegate.TextPrompt;
import org.mozilla.geckoview.GeckoSessionSettings;
import org.mozilla.geckoview.GeckoView;
import org.mozilla.geckoview.GeckoWebExecutor;
import org.mozilla.geckoview.StorageController;
import org.mozilla.geckoview.WebExtension;
import org.mozilla.geckoview.WebExtensionController;
import org.mozilla.geckoview.WebRequest;
import org.mozilla.geckoview.WebRequestError;
import org.mozilla.geckoview.WebResponse;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.regex.Pattern;

public class MainActivity extends Activity {

    static final int REQ_FILE = 11, REQ_BG = 12, REQ_FILE_WEB = 13;
    static final String CHROME_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
            + "(KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36";
    static final String HIDE_JS =
            "(function(){if(document.getElementById('__md_ab'))return;"
            + "var s=document.createElement('style');s.id='__md_ab';"
            + "s.textContent='ins.adsbygoogle,.adsbygoogle,[id^=\\\"div-gpt-ad\\\"],[id^=\\\"google_ads_iframe\\\"],"
            + "iframe[src*=\\\"doubleclick.net\\\"],iframe[src*=\\\"googlesyndication\\\"],[id^=\\\"taboola-\\\"],"
            + ".trc_rbox_container,.OUTBRAIN{display:none!important}';"
            + "(document.head||document.documentElement).appendChild(s);})();";
    static final HashSet<String> AD_HOSTS = new HashSet<>();

    static final int C_BAR = 0xFF1C1C1F, C_TOOL = 0xFF2B2B30, C_FIELD = 0xFF3B3B42,
            C_TEXT = 0xFFEDEDF0, C_DIM = 0xFF9C9CA5, C_ACCENT = 0xFFFFCC00;
    static final int[] TILE_COLORS = {0xFFE8453C, 0xFFF4A100, 0xFF1E88E5, 0xFF43A047, 0xFF8E24AA,
            0xFF00897B, 0xFFF4511E, 0xFF3949AB, 0xFFD81B60, 0xFF6D4C41};

    static final String DEFAULT_TILES = "["
            + "{\"t\":\"Google\",\"u\":\"https://www.google.com\"},"
            + "{\"t\":\"YouTube\",\"u\":\"https://www.youtube.com\"},"
            + "{\"t\":\"TradingView\",\"u\":\"https://www.tradingview.com\"},"
            + "{\"t\":\"Vikipedi\",\"u\":\"https://tr.wikipedia.org\"},"
            + "{\"t\":\"Yandex\",\"u\":\"https://yandex.com.tr\"},"
            + "{\"t\":\"GitHub\",\"u\":\"https://github.com\"},"
            + "{\"t\":\"Gmail\",\"u\":\"https://mail.google.com\"},"
            + "{\"t\":\"Hava durumu\",\"u\":\"https://www.mgm.gov.tr\"}"
            + "]";

    static final int[] ZOOMS = {67, 75, 80, 90, 100, 110, 125, 150};
    static final int ENG_WEB = 0, ENG_GECKO = 1;
    static final int AT_ON = ContentBlocking.AntiTracking.DEFAULT
            | ContentBlocking.AntiTracking.CRYPTOMINING
            | ContentBlocking.AntiTracking.FINGERPRINTING;

    // Motor işlem başına bir kez açılır.
    static GeckoRuntime runtime;
    static WebExtension adExt;
    static String desktopUa;
    static GeckoWebExecutor executor;
    static GeckoSession spareSession;
    static final HashMap<String, Preload> preloads = new HashMap<>();
    ProgressBar ntSpinner;

    /** Arka planda önceden açılmış bir Google sayfası (YouTube, Gmail). */
    static class Preload {
        GeckoSession s;
        String url, title;
        long time;
        boolean attached;   // ekrana bağlı (gerçek boyutta) yüklendi mi
    }

    final ArrayList<Tab> tabs = new ArrayList<>();
    final Handler ui = new Handler(Looper.getMainLooper());
    Tab current;
    SharedPreferences prefs;
    boolean adBlock;
    boolean spViewport, spPre, spGecko, spTimer, spPreload;
    int zoom;

    LinearLayout mainLayout, tabBar, toolBar, tabStrip, bookmarkStrip;
    HorizontalScrollView tabScroll, bmScroll;
    FrameLayout webContainer;
    GeckoView geckoView;
    EditText address;
    TextView backBtn, fwdBtn, starBtn, shieldBtn, tileBtn, videoBtn;
    ProgressBar progress;

    FrameLayout ntRoot;
    ImageView ntBg;
    View ntShade;
    TextView ntClock, ntDate;
    EditText ntSearch;
    GridLayout ntGrid;
    Bitmap bgCache;
    boolean bgLoaded;

    FrameLayout fullContainer;
    View customView;
    WebChromeClient.CustomViewCallback customCb;
    ValueCallback<Uri[]> webFileCb;

    FilePrompt pendingFile;
    GeckoResult<PromptResponse> pendingFileResult;

    class Tab {
        GeckoSession session;      // Firefox motoru (Google hesap siteleri)
        WebView web;               // hızlı motor (diğer bütün siteler)
        boolean gecko;             // şu an hangi motor görünüyor
        Boolean backTo;            // motor değişince geri tuşu diğer motora döner
        Tab opener;                // bu sekmeyi açılır pencere olarak açan sekme
        String webUrl, geckoUrl, webTitle, geckoTitle;
        String url = "";
        String title = "Yeni sekme";
        String pendingUrl;
        boolean isNewTab = true;
        boolean canBack, canFwd, fullscreen;   // Firefox motorunun geri/ileri durumu
        int progress = 100;
        final AtomicInteger blocked = new AtomicInteger();
        long loadStart;
        final List<String> netVideos = Collections.synchronizedList(new ArrayList<>());
        boolean hasVideo;
        boolean geckoPainted = true;   // Firefox motoru ilk görüntüyü çizdi mi
        boolean coverWithNewTab;        // çizene kadar yeni sekme sayfası ekranda kalsın
        LinearLayout view;
        TextView titleView;

        String url() {
            if (pendingUrl != null) return pendingUrl;
            if (isNewTab) return "";
            return url == null ? "" : url;
        }
    }

    // ------------------------------------------------------------------ yaşam döngüsü

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("tarayici", MODE_PRIVATE);
        adBlock = prefs.getBoolean("adblock", true);
        zoom = prefs.getInt("zoom_v2", 100);
        loadAdHosts();
        loadSpeedPrefs();
        loadTasks();
        getWindow().setStatusBarColor(C_BAR);
        getWindow().setNavigationBarColor(C_TOOL);
        buildUi();
        restoreSession();
        if (savedInstanceState == null) handleIntent(getIntent());
        ui.post(clockTick);
        scheduleWarm(2500);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        handleIntent(intent);
    }

    void handleIntent(Intent in) {
        if (in != null && Intent.ACTION_VIEW.equals(in.getAction()) && in.getData() != null) {
            newTab(in.getData().toString(), true, false);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        saveSession();
        CookieManager.getInstance().flush();
    }

    @Override
    protected void onDestroy() {
        ui.removeCallbacks(clockTick);
        for (Tab t : tabs) {
            if (t.web != null) {
                try { t.web.destroy(); } catch (Exception ignored) { }
            }
        }
        try { geckoView.releaseSession(); } catch (Exception ignored) { }
        for (Tab t : tabs) {
            if (t.session != null) {
                try { t.session.close(); } catch (Exception ignored) { }
            }
        }
        super.onDestroy();
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        webContainer.postDelayed(this::applyViewportAll, 350);
        if (current != null && current.isNewTab) ui.postDelayed(this::refreshNewTab, 200);
    }

    void ensureRuntime() {
        if (runtime != null) return;
        float density = getResources().getDisplayMetrics().density;
        ContentBlocking.Settings cb = new ContentBlocking.Settings.Builder()
                .antiTracking(adBlock ? AT_ON : ContentBlocking.AntiTracking.NONE)
                .enhancedTrackingProtectionLevel(adBlock ? ContentBlocking.EtpLevel.DEFAULT
                        : ContentBlocking.EtpLevel.NONE)
                .cookieBehavior(ContentBlocking.CookieBehavior.ACCEPT_NON_TRACKERS)
                .build();
        GeckoRuntimeSettings.Builder b = new GeckoRuntimeSettings.Builder()
                .javaScriptEnabled(true)
                .consoleOutput(false)
                .remoteDebuggingEnabled(false)
                .fontInflation(false)
                .preferredColorScheme(GeckoRuntimeSettings.COLOR_SCHEME_SYSTEM)
                .locales(new String[]{"tr-TR", "tr", "en-US", "en"})
                .contentBlocking(cb);
        runtime = GeckoRuntime.create(getApplicationContext(), b.build());

        runtime.getWebExtensionController()
                .ensureBuiltIn("resource://android/assets/adblock/", "adblock@masaustu")
                .accept(ext -> {
                    adExt = ext;
                    if (!adBlock) setExtEnabled(false);
                }, e -> { });

        String def = GeckoSession.getDefaultUserAgent();
        Matcher m = Pattern.compile("rv:([0-9.]+)").matcher(def == null ? "" : def);
        String v = m.find() ? m.group(1) : "140.0";
        desktopUa = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:" + v + ") Gecko/20100101 Firefox/" + v;
    }

    void loadSpeedPrefs() {
        spViewport = prefs.getBoolean("sp_vp", true);
        spPre = prefs.getBoolean("sp_pre", true);
        spGecko = prefs.getBoolean("sp_gecko", true);
        spTimer = prefs.getBoolean("sp_timer", true);
        spPreload = prefs.getBoolean("sp_preload", true);
    }

    boolean useGeckoFor(String url) {
        return spGecko && (isGoogleAccountUrl(url) || inGeckoSites(url));
    }

    // "Google ile giriş" yapılan siteler: oturum Firefox motorunda açıldığı için bu siteler hep orada açılır.
    final HashSet<String> geckoSites = new HashSet<>();
    boolean geckoSitesLoaded;

    static String baseDomain(String host) {
        if (host == null) return "";
        String h = host.toLowerCase(Locale.ROOT);
        if (h.startsWith("www.")) h = h.substring(4);
        String[] p = h.split("\\.");
        if (p.length <= 2) return h;
        String sld = p[p.length - 2];
        boolean cc = p[p.length - 1].length() == 2 && java.util.Arrays.asList(
                "com", "net", "org", "gov", "edu", "co", "gen", "web", "bel", "av", "k12", "biz", "info", "tv")
                .contains(sld);
        int keep = cc ? 3 : 2;
        StringBuilder b = new StringBuilder();
        for (int i = p.length - keep; i < p.length; i++) {
            if (b.length() > 0) b.append('.');
            b.append(p[i]);
        }
        return b.toString();
    }

    boolean inGeckoSites(String url) {
        if (url == null || !url.startsWith("http")) return false;
        if (!geckoSitesLoaded) {
            geckoSitesLoaded = true;
            JSONArray a = getArr("gecko_sites");
            for (int i = 0; i < a.length(); i++) geckoSites.add(a.optString(i));
        }
        if (geckoSites.isEmpty()) return false;
        return geckoSites.contains(baseDomain(hostOf(url)));
    }

    static boolean isGoogleOAuthUrl(String url) {
        if (url == null || !url.startsWith("https://accounts.google.com/")) return false;
        return url.contains("oauth") || url.contains("client_id=") || url.contains("/gsi/");
    }

    /**
     * Bir site "Google ile giriş yap" başlattığında: o siteyi Firefox motoruna taşır ve hatırlar.
     * Giriş (ve sitenin oturum çerezleri) baştan sona aynı motorda yapılır; yarım kalmaz.
     */
    void moveSiteToGecko(Tab t, String originUrl) {
        String base = baseDomain(hostOf(originUrl == null ? "" : originUrl));
        if (base.isEmpty()) return;
        inGeckoSites(originUrl);
        geckoSites.add(base);
        JSONArray a = new JSONArray();
        for (String g : geckoSites) a.put(g);
        putArr("gecko_sites", a);
        Tab target = t;
        if (t.opener != null && tabs.contains(t.opener)) {
            target = t.opener;
            closeTab(t);
            selectTab(target);
        }
        String reload = target.webUrl != null ? target.webUrl : originUrl;
        load(target, reload);
        dlg().setTitle("Google ile giriş")
                .setMessage(base + " artık Google hesabınla giriş yapılabilen motorda açılıyor ve bu tercih "
                        + "hatırlanacak.\n\nSayfa yeniden yüklendi. \"Google ile giriş yap\" düğmesine bir kez daha bas.")
                .setPositiveButton("Tamam", null).show();
    }

    void startTimer(Tab t) {
        t.loadStart = SystemClock.elapsedRealtime();
    }

    void stopTimer(Tab t, String engine) {
        if (t.loadStart == 0) return;
        long ms = SystemClock.elapsedRealtime() - t.loadStart;
        t.loadStart = 0;
        if (spTimer && t == current && !t.isNewTab) {
            toast("Açılış: " + String.format(new Locale("tr", "TR"), "%.1f", ms / 1000f) + " sn (" + engine + ")");
        }
    }

    /** Hız ayarları: her biri ayrı açılıp kapatılabilir, açılış süresi ekranda ölçülür. */
    void speedDialog() {
        final String[] labels = {
                "Masaüstü genişlik ayarı (sayfaya ek kod çalıştırır)",
                "Sayfayı önceden çiz (akıcı kaydırma, daha çok bellek)",
                "Gmail ve YouTube'u Firefox motorunda aç (hesaba giriş için)",
                "Her sayfanın açılış süresini göster",
                "YouTube ve Gmail'i önceden yükle (anında açılır, biraz daha fazla internet)"};
        final boolean[] on = {spViewport, spPre, spGecko, spTimer, spPreload};
        dlg().setTitle("Hız ayarları")
                .setMultiChoiceItems(labels, on, (d, which, checked) -> on[which] = checked)
                .setPositiveButton("Kaydet", (d, w) -> saveSpeed(on[0], on[1], on[2], on[3], on[4]))
                .setNeutralButton("İlk sürümdeki gibi", (d, w) -> saveSpeed(false, false, false, true, false))
                .setNegativeButton("İptal", null)
                .show();
    }

    void saveSpeed(boolean vp, boolean pre, boolean gk, boolean tm, boolean pl) {
        prefs.edit().putBoolean("sp_vp", vp).putBoolean("sp_pre", pre)
                .putBoolean("sp_gecko", gk).putBoolean("sp_timer", tm).putBoolean("sp_preload", pl).apply();
        loadSpeedPrefs();
        if (!spPreload || !spGecko) dropPreloads();
        showContent();
        toast("Hız ayarları kaydedildi. Değişiklik yeni açılan sayfalarda geçerli.");
    }

    void loadAdHosts() {
        if (!AD_HOSTS.isEmpty()) return;
        try (InputStream in = getAssets().open("adblock/rules.json")) {
            java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            JSONArray rules = new JSONArray(bo.toString("UTF-8"));
            JSONArray d = rules.getJSONObject(0).getJSONObject("condition").getJSONArray("requestDomains");
            for (int i = 0; i < d.length(); i++) AD_HOSTS.add(d.getString(i));
        } catch (Exception ignored) { }
    }

    static boolean isAdHost(String host) {
        if (host == null) return false;
        String h = host.toLowerCase(Locale.ROOT);
        while (true) {
            if (AD_HOSTS.contains(h)) return true;
            int dot = h.indexOf('.');
            if (dot < 0 || dot == h.length() - 1) return false;
            h = h.substring(dot + 1);
        }
    }

    /** Google hesabı isteyen siteler Firefox motorunda açılır; Google bunlara başka motordan girişe izin vermiyor. */
    static boolean isGoogleAccountUrl(String url) {
        if (url == null || !url.startsWith("http")) return false;
        String h;
        try { h = Uri.parse(url).getHost(); } catch (Exception e) { return false; }
        if (h == null) return false;
        h = h.toLowerCase(Locale.ROOT);
        String[] exact = {"accounts.google.com", "mail.google.com", "myaccount.google.com", "drive.google.com",
                "docs.google.com", "photos.google.com", "calendar.google.com", "contacts.google.com",
                "keep.google.com", "meet.google.com", "chat.google.com", "play.google.com",
                "gemini.google.com", "notebooklm.google.com", "accounts.youtube.com"};
        for (String e : exact) if (h.equals(e)) return true;
        String[] suffix = {"youtube.com", "youtu.be", "gmail.com"};
        for (String sfx : suffix) if (h.equals(sfx) || h.endsWith("." + sfx)) return true;
        return false;
    }

    void setExtEnabled(boolean on) {
        if (adExt == null) return;
        try {
            WebExtensionController c = runtime.getWebExtensionController();
            GeckoResult<WebExtension> r = on
                    ? c.enable(adExt, WebExtensionController.EnableSource.USER)
                    : c.disable(adExt, WebExtensionController.EnableSource.USER);
            r.accept(ext -> { if (ext != null) adExt = ext; }, e -> { });
        } catch (Exception ignored) { }
    }

    // ------------------------------------------------------------------ arayüz yardımcıları

    int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    Drawable ripple(boolean borderless) {
        TypedValue tv = new TypedValue();
        getTheme().resolveAttribute(borderless
                ? android.R.attr.selectableItemBackgroundBorderless
                : android.R.attr.selectableItemBackground, tv, true);
        return getDrawable(tv.resourceId);
    }

    GradientDrawable round(int color, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    TextView iconBtn(String s, int sp) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(C_TEXT);
        t.setGravity(Gravity.CENTER);
        t.setBackground(ripple(true));
        t.setClickable(true);
        return t;
    }

    void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    AlertDialog.Builder dlg() {
        return new AlertDialog.Builder(this);
    }

    void hideKeyboard(View v) {
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
    }

    static String nz(String s, String d) {
        return (s == null || s.isEmpty()) ? d : s;
    }

    // ------------------------------------------------------------------ arayüz

    void buildUi() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(C_BAR);

        mainLayout = new LinearLayout(this);
        mainLayout.setOrientation(LinearLayout.VERTICAL);
        mainLayout.setBackgroundColor(C_TOOL);
        root.addView(mainLayout, new FrameLayout.LayoutParams(-1, -1));
        fullContainer = new FrameLayout(this);
        fullContainer.setBackgroundColor(Color.BLACK);
        fullContainer.setVisibility(View.GONE);
        root.addView(fullContainer, new FrameLayout.LayoutParams(-1, -1));

        // Sekme şeridi
        tabBar = new LinearLayout(this);
        tabBar.setOrientation(LinearLayout.HORIZONTAL);
        tabBar.setBackgroundColor(C_BAR);
        tabBar.setPadding(dp(6), dp(6), dp(6), 0);
        tabBar.setGravity(Gravity.BOTTOM);
        tabScroll = new HorizontalScrollView(this);
        tabScroll.setHorizontalScrollBarEnabled(false);
        tabStrip = new LinearLayout(this);
        tabStrip.setOrientation(LinearLayout.HORIZONTAL);
        tabScroll.addView(tabStrip, new FrameLayout.LayoutParams(-2, -1));
        tabBar.addView(tabScroll, new LinearLayout.LayoutParams(0, dp(38), 1f));
        TextView plus = iconBtn("+", 22);
        plus.setOnClickListener(v -> newTab(null, true, false));
        tabBar.addView(plus, new LinearLayout.LayoutParams(dp(44), dp(38)));
        mainLayout.addView(tabBar, new LinearLayout.LayoutParams(-1, -2));

        // Araç çubuğu
        toolBar = new LinearLayout(this);
        toolBar.setOrientation(LinearLayout.HORIZONTAL);
        toolBar.setBackgroundColor(C_TOOL);
        toolBar.setGravity(Gravity.CENTER_VERTICAL);
        toolBar.setPadding(dp(6), dp(5), dp(6), dp(5));
        backBtn = iconBtn("←", 20);
        backBtn.setOnClickListener(v -> goBack());
        fwdBtn = iconBtn("→", 20);
        fwdBtn.setOnClickListener(v -> goForward());
        TextView reload = iconBtn("↻", 20);
        reload.setOnClickListener(v -> reload());
        TextView home = iconBtn("⌂", 22);
        home.setOnClickListener(v -> goHome());
        for (TextView b : new TextView[]{backBtn, fwdBtn, reload, home}) {
            toolBar.addView(b, new LinearLayout.LayoutParams(dp(42), dp(40)));
        }

        address = new EditText(this);
        address.setSingleLine(true);
        address.setTextColor(C_TEXT);
        address.setHintTextColor(C_DIM);
        address.setHint("Arama yapın veya adres yazın");
        address.setTextSize(15);
        address.setBackground(round(C_FIELD, 20));
        address.setPadding(dp(16), 0, dp(48), 0);
        address.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        address.setImeOptions(EditorInfo.IME_ACTION_GO | EditorInfo.IME_FLAG_NO_EXTRACT_UI);
        address.setSelectAllOnFocus(true);
        address.setOnEditorActionListener((v, id, ev) -> {
            boolean enter = ev != null && ev.getKeyCode() == KeyEvent.KEYCODE_ENTER;
            if (id == EditorInfo.IME_ACTION_GO || (enter && ev.getAction() == KeyEvent.ACTION_DOWN)) {
                go(address.getText().toString());
                return true;
            }
            return enter;
        });
        address.setOnFocusChangeListener((v, has) -> { if (!has) updateToolbar(); });
        // Adres kutusu ve sağ ucundaki "ana sayfaya ekle" düğmesi
        FrameLayout addrBox = new FrameLayout(this);
        addrBox.addView(address, new FrameLayout.LayoutParams(-1, -1));
        tileBtn = iconBtn("⊞", 20);
        tileBtn.setOnClickListener(v -> toggleTile());
        tileBtn.setOnLongClickListener(v -> {
            toast("Bu siteyi ana sayfadaki kutucuklara ekler veya kaldırır");
            return true;
        });
        addrBox.addView(tileBtn, new FrameLayout.LayoutParams(dp(42), dp(38), Gravity.END | Gravity.CENTER_VERTICAL));
        LinearLayout.LayoutParams alp = new LinearLayout.LayoutParams(0, dp(38), 1f);
        alp.leftMargin = dp(6);
        alp.rightMargin = dp(6);
        toolBar.addView(addrBox, alp);

        videoBtn = iconBtn("⬇", 19);
        videoBtn.setOnClickListener(v -> videoButton());
        videoBtn.setOnLongClickListener(v -> {
            toast("Sayfadaki videoyu indir");
            return true;
        });
        toolBar.addView(videoBtn, new LinearLayout.LayoutParams(dp(42), dp(40)));

        shieldBtn = iconBtn("🛡", 15);
        shieldBtn.setOnClickListener(v -> adBlockDialog());
        toolBar.addView(shieldBtn, new LinearLayout.LayoutParams(dp(60), dp(40)));
        starBtn = iconBtn("☆", 22);
        starBtn.setOnClickListener(v -> toggleBookmark());
        toolBar.addView(starBtn, new LinearLayout.LayoutParams(dp(42), dp(40)));
        final TextView menu = iconBtn("⋮", 22);
        menu.setOnClickListener(v -> showMenu(menu));
        toolBar.addView(menu, new LinearLayout.LayoutParams(dp(42), dp(40)));
        mainLayout.addView(toolBar, new LinearLayout.LayoutParams(-1, -2));

        // Yer imleri çubuğu
        bmScroll = new HorizontalScrollView(this);
        bmScroll.setHorizontalScrollBarEnabled(false);
        bmScroll.setBackgroundColor(C_TOOL);
        bookmarkStrip = new LinearLayout(this);
        bookmarkStrip.setOrientation(LinearLayout.HORIZONTAL);
        bookmarkStrip.setGravity(Gravity.CENTER_VERTICAL);
        bookmarkStrip.setPadding(dp(8), 0, dp(8), dp(2));
        bmScroll.addView(bookmarkStrip, new FrameLayout.LayoutParams(-2, -1));
        mainLayout.addView(bmScroll, new LinearLayout.LayoutParams(-1, dp(34)));

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        progress.setProgressTintList(ColorStateList.valueOf(C_ACCENT));
        progress.setProgressBackgroundTintList(ColorStateList.valueOf(C_TOOL));
        progress.setVisibility(View.INVISIBLE);
        mainLayout.addView(progress, new LinearLayout.LayoutParams(-1, dp(3)));

        webContainer = new FrameLayout(this);
        webContainer.setBackgroundColor(Color.WHITE);
        geckoView = new GeckoView(this);
        geckoView.setVisibility(View.GONE);
        webContainer.addView(geckoView, new FrameLayout.LayoutParams(-1, -1));
        buildNewTabPage();
        webContainer.addView(ntRoot, new FrameLayout.LayoutParams(-1, -1));
        mainLayout.addView(webContainer, new LinearLayout.LayoutParams(-1, 0, 1f));

        setContentView(root);
        refreshBookmarkBar();
    }

    // ------------------------------------------------------------------ yeni sekme sayfası (uygulamanın içinde çizilir)

    void buildNewTabPage() {
        ntRoot = new FrameLayout(this);
        ntRoot.setBackgroundColor(0xFF16161B);
        ntRoot.setClickable(true);

        ntBg = new ImageView(this);
        ntBg.setScaleType(ImageView.ScaleType.CENTER_CROP);
        ntRoot.addView(ntBg, new FrameLayout.LayoutParams(-1, -1));

        ntShade = new View(this);
        ntShade.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0x47000000, 0x1F000000, 0x61000000}));
        ntRoot.addView(ntShade, new FrameLayout.LayoutParams(-1, -1));

        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER_HORIZONTAL);
        col.setPadding(dp(28), dp(64), dp(28), dp(60));

        ntClock = new TextView(this);
        ntClock.setTextColor(0xFFF6F6F8);
        ntClock.setTextSize(84);
        ntClock.setTypeface(Typeface.create("sans-serif-thin", Typeface.NORMAL));
        ntClock.setShadowLayer(24, 0, 2, 0x59000000);
        ntClock.setGravity(Gravity.CENTER_HORIZONTAL);
        ntClock.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        col.addView(ntClock, new LinearLayout.LayoutParams(-1, -2));

        ntDate = new TextView(this);
        ntDate.setTextColor(0xCCF6F6F8);
        ntDate.setTextSize(17);
        ntDate.setShadowLayer(10, 0, 1, 0x66000000);
        ntDate.setGravity(Gravity.CENTER_HORIZONTAL);
        ntDate.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        col.addView(ntDate, new LinearLayout.LayoutParams(-1, -2));

        ntSearch = new EditText(this);
        ntSearch.setSingleLine(true);
        ntSearch.setHint("Google’da ara veya adres yaz");
        ntSearch.setHintTextColor(0xFF7A7A84);
        ntSearch.setTextColor(0xFF1C1C1F);
        ntSearch.setTextSize(17);
        ntSearch.setBackground(round(0xF0FFFFFF, 27));
        ntSearch.setPadding(dp(24), 0, dp(24), 0);
        ntSearch.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        ntSearch.setImeOptions(EditorInfo.IME_ACTION_GO | EditorInfo.IME_FLAG_NO_EXTRACT_UI);
        ntSearch.setElevation(dp(6));
        ntSearch.setOnEditorActionListener((v, id, ev) -> {
            boolean enter = ev != null && ev.getKeyCode() == KeyEvent.KEYCODE_ENTER;
            if (id == EditorInfo.IME_ACTION_GO || (enter && ev.getAction() == KeyEvent.ACTION_DOWN)) {
                String q = ntSearch.getText().toString();
                ntSearch.setText("");
                hideKeyboard(ntSearch);
                go(q);
                return true;
            }
            return enter;
        });
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(dp(680), dp(54));
        slp.topMargin = dp(34);
        slp.bottomMargin = dp(40);
        col.addView(ntSearch, slp);

        ntGrid = new GridLayout(this);
        col.addView(ntGrid, new LinearLayout.LayoutParams(dp(1060), -2));

        sv.addView(col, new FrameLayout.LayoutParams(-1, -2));
        ntRoot.addView(sv, new FrameLayout.LayoutParams(-1, -1));

        TextView bgBtn = new TextView(this);
        bgBtn.setText("Arka plan");
        bgBtn.setTextColor(0xFFF6F6F8);
        bgBtn.setTextSize(14);
        bgBtn.setGravity(Gravity.CENTER);
        bgBtn.setPadding(dp(16), 0, dp(16), 0);
        GradientDrawable pill = round(0x6B18181E, 19);
        pill.setStroke(dp(1), 0x29FFFFFF);
        bgBtn.setBackground(pill);
        bgBtn.setForeground(ripple(false));
        bgBtn.setOnClickListener(v -> backgroundPicker());
        ntSpinner = new ProgressBar(this);
        ntSpinner.setIndeterminate(true);
        ntSpinner.setIndeterminateTintList(ColorStateList.valueOf(C_ACCENT));
        ntSpinner.setVisibility(View.GONE);
        ntRoot.addView(ntSpinner, new FrameLayout.LayoutParams(dp(56), dp(56), Gravity.CENTER));

        FrameLayout.LayoutParams blp = new FrameLayout.LayoutParams(-2, dp(38), Gravity.TOP | Gravity.END);
        blp.topMargin = dp(16);
        blp.rightMargin = dp(18);
        ntRoot.addView(bgBtn, blp);
    }

    static final String[] BG_FILES = {"bg1.jpg", "bg2.jpg", "bg3.jpg", "bg4.jpg", "bg5.jpg"};

    /** Seçili arka planı yükler: hazır görsellerden biri, galeriden seçilen ya da varsayılan renk geçişi. */
    Bitmap loadBgBitmap() {
        File f = new File(getFilesDir(), "bg.jpg");
        String c = prefs.getString("bg_choice", null);
        if (c == null) c = f.exists() ? "custom" : "";
        if (c.equals("custom")) return f.exists() ? BitmapFactory.decodeFile(f.getAbsolutePath()) : null;
        if (c.startsWith("asset:")) {
            try (InputStream in = getAssets().open("backgrounds/" + c.substring(6))) {
                return BitmapFactory.decodeStream(in);
            } catch (Exception e) {
                return null;
            }
        }
        return null;
    }

    void setBackgroundChoice(String choice, String message) {
        prefs.edit().putString("bg_choice", choice).apply();
        bgLoaded = false;
        bgCache = null;
        refreshNewTab();
        toast(message);
    }

    /** Hazır arka planlar küçük resimlerle gösterilir; dokununca hemen değişir. */
    void backgroundPicker() {
        String cur = prefs.getString("bg_choice", null);
        if (cur == null) cur = new File(getFilesDir(), "bg.jpg").exists() ? "custom" : "";
        final AlertDialog[] ref = new AlertDialog[1];
        GridLayout g = new GridLayout(this);
        g.setColumnCount(3);
        g.setPadding(dp(12), dp(8), dp(12), dp(4));
        for (int i = 0; i < BG_FILES.length; i++) {
            final String choice = "asset:" + BG_FILES[i];
            ImageView iv = new ImageView(this);
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            try (InputStream in = getAssets().open("backgrounds/t" + (i + 1) + ".jpg")) {
                iv.setImageBitmap(BitmapFactory.decodeStream(in));
            } catch (Exception ignored) { }
            iv.setBackground(round(0xFF2B2B30, 12));
            iv.setClipToOutline(true);
            if (choice.equals(cur)) {
                GradientDrawable sel = new GradientDrawable();
                sel.setCornerRadius(dp(12));
                sel.setStroke(dp(3), C_ACCENT);
                iv.setForeground(sel);
            }
            iv.setOnClickListener(v -> {
                ref[0].dismiss();
                setBackgroundChoice(choice, "Arka plan değiştirildi");
            });
            g.addView(iv, pickerLp());
        }
        TextView gallery = pickerTile("Galeriden seç");
        gallery.setOnClickListener(v -> {
            ref[0].dismiss();
            pickBackground();
        });
        g.addView(gallery, pickerLp());
        TextView def = pickerTile("Varsayılan");
        def.setBackground(defaultBg());
        def.setClipToOutline(true);
        def.setOnClickListener(v -> {
            ref[0].dismiss();
            setBackgroundChoice("", "Varsayılan arka plana dönüldü");
        });
        g.addView(def, pickerLp());
        ScrollView sv = new ScrollView(this);
        sv.addView(g);
        ref[0] = dlg().setTitle("Arka plan").setView(sv).setNegativeButton("Kapat", null).show();
    }

    GridLayout.LayoutParams pickerLp() {
        GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
        lp.width = dp(156);
        lp.height = dp(104);
        lp.setMargins(dp(6), dp(6), dp(6), dp(6));
        return lp;
    }

    TextView pickerTile(String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(C_TEXT);
        t.setTextSize(14);
        t.setGravity(Gravity.CENTER);
        GradientDrawable bg = round(0xFF2B2B30, 12);
        bg.setStroke(dp(1), 0x55FFFFFF, dp(5), dp(3));
        t.setBackground(bg);
        return t;
    }

    Drawable defaultBg() {
        return new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{0xFF3A2D6E, 0xFF1A1724, 0xFF0D5A6B});
    }

    void refreshNewTab() {
        if (!bgLoaded) {
            bgLoaded = true;
            bgCache = loadBgBitmap();
        }
        if (bgCache != null) {
            ntBg.setImageBitmap(bgCache);
            ntShade.setVisibility(View.VISIBLE);
        } else {
            ntBg.setImageDrawable(defaultBg());
            ntShade.setVisibility(View.GONE);
        }

        int avail = getResources().getDisplayMetrics().widthPixels - dp(56);
        int gridW = Math.min(avail, dp(1060));
        ViewGroupWidth(ntSearch, Math.min(avail, dp(680)));
        ViewGroupWidth(ntGrid, gridW);
        int cols = Math.max(2, Math.min(8, gridW / dp(164)));
        ntGrid.removeAllViews();
        ntGrid.setColumnCount(cols);

        JSONArray tiles = getTiles();
        for (int i = 0; i < tiles.length(); i++) {
            JSONObject o = tiles.optJSONObject(i);
            if (o == null) continue;
            ntGrid.addView(tileView(o.optString("t"), o.optString("u"), i), gridLp());
        }
        ntGrid.addView(tileView("Site ekle", null, -1), gridLp());
        tickClock();
    }

    void ViewGroupWidth(View v, int w) {
        android.view.ViewGroup.LayoutParams lp = v.getLayoutParams();
        if (lp != null && lp.width != w) {
            lp.width = w;
            v.setLayoutParams(lp);
        }
    }

    GridLayout.LayoutParams gridLp() {
        GridLayout.LayoutParams lp = new GridLayout.LayoutParams(
                GridLayout.spec(GridLayout.UNDEFINED), GridLayout.spec(GridLayout.UNDEFINED, 1f));
        lp.width = 0;
        lp.height = -2;
        lp.setMargins(dp(8), dp(8), dp(8), dp(8));
        return lp;
    }

    static final int TILE_W = 124;

    View tileView(String name, final String url, final int idx) {
        boolean add = url == null;
        LinearLayout v = new LinearLayout(this);
        v.setOrientation(LinearLayout.VERTICAL);
        v.setGravity(Gravity.CENTER);
        int pad = dp(14);   // çerçeve ile içerik arası: dört kenarda eşit
        v.setPadding(pad, pad, pad, pad);
        GradientDrawable bg = round(add ? 0x3818181E : 0x6B18181E, 18);
        if (add) bg.setStroke(dp(1), 0x80FFFFFF, dp(6), dp(4));
        else bg.setStroke(dp(1), 0x29FFFFFF);
        v.setBackground(bg);
        v.setForeground(ripple(false));

        FrameLayout logoBox = new FrameLayout(this);
        TextView logo = new TextView(this);
        logo.setGravity(Gravity.CENTER);
        logo.setTextColor(Color.WHITE);
        logoBox.addView(logo, new FrameLayout.LayoutParams(-1, -1));
        if (add) {
            logo.setText("+");
            logo.setTextSize(30);
            GradientDrawable lb = round(0x00000000, 14);
            lb.setStroke(dp(1.5f), 0xCCF6F6F8, dp(5), dp(3));
            logo.setBackground(lb);
        } else {
            String host = hostOf(url);
            String letter = nz(name, nz(host, "?")).trim();
            logo.setText(letter.isEmpty() ? "?" : letter.substring(0, 1).toUpperCase(new Locale("tr")));
            logo.setTextSize(24);
            logo.setTypeface(Typeface.DEFAULT_BOLD);
            logo.setBackground(round(colorFor(nz(host, name)), 14));
            ImageView icon = new ImageView(this);
            icon.setScaleType(ImageView.ScaleType.FIT_CENTER);
            icon.setBackground(round(0xFFFFFFFF, 14));
            icon.setPadding(dp(6), dp(6), dp(6), dp(6));
            icon.setClipToOutline(true);
            icon.setVisibility(View.GONE);
            logoBox.addView(icon, new FrameLayout.LayoutParams(-1, -1));
            setIcon(host, icon);
        }
        v.addView(logoBox, new LinearLayout.LayoutParams(dp(54), dp(54)));

        TextView nm = new TextView(this);
        nm.setText(name);
        nm.setTextColor(0xFFF6F6F8);
        nm.setTextSize(14);
        nm.setSingleLine(true);
        nm.setEllipsize(TextUtils.TruncateAt.END);
        nm.setShadowLayer(8, 0, 1, 0x73000000);
        LinearLayout.LayoutParams nlp = new LinearLayout.LayoutParams(-2, -2);
        nlp.topMargin = dp(10);
        nm.setMaxWidth(dp(TILE_W) - 2 * pad);
        v.addView(nm, nlp);

        if (add) {
            v.setOnClickListener(c -> tileEditor(-1));
        } else {
            v.setOnTouchListener((c, ev) -> {
                if (ev.getAction() == MotionEvent.ACTION_DOWN) preconnect(url);
                return false;
            });
            v.setOnClickListener(c -> load(current, url));
            v.setOnLongClickListener(c -> { tileMenu(idx); return true; });
            v.setOnContextClickListener(c -> { tileMenu(idx); return true; });
        }
        // Çerçeve içeriği saracak kadar dar; ızgara hücresinin ortasında durur
        FrameLayout cell = new FrameLayout(this);
        cell.addView(v, new FrameLayout.LayoutParams(dp(TILE_W), -2, Gravity.CENTER));
        return cell;
    }

    final HashMap<String, Bitmap> iconMem = new HashMap<>();
    final HashSet<String> iconLoading = new HashSet<>();
    final HashSet<String> iconFailed = new HashSet<>();

    /** Sitenin kendi logosunu gösterir; ilk seferde internetten alıp telefona kaydeder. */
    void setIcon(final String host, final ImageView iv) {
        if (host == null || host.isEmpty()) return;
        Bitmap b = iconMem.get(host);
        final File dir = new File(getFilesDir(), "icons");
        final File f = new File(dir, host.replaceAll("[^a-zA-Z0-9.-]", "_") + ".png");
        if (b == null && f.exists()) {
            b = BitmapFactory.decodeFile(f.getAbsolutePath());
            if (b != null) iconMem.put(host, b);
        }
        if (b != null) {
            iv.setImageBitmap(b);
            iv.setVisibility(View.VISIBLE);
            return;
        }
        if (iconFailed.contains(host) || !iconLoading.add(host)) return;
        new Thread(() -> {
            Bitmap got = null;
            String[] sources = {
                    "https://" + host + "/apple-touch-icon.png",
                    "https://www." + host + "/apple-touch-icon.png",
                    "https://www.google.com/s2/favicons?sz=128&domain_url=https%3A%2F%2F" + host,
                    "https://icons.duckduckgo.com/ip3/" + host + ".ico"
            };
            for (String src : sources) {
                if (src.startsWith("https://www.www.")) continue;
                got = fetchIcon(src);
                if (got != null) break;
            }
            if (got != null) {
                try {
                    //noinspection ResultOfMethodCallIgnored
                    dir.mkdirs();
                    try (FileOutputStream out = new FileOutputStream(f)) {
                        got.compress(Bitmap.CompressFormat.PNG, 100, out);
                    }
                } catch (Exception ignored) { }
            }
            final Bitmap fb = got;
            ui.post(() -> {
                iconLoading.remove(host);
                if (fb == null) {
                    iconFailed.add(host);
                    return;
                }
                iconMem.put(host, fb);
                if (current != null && current.isNewTab) refreshNewTab();
            });
        }).start();
    }

    /** Bir adresten logo indirir; bulanık kalacak kadar küçük logoları kabul etmez. */
    Bitmap fetchIcon(String src) {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(src).openConnection();
            c.setInstanceFollowRedirects(true);
            c.setConnectTimeout(6000);
            c.setReadTimeout(8000);
            c.setRequestProperty("User-Agent", desktopUa != null ? desktopUa : "Mozilla/5.0");
            c.setRequestProperty("Accept", "image/*");
            if (c.getResponseCode() != 200) return null;
            try (InputStream in = c.getInputStream()) {
                Bitmap bm = BitmapFactory.decodeStream(in);
                return (bm != null && bm.getWidth() >= 32 && bm.getHeight() >= 32) ? bm : null;
            }
        } catch (Exception e) {
            return null;
        } finally {
            if (c != null) c.disconnect();
        }
    }

    int colorFor(String s) {
        int h = 0;
        for (int i = 0; i < s.length(); i++) h = h * 31 + s.charAt(i);
        return TILE_COLORS[Math.abs(h % TILE_COLORS.length)];
    }

    static String hostOf(String u) {
        try {
            String h = Uri.parse(u).getHost();
            if (h == null) return "";
            return h.startsWith("www.") ? h.substring(4) : h;
        } catch (Exception e) {
            return "";
        }
    }

    JSONArray getTiles() {
        try {
            return new JSONArray(prefs.getString("tiles", DEFAULT_TILES));
        } catch (JSONException e) {
            return new JSONArray();
        }
    }

    int tileIndexFor(String url) {
        String h = hostOf(url);
        if (h.isEmpty()) return -1;
        JSONArray a = getTiles();
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o != null && h.equals(hostOf(o.optString("u")))) return i;
        }
        return -1;
    }

    /** Sitenin kısa, okunur adı: sayfa başlığının ilk parçası ya da alan adı. */
    String siteName(String url, String title) {
        if (title != null) {
            String tt = title.replaceAll("^\\(\\d+\\)\\s*", "").trim();
            String first = tt.split("\\s[-|–—:•]\\s")[0].trim();
            if (!first.isEmpty() && first.length() <= 22 && !first.startsWith("http")) return first;
        }
        String h = hostOf(url);
        String label = h.contains(".") ? h.substring(0, h.indexOf('.')) : h;
        if (label.isEmpty()) return h;
        return label.substring(0, 1).toUpperCase(new Locale("tr", "TR")) + label.substring(1);
    }

    /** Adres kutusunun sağındaki düğme: siteyi ana sayfa kutucuklarına ekler, tekrar basınca kaldırır. */
    void toggleTile() {
        Tab t = current;
        if (t == null || t.isNewTab) return;
        String url = t.url();
        Uri u = Uri.parse(url);
        if (u.getHost() == null || !url.startsWith("http")) {
            toast("Bu sayfa ana sayfaya eklenemez");
            return;
        }
        JSONArray a = getTiles();
        int idx = tileIndexFor(url);
        if (idx >= 0) {
            String name = a.optJSONObject(idx) != null ? a.optJSONObject(idx).optString("t") : "";
            a.remove(idx);
            prefs.edit().putString("tiles", a.toString()).apply();
            toast("Ana sayfadan kaldırıldı: " + name);
        } else {
            String site = u.getScheme() + "://" + u.getHost();
            String name = siteName(url, t.title);
            JSONObject o = new JSONObject();
            try {
                o.put("t", name);
                o.put("u", site);
            } catch (JSONException ignored) { }
            a.put(o);
            prefs.edit().putString("tiles", a.toString()).apply();
            toast("Ana sayfaya eklendi: " + name);
        }
        updateToolbar();
    }

    void tileMenu(final int idx) {
        final JSONObject o = getTiles().optJSONObject(idx);
        if (o == null) return;
        final String u = o.optString("u");
        dlg().setTitle(o.optString("t"))
                .setItems(new String[]{"Yeni sekmede aç", "Düzenle", "Sil"}, (d, which) -> {
                    if (which == 0) newTab(u, true, true);
                    else if (which == 1) tileEditor(idx);
                    else {
                        JSONArray a = getTiles();
                        a.remove(idx);
                        prefs.edit().putString("tiles", a.toString()).apply();
                        refreshNewTab();
                    }
                }).show();
    }

    void tileEditor(final int idx) {
        JSONObject o = idx >= 0 ? getTiles().optJSONObject(idx) : null;
        formDialog(idx >= 0 ? "Kutucuğu düzenle" : "Site ekle",
                o == null ? "" : o.optString("t"), o == null ? "" : o.optString("u"), (nm, u) -> {
                    JSONArray a = getTiles();
                    JSONObject n = new JSONObject();
                    try {
                        n.put("t", nm);
                        n.put("u", u);
                        if (idx >= 0 && idx < a.length()) a.put(idx, n); else a.put(n);
                    } catch (JSONException ignored) { }
                    prefs.edit().putString("tiles", a.toString()).apply();
                    refreshNewTab();
                });
    }

    interface FormSave {
        void save(String name, String url);
    }

    void formDialog(String title, String name, String url, final FormSave cb) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(8), dp(20), 0);
        final EditText n = new EditText(this);
        n.setHint("Ad");
        n.setSingleLine(true);
        n.setText(name);
        final EditText a = new EditText(this);
        a.setHint("Adres (örnek.com)");
        a.setSingleLine(true);
        a.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        a.setText(url);
        box.addView(n);
        box.addView(a);
        dlg().setTitle(title).setView(box)
                .setPositiveButton("Kaydet", (d, w) -> {
                    String u = a.getText().toString().trim();
                    if (u.isEmpty()) return;
                    if (!u.matches("^[a-zA-Z][a-zA-Z0-9+.-]*:.*")) u = "https://" + u;
                    String nm = n.getText().toString().trim();
                    if (nm.isEmpty()) nm = hostOf(u);
                    cb.save(nm, u);
                })
                .setNegativeButton("İptal", null).show();
    }

    final Runnable clockTick = new Runnable() {
        @Override
        public void run() {
            tickClock();
            ui.postDelayed(this, 15000);
        }
    };

    void tickClock() {
        if (ntClock == null || ntRoot.getVisibility() != View.VISIBLE) return;
        Date d = new Date();
        Locale tr = new Locale("tr", "TR");
        ntClock.setText(new SimpleDateFormat("HH:mm", tr).format(d));
        ntDate.setText(new SimpleDateFormat("d MMMM EEEE", tr).format(d));
    }

    void pickBackground() {
        Intent i = new Intent(Intent.ACTION_GET_CONTENT);
        i.setType("image/*");
        i.addCategory(Intent.CATEGORY_OPENABLE);
        try {
            startActivityForResult(Intent.createChooser(i, "Arka plan görseli seç"), REQ_BG);
        } catch (Exception e) {
            toast("Galeri açılamadı");
        }
    }

    void saveBackground(Uri u) {
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            try (InputStream in = getContentResolver().openInputStream(u)) {
                BitmapFactory.decodeStream(in, null, o);
            }
            int max = Math.max(o.outWidth, o.outHeight);
            int sample = 1;
            while (max / (sample * 2) >= 2560) sample *= 2;
            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = sample;
            Bitmap bm;
            try (InputStream in = getContentResolver().openInputStream(u)) {
                bm = BitmapFactory.decodeStream(in, null, o2);
            }
            if (bm == null) {
                toast("Bu görsel açılamadı");
                return;
            }
            int rot = 0;
            try (InputStream in = getContentResolver().openInputStream(u)) {
                if (in != null) {
                    ExifInterface ex = new ExifInterface(in);
                    int or = ex.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
                    if (or == ExifInterface.ORIENTATION_ROTATE_90) rot = 90;
                    else if (or == ExifInterface.ORIENTATION_ROTATE_180) rot = 180;
                    else if (or == ExifInterface.ORIENTATION_ROTATE_270) rot = 270;
                }
            } catch (Exception ignored) { }
            Matrix mx = new Matrix();
            float big = Math.max(bm.getWidth(), bm.getHeight());
            if (big > 2560) mx.postScale(2560f / big, 2560f / big);
            if (rot != 0) mx.postRotate(rot);
            if (!mx.isIdentity()) bm = Bitmap.createBitmap(bm, 0, 0, bm.getWidth(), bm.getHeight(), mx, true);
            try (FileOutputStream out = new FileOutputStream(new File(getFilesDir(), "bg.jpg"))) {
                bm.compress(Bitmap.CompressFormat.JPEG, 85, out);
            }
            prefs.edit().putString("bg_choice", "custom").apply();
            bgCache = bm;
            bgLoaded = true;
            refreshNewTab();
            toast("Arka plan değiştirildi");
        } catch (Exception e) {
            toast("Görsel kaydedilemedi");
        }
    }

    // ------------------------------------------------------------------ sekmeler

    Tab newTab(String url, boolean select, boolean nextToCurrent) {
        Tab t = new Tab();
        int idx = (nextToCurrent && current != null) ? tabs.indexOf(current) + 1 : tabs.size();
        tabs.add(idx, t);
        buildTabView(t);
        tabStrip.addView(t.view, idx);
        if (url != null && !url.isEmpty()) {
            load(t, url);
            if (!select && t.gecko && t.session != null) t.session.setActive(false);
        }
        if (select || current == null) selectTab(t); else refreshTabViews();
        return t;
    }

    void buildTabView(final Tab t) {
        LinearLayout v = new LinearLayout(this);
        v.setOrientation(LinearLayout.HORIZONTAL);
        v.setGravity(Gravity.CENTER_VERTICAL);
        v.setPadding(dp(12), 0, dp(4), 0);
        TextView title = new TextView(this);
        title.setSingleLine(true);
        title.setEllipsize(TextUtils.TruncateAt.END);
        title.setTextSize(13);
        v.addView(title, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView x = new TextView(this);
        x.setText("✕");
        x.setTextSize(12);
        x.setTextColor(C_DIM);
        x.setGravity(Gravity.CENTER);
        x.setBackground(ripple(true));
        x.setOnClickListener(c -> closeTab(t));
        v.addView(x, new LinearLayout.LayoutParams(dp(28), dp(28)));
        v.setOnClickListener(c -> selectTab(t));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(210), -1);
        lp.rightMargin = dp(2);
        v.setLayoutParams(lp);
        t.view = v;
        t.titleView = title;
    }

    String tabTitle(Tab t) {
        if (t.isNewTab && t.pendingUrl == null) return "Yeni sekme";
        if (t.title != null && !t.title.trim().isEmpty()) return t.title;
        String u = t.url();
        return u.isEmpty() ? "Yeni sekme" : u;
    }

    void refreshTabViews() {
        float r = dp(10);
        for (Tab t : tabs) {
            boolean active = t == current;
            GradientDrawable g = new GradientDrawable();
            g.setColor(active ? C_TOOL : 0x00000000);
            g.setCornerRadii(new float[]{r, r, r, r, 0, 0, 0, 0});
            t.view.setBackground(g);
            t.titleView.setText(tabTitle(t));
            t.titleView.setTextColor(active ? C_TEXT : C_DIM);
        }
    }

    void selectTab(Tab t) {
        current = t;
        if (t.pendingUrl != null) {
            String u = t.pendingUrl;
            t.pendingUrl = null;
            load(t, u);
        }
        showContent();
        refreshTabViews();
        updateToolbar();
        final View v = t.view;
        tabScroll.post(() -> {
            int l = v.getLeft(), rr = v.getRight(), sx = tabScroll.getScrollX(), w = tabScroll.getWidth();
            if (l < sx) tabScroll.smoothScrollTo(l, 0);
            else if (rr > sx + w) tabScroll.smoothScrollTo(rr - w, 0);
        });
    }

    /** Görünen sekmeye göre doğru motoru veya yeni sekme sayfasını gösterir; diğer sekmeleri uyutur. */
    void showContent() {
        Tab t = current;
        if (t == null) return;
        boolean nt = t.isNewTab;
        boolean cover = !nt && t.gecko && !t.geckoPainted && t.coverWithNewTab;
        boolean wasVisible = ntRoot.getVisibility() == View.VISIBLE;
        ntRoot.setVisibility(nt || cover ? View.VISIBLE : View.GONE);
        if (nt || (cover && !wasVisible)) refreshNewTab();
        ntSpinner.setVisibility(cover ? View.VISIBLE : View.GONE);
        if (nt) scheduleWarm(1500);
        for (Tab o : tabs) {
            if (o.web == null) continue;
            boolean vis = o == t && !nt && !t.gecko;
            o.web.setVisibility(vis ? View.VISIBLE : View.GONE);
            o.web.getSettings().setOffscreenPreRaster(vis && spPre);
        }
        geckoView.setVisibility(!nt && t.gecko ? View.VISIBLE : View.GONE);
        showSession(t);
        applyChrome();
    }

    void showSession(final Tab t) {
        GeckoSession want = t.isNewTab ? attachablePreload()
                : ((!t.gecko || t.session == null) ? null : t.session);
        geckoView.setVisibility(want != null || (!t.isNewTab && t.gecko) ? View.VISIBLE : View.GONE);
        GeckoSession have = geckoView.getSession();
        if (want == have) return;
        if (want != null && !want.isOpen()) {
            ui.postDelayed(() -> { if (current == t) showSession(t); }, 120);
            return;
        }
        if (have != null) {
            have.setActive(false);
            geckoView.releaseSession();
        }
        if (want != null) {
            geckoView.setSession(want);
            want.setActive(true);
            if (!t.isNewTab) geckoView.requestFocus();
            for (Preload p : preloads.values()) if (p.s == want) p.attached = true;
        }
    }

    /** Yeni sekme sayfasının arkasına bağlanacak önceden yüklenmiş sayfa (ilk Google kutucuğu). */
    GeckoSession attachablePreload() {
        if (!spPreload || !spGecko) return null;
        JSONArray tiles = getTiles();
        for (int i = 0; i < tiles.length(); i++) {
            JSONObject o = tiles.optJSONObject(i);
            if (o == null || !isGoogleAccountUrl(o.optString("u"))) continue;
            Preload p = preloads.get(preloadKey(o.optString("u")));
            return (p != null && p.s != null && p.s.isOpen()) ? p.s : null;
        }
        return null;
    }

    void closeTab(Tab t) {
        int i = tabs.indexOf(t);
        if (i < 0) return;
        if (customView != null && t == current) hideFullscreen();
        tabs.remove(i);
        tabStrip.removeView(t.view);
        if (t.session != null) {
            if (geckoView.getSession() == t.session) geckoView.releaseSession();
            try { t.session.close(); } catch (Exception ignored) { }
            t.session = null;
        }
        if (t.web != null) {
            webContainer.removeView(t.web);
            try { t.web.destroy(); } catch (Exception ignored) { }
            t.web = null;
        }
        if (tabs.isEmpty()) {
            current = null;
            newTab(null, true, false);
            return;
        }
        if (t == current) {
            current = null;
            selectTab(tabs.get(Math.min(i, tabs.size() - 1)));
        } else {
            refreshTabViews();
        }
    }

    void recreateSession(Tab t) {
        if (!tabs.contains(t)) return;
        String u = t.geckoUrl;
        if (t.session != null) {
            if (geckoView.getSession() == t.session) geckoView.releaseSession();
            try { t.session.close(); } catch (Exception ignored) { }
            t.session = null;
        }
        if (!t.gecko || u == null || u.isEmpty()) return;
        if (t == current) load(t, u); else t.pendingUrl = u;
    }

    void recreateWeb(Tab t) {
        if (!tabs.contains(t) || t.web == null) return;
        String u = t.webUrl;
        webContainer.removeView(t.web);
        try { t.web.destroy(); } catch (Exception ignored) { }
        t.web = null;
        if (t.gecko || u == null || u.isEmpty()) return;
        if (t == current) load(t, u); else t.pendingUrl = u;
    }

    boolean hasPage(Tab t, boolean geckoEngine) {
        return geckoEngine ? (t.session != null && t.geckoUrl != null)
                : (t.web != null && t.webUrl != null);
    }

    void load(Tab t, String url) {
        if (t == null) return;
        if (url == null || url.isEmpty()) {
            t.isNewTab = true;
            if (t == current) { showContent(); updateToolbar(); refreshTabViews(); }
            return;
        }
        t.pendingUrl = null;
        startTimer(t);
        boolean useGecko = useGeckoFor(url);
        if (useGecko && t.isNewTab && adoptPreload(t, url)) return;
        if (useGecko) {
            t.coverWithNewTab = t.isNewTab;
            t.geckoPainted = false;
            ui.postDelayed(() -> {
                if (!t.geckoPainted) { t.geckoPainted = true; if (t == current) showContent(); }
            }, 6000);
        }
        if (useGecko != t.gecko) {
            t.backTo = (!t.isNewTab && hasPage(t, t.gecko)) ? t.gecko : null;
        }
        t.isNewTab = false;
        t.gecko = useGecko;
        t.url = url;
        if (useGecko) {
            if (t.session == null) t.session = createSession(t, true);
            t.geckoUrl = url;
            t.session.loadUri(url);
        } else {
            if (t.web == null) createWebView(t);
            t.webUrl = url;
            t.web.loadUrl(url);
        }
        if (t == current) { showContent(); updateToolbar(); refreshTabViews(); }
    }

    /** Parmak dokunduğu anda siteyle bağlantıyı açmaya başlar; sayfa birkaç yüz milisaniye erken gelir. */
    void preconnect(String url) {
        if (url == null || !isGoogleAccountUrl(url)) return;
        try {
            if (runtime == null) return;
            if (executor == null) executor = new GeckoWebExecutor(runtime);
            executor.speculativeConnect(url);
        } catch (Exception ignored) { }
    }

    void go(String input) {
        String s = input.trim();
        if (s.isEmpty() || current == null) return;
        String url;
        if (s.matches("^[a-zA-Z][a-zA-Z0-9+.-]*://.*") || s.startsWith("about:")) {
            url = s;
        } else if (!s.contains(" ") && (s.matches("^[^\\s/]+\\.[a-zA-Z]{2,}(:\\d+)?(/.*)?$")
                || s.matches("^\\d{1,3}(\\.\\d{1,3}){3}(:\\d+)?(/.*)?$")
                || s.startsWith("localhost"))) {
            url = "https://" + s;
        } else {
            String q;
            try { q = URLEncoder.encode(s, "UTF-8"); } catch (Exception e) { q = s; }
            url = "https://www.google.com/search?q=" + q;
        }
        address.clearFocus();
        hideKeyboard(address);
        load(current, url);
    }

    boolean canGoBack(Tab t) {
        if (t == null) return false;
        if (t.isNewTab) return t.url != null && !t.url.isEmpty() && (t.session != null || t.web != null);
        if (t.gecko ? t.canBack : (t.web != null && t.web.canGoBack())) return true;
        return t.backTo != null && hasPage(t, t.backTo);
    }

    void goBack() {
        Tab t = current;
        if (t == null) return;
        if (t.isNewTab) {
            if (canGoBack(t)) {
                t.isNewTab = false;
                showContent();
                updateToolbar();
                refreshTabViews();
            }
            return;
        }
        if (t.gecko && t.canBack && t.session != null) { t.session.goBack(); return; }
        if (!t.gecko && t.web != null && t.web.canGoBack()) { t.web.goBack(); return; }
        if (t.backTo != null && hasPage(t, t.backTo)) {
            t.gecko = t.backTo;
            t.backTo = null;
            t.url = t.gecko ? t.geckoUrl : t.webUrl;
            t.title = nz(t.gecko ? t.geckoTitle : t.webTitle, t.url);
            showContent();
            updateToolbar();
            refreshTabViews();
        }
    }

    void goForward() {
        Tab t = current;
        if (t == null || t.isNewTab) return;
        if (t.gecko) { if (t.canFwd && t.session != null) t.session.goForward(); }
        else if (t.web != null && t.web.canGoForward()) t.web.goForward();
    }

    void reload() {
        if (current == null) return;
        if (current.isNewTab) refreshNewTab();
        else if (current.gecko && current.session != null) current.session.reload();
        else if (!current.gecko && current.web != null) current.web.reload();
    }

    void goHome() {
        if (current == null) return;
        current.isNewTab = true;
        showContent();
        updateToolbar();
        refreshTabViews();
    }

    void updateToolbar() {
        Tab t = current;
        if (t == null) return;
        if (!address.hasFocus()) address.setText(t.url());
        backBtn.setAlpha(canGoBack(t) ? 1f : 0.35f);
        boolean fwd = !t.isNewTab && (t.gecko ? t.canFwd : (t.web != null && t.web.canGoForward()));
        fwdBtn.setAlpha(fwd ? 1f : 0.35f);
        String u = t.url();
        boolean bm = !u.isEmpty() && bookmarkIndex(u) >= 0;
        starBtn.setText(bm ? "★" : "☆");
        starBtn.setTextColor(bm ? C_ACCENT : C_TEXT);
        boolean onSite = !t.isNewTab && u.startsWith("http");
        videoBtn.setVisibility(onSite ? View.VISIBLE : View.GONE);
        boolean vids = !t.gecko && (t.hasVideo || !t.netVideos.isEmpty());
        videoBtn.setTextColor(vids ? C_ACCENT : C_TEXT);
        videoBtn.setAlpha(vids ? 1f : 0.45f);
        tileBtn.setVisibility(onSite ? View.VISIBLE : View.GONE);
        boolean inTiles = onSite && tileIndexFor(u) >= 0;
        tileBtn.setText(inTiles ? "⊟" : "⊞");
        tileBtn.setTextColor(inTiles ? C_ACCENT : C_DIM);
        updateShield();
        progress.setProgress(t.progress);
        progress.setVisibility(!t.isNewTab && t.progress < 100 ? View.VISIBLE : View.INVISIBLE);
    }

    void updateShield() {
        if (current == null) return;
        int n = current.isNewTab ? 0 : current.blocked.get();
        shieldBtn.setText(adBlock && n > 0 ? "🛡 " + n : "🛡");
        shieldBtn.setAlpha(adBlock ? 1f : 0.35f);
    }

    void applyChrome() {
        boolean fs = current != null && current.fullscreen && !current.isNewTab;
        int vis = fs ? View.GONE : View.VISIBLE;
        tabBar.setVisibility(vis);
        toolBar.setVisibility(vis);
        bmScroll.setVisibility(vis);
        progress.setVisibility(fs ? View.GONE : (current != null && !current.isNewTab
                && current.progress < 100 ? View.VISIBLE : View.INVISIBLE));
        setSystemBars(!fs);
    }

    @SuppressWarnings("deprecation")
    void setSystemBars(boolean show) {
        if (Build.VERSION.SDK_INT >= 30) {
            WindowInsetsController c = getWindow().getInsetsController();
            if (c == null) return;
            if (show) {
                c.show(WindowInsets.Type.systemBars());
            } else {
                c.hide(WindowInsets.Type.systemBars());
                c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        } else {
            getWindow().getDecorView().setSystemUiVisibility(show ? 0
                    : (View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY));
        }
    }

    // ------------------------------------------------------------------ motor oturumu

    // ------------------------------------------------------------------ hızlı motor (Android'in kendi motoru)

    WebView createWebView(final Tab t) {
        WebView w = new WebView(this);
        WebSettings st = w.getSettings();
        st.setJavaScriptEnabled(true);
        st.setDomStorageEnabled(true);
        st.setDatabaseEnabled(true);
        st.setUserAgentString(CHROME_UA);
        st.setUseWideViewPort(true);
        st.setLoadWithOverviewMode(true);
        st.setSupportZoom(true);
        st.setBuiltInZoomControls(true);
        st.setDisplayZoomControls(false);
        st.setSupportMultipleWindows(true);
        st.setJavaScriptCanOpenWindowsAutomatically(true);
        st.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        st.setLayoutAlgorithm(WebSettings.LayoutAlgorithm.NORMAL);
        st.setTextZoom(100);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(w, true);
        w.setBackgroundColor(Color.WHITE);
        w.setScrollbarFadingEnabled(false);

        w.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                String u = r.getUrl().toString();
                if (r.isForMainFrame() && spGecko && isGoogleOAuthUrl(u)) {
                    final String origin = t.opener != null ? t.opener.webUrl : t.webUrl;
                    if (origin != null && !isGoogleAccountUrl(origin)) {
                        ui.post(() -> moveSiteToGecko(t, origin));
                        return true;
                    }
                }
                if (r.isForMainFrame() && useGeckoFor(u)) {
                    ui.post(() -> load(t, u));
                    return true;
                }
                String sc = r.getUrl().getScheme();
                if (sc == null) return false;
                sc = sc.toLowerCase(Locale.ROOT);
                if (sc.equals("http") || sc.equals("https") || sc.equals("about") || sc.equals("data")
                        || sc.equals("blob") || sc.equals("javascript") || sc.equals("file")) {
                    return false;
                }
                final Uri uri = r.getUrl();
                ui.post(() -> openSpecial(uri));
                return true;
            }

            @Override
            public void onPageStarted(WebView v, String url, Bitmap favicon) {
                if (url != null) t.webUrl = url;
                t.netVideos.clear();
                t.hasVideo = false;
                if (t.gecko) return;
                t.blocked.set(0);
                t.progress = 5;
                if (url != null) t.url = url;
                if (t.loadStart == 0) startTimer(t);
                if (spViewport) v.evaluateJavascript(viewportJs(), null);
                if (t == current) updateToolbar();
            }

            @Override
            public void onPageCommitVisible(WebView v, String url) {
                if (spViewport) v.evaluateJavascript(viewportJs(), null);
            }

            @Override
            public void onPageFinished(WebView v, String url) {
                if (t.gecko) return;
                t.progress = 100;
                stopTimer(t, "hızlı motor");
                v.evaluateJavascript(DETECT_JS, res -> {
                    if (res != null && res.contains("u\\\":")) {
                        t.hasVideo = true;
                        if (t == current) updateToolbar();
                    }
                });
                if (url != null && url.startsWith("http")) {
                    if (spViewport) v.evaluateJavascript(viewportJs(), null);
                    if (adBlock) v.evaluateJavascript(HIDE_JS, null);
                    addHistory(v.getTitle(), url);
                }
                if (t == current) updateToolbar();
                CookieManager.getInstance().flush();
            }

            @Override
            public void doUpdateVisitedHistory(WebView v, String url, boolean isReload) {
                if (url != null) t.webUrl = url;
                if (t.gecko) return;
                if (url != null) t.url = url;
                if (t == current) updateToolbar();
            }

            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                String path = r.getUrl().getPath();
                if (path != null && VIDEO_PATH.matcher(path).find() && !isAdHost(r.getUrl().getHost())) {
                    String vu = r.getUrl().toString();
                    if (!t.netVideos.contains(vu) && t.netVideos.size() < 40) {
                        t.netVideos.add(vu);
                        ui.post(() -> { if (t == current) updateToolbar(); });
                    }
                }
                if (adBlock && !r.isForMainFrame() && isAdHost(r.getUrl().getHost())) {
                    t.blocked.incrementAndGet();
                    ui.post(() -> { if (t == current && !t.gecko) updateShield(); });
                    return new WebResourceResponse("text/plain", "utf-8",
                            new ByteArrayInputStream(new byte[0]));
                }
                return null;
            }

            @Override
            public boolean onRenderProcessGone(WebView v, RenderProcessGoneDetail detail) {
                ui.post(() -> recreateWeb(t));
                return true;
            }
        });

        w.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView v, int p) {
                if (t.gecko) return;
                t.progress = p;
                if (t == current && !t.isNewTab) {
                    progress.setProgress(p);
                    progress.setVisibility(p < 100 ? View.VISIBLE : View.INVISIBLE);
                }
            }

            @Override
            public void onReceivedTitle(WebView v, String title) {
                t.webTitle = title;
                if (t.gecko) return;
                t.title = title;
                refreshTabViews();
            }

            @Override
            public boolean onCreateWindow(WebView v, boolean isDialog, boolean isUserGesture, Message msg) {
                if (adBlock && !isUserGesture) return false;
                Tab nt = new Tab();
                nt.isNewTab = false;
                nt.opener = t;
                createWebView(nt);
                int idx = current != null ? tabs.indexOf(current) + 1 : tabs.size();
                tabs.add(idx, nt);
                buildTabView(nt);
                tabStrip.addView(nt.view, idx);
                WebView.WebViewTransport tr = (WebView.WebViewTransport) msg.obj;
                tr.setWebView(nt.web);
                msg.sendToTarget();
                selectTab(nt);
                return true;
            }

            @Override
            public void onCloseWindow(WebView v) {
                ui.post(() -> closeTab(t));
            }

            @Override
            public void onShowCustomView(View view, CustomViewCallback callback) {
                showFullscreen(view, callback);
            }

            @Override
            public void onHideCustomView() {
                hideFullscreen();
            }

            @Override
            public Bitmap getDefaultVideoPoster() {
                return Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888);
            }

            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams params) {
                if (webFileCb != null) webFileCb.onReceiveValue(null);
                webFileCb = cb;
                try {
                    Intent i = params.createIntent();
                    if (params.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE) {
                        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                    }
                    startActivityForResult(i, REQ_FILE_WEB);
                } catch (Exception e) {
                    webFileCb = null;
                    return false;
                }
                return true;
            }
        });

        w.setDownloadListener((url, ua, cd, mime, len) ->
                requestDownload(url, ua, cd, mime, len, t.webUrl, false, null, null));
        w.setOnLongClickListener(v -> onWebLongPress(t));
        w.setOnContextClickListener(v -> onWebLongPress(t));
        w.setVisibility(View.GONE);
        t.web = w;
        webContainer.addView(w, 0, new FrameLayout.LayoutParams(-1, -1));
        return w;
    }

    boolean onWebLongPress(Tab t) {
        if (t.web == null) return false;
        WebView.HitTestResult r = t.web.getHitTestResult();
        if (r == null) return false;
        int type = r.getType();
        String extra = r.getExtra();
        if (extra == null) return false;
        if (type == WebView.HitTestResult.SRC_ANCHOR_TYPE) {
            linkMenu(extra, null);
            return true;
        }
        if (type == WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE) {
            Message m = ui.obtainMessage();
            t.web.requestFocusNodeHref(m);
            String link = m.getData().getString("url");
            linkMenu(link != null && !link.isEmpty() ? link : extra, extra);
            return true;
        }
        if (type == WebView.HitTestResult.IMAGE_TYPE) {
            linkMenu(null, extra);
            return true;
        }
        return false;
    }

    /** Sayfaya bilgisayar ekranı genişliği verir (yakınlaştırma ayarıyla). */
    String viewportJs() {
        float d = getResources().getDisplayMetrics().density;
        int px = webContainer.getWidth();
        if (px <= 0) px = getResources().getDisplayMetrics().widthPixels;
        int css = Math.max(320, Math.round(px / d));
        int w = Math.round(css * 100f / zoom);
        String sc = String.format(Locale.US, "%.4f", css / (float) w);
        return "(function(){window.__mdvpC='width=" + w + ", initial-scale=" + sc
                + ", minimum-scale=" + sc + ", user-scalable=yes';"
                + "function ap(){var c=window.__mdvpC;var h=document.head;if(!h)return;"
                + "var ms=document.querySelectorAll('meta[name=\"viewport\"]');"
                + "if(!ms.length){var m=document.createElement('meta');m.name='viewport';h.appendChild(m);ms=[m];}"
                + "for(var i=0;i<ms.length;i++){if(ms[i].getAttribute('content')!==c)ms[i].setAttribute('content',c);}"
                + "if(!window.__mdvpO){try{window.__mdvpO=new MutationObserver(ap);"
                + "window.__mdvpO.observe(h,{childList:true});}catch(e){}}}"
                + "ap();setTimeout(ap,60);setTimeout(ap,600);"
                + "if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',ap);})();";
    }

    void applyViewportAll() {
        if (!spViewport) return;
        String js = viewportJs();
        for (Tab t : tabs) {
            if (t.web != null && t.webUrl != null) t.web.evaluateJavascript(js, null);
        }
    }

    void showFullscreen(View v, WebChromeClient.CustomViewCallback cb) {
        if (customView != null) {
            cb.onCustomViewHidden();
            return;
        }
        customView = v;
        customCb = cb;
        fullContainer.addView(v, new FrameLayout.LayoutParams(-1, -1));
        fullContainer.setVisibility(View.VISIBLE);
        mainLayout.setVisibility(View.GONE);
        setSystemBars(false);
    }

    void hideFullscreen() {
        if (customView == null) return;
        fullContainer.removeView(customView);
        fullContainer.setVisibility(View.GONE);
        mainLayout.setVisibility(View.VISIBLE);
        customView = null;
        setSystemBars(true);
        WebChromeClient.CustomViewCallback cb = customCb;
        customCb = null;
        if (cb != null) cb.onCustomViewHidden();
    }

    GeckoSession createSession(final Tab t, boolean open) {
        ensureRuntime();
        if (open && spareSession != null && spareSession.isOpen()) {
            GeckoSession s = spareSession;
            spareSession = null;
            attachDelegates(t, s);
            scheduleWarm(4000);
            return s;
        }
        GeckoSession s = newBareSession();
        attachDelegates(t, s);
        if (open) s.open(runtime);
        return s;
    }

    GeckoSession newBareSession() {
        return newBareSession(false);
    }

    GeckoSession newBareSession(boolean suspendMedia) {
        GeckoSessionSettings ss = new GeckoSessionSettings.Builder()
                .suspendMediaWhenInactive(suspendMedia)
                .usePrivateMode(false)
                .useTrackingProtection(adBlock)
                .userAgentMode(GeckoSessionSettings.USER_AGENT_MODE_DESKTOP)
                .userAgentOverride(desktopUa)
                .viewportMode(GeckoSessionSettings.VIEWPORT_MODE_MOBILE)
                .allowJavascript(true)
                .build();
        return new GeckoSession(ss);
    }

    void attachDelegates(Tab t, GeckoSession s) {
        s.setNavigationDelegate(new Nav(t));
        s.setProgressDelegate(new Prog(t));
        s.setContentDelegate(new Content(t));
        s.setPromptDelegate(new Prompts());
        s.setPermissionDelegate(new Perms());
        s.setContentBlockingDelegate(new Blocking(t));
        s.setSelectionActionDelegate(new BasicSelectionActionDelegate(this));
    }

    /**
     * Firefox motorunu, sen Gmail/YouTube'a basmadan önce arka planda hazırlar:
     * motor çalışır, boş bir sekme açık bekler ve Google sunucularıyla bağlantı önceden kurulur.
     */
    final Runnable warmTask = this::warmGecko;

    void scheduleWarm(long delay) {
        ui.removeCallbacks(warmTask);
        ui.postDelayed(warmTask, delay);
    }

    static String preloadKey(String url) {
        Uri u = Uri.parse(url);
        String h = u.getHost() == null ? "" : u.getHost().toLowerCase(Locale.ROOT);
        if (h.startsWith("www.")) h = h.substring(4);
        if (h.startsWith("m.")) h = h.substring(2);
        String path = u.getPath() == null || u.getPath().isEmpty() ? "/" : u.getPath();
        return h + path;
    }

    /** Yeni sekme kutucuklarındaki YouTube ve Gmail'i arka planda hazırda tutar. */
    void preloadTiles() {
        if (!spPreload || !spGecko || runtime == null) return;
        JSONArray tiles = getTiles();
        int count = 0;
        for (int i = 0; i < tiles.length() && count < 2; i++) {
            JSONObject o = tiles.optJSONObject(i);
            if (o == null) continue;
            String url = o.optString("u");
            if (!isGoogleAccountUrl(url)) continue;
            count++;
            String key = preloadKey(url);
            if (preloads.containsKey(key)) continue;
            final Preload p = new Preload();
            p.url = url;
            p.time = System.currentTimeMillis();
            p.s = newBareSession(true);
            p.s.setProgressDelegate(new GeckoSession.ProgressDelegate() {
                public void onPageStop(GeckoSession s, boolean success) {
                    p.time = System.currentTimeMillis();
                }
            });
            p.s.setNavigationDelegate(new GeckoSession.NavigationDelegate() {
                public void onLocationChange(GeckoSession s, String u,
                                             List<GeckoSession.PermissionDelegate.ContentPermission> perms) {
                    if (u != null && !u.equals("about:blank")) p.url = u;
                }

                public void onLocationChange(GeckoSession s, String u,
                                             List<GeckoSession.PermissionDelegate.ContentPermission> perms,
                                             Boolean hasUserGesture) {
                    if (u != null && !u.equals("about:blank")) p.url = u;
                }
            });
            p.s.setContentDelegate(new GeckoSession.ContentDelegate() {
                public void onTitleChange(GeckoSession s, String title) {
                    p.title = title;
                }
            });
            p.s.open(runtime);
            p.s.setActive(false);
            preloads.put(key, p);
            if (current != null && current.isNewTab) showSession(current);
            p.s.loadUri(url);
        }
    }

    void dropPreloads() {
        for (Preload p : preloads.values()) {
            if (geckoView.getSession() == p.s) geckoView.releaseSession();
            try { p.s.close(); } catch (Exception ignored) { }
        }
        preloads.clear();
    }

    /** Önceden yüklenmiş sayfa varsa sekmeye anında takar. */
    boolean adoptPreload(Tab t, String url) {
        Preload p = preloads.remove(preloadKey(url));
        if (p == null || p.s == null || !p.s.isOpen()) return false;
        if (t.session != null) {
            if (geckoView.getSession() == t.session) geckoView.releaseSession();
            try { t.session.close(); } catch (Exception ignored) { }
        }
        t.backTo = null;
        t.session = p.s;
        try { p.s.getSettings().setSuspendMediaWhenInactive(false); } catch (Exception ignored) { }
        attachDelegates(t, p.s);
        t.isNewTab = false;
        t.gecko = true;
        t.geckoPainted = true;
        t.coverWithNewTab = false;
        t.canBack = false;
        t.canFwd = false;
        t.progress = 100;
        t.geckoUrl = p.url != null ? p.url : url;
        t.url = t.geckoUrl;
        t.geckoTitle = p.title;
        t.title = nz(p.title, t.url);
        if (!p.attached || System.currentTimeMillis() - p.time > 15 * 60 * 1000L) p.s.reload();
        if (t == current) { showContent(); updateToolbar(); refreshTabViews(); }
        stopTimer(t, "önceden yüklendi");
        addHistory(t.title, t.url);
        return true;
    }

    void warmGecko() {
        if (!spGecko || isFinishing()) return;
        try {
            ensureRuntime();
            if (spareSession == null) {
                GeckoSession s = newBareSession();
                s.open(runtime);
                s.setActive(false);
                spareSession = s;
            }
            if (executor == null) executor = new GeckoWebExecutor(runtime);
            executor.speculativeConnect("https://www.youtube.com/");
            executor.speculativeConnect("https://mail.google.com/");
            executor.speculativeConnect("https://accounts.google.com/");
            preloadTiles();
        } catch (Exception ignored) { }
    }

    void locationChanged(Tab t, String url) {
        if (url == null) return;
        if (url.equals("about:blank") && t.geckoUrl != null && !t.geckoUrl.isEmpty()) return;
        t.geckoUrl = url;
        if (!t.gecko) return;
        t.url = url;
        if (t == current) updateToolbar();
    }

    class Nav implements GeckoSession.NavigationDelegate {
        final Tab t;

        Nav(Tab t) { this.t = t; }

        public void onLocationChange(GeckoSession s, String url,
                                     List<GeckoSession.PermissionDelegate.ContentPermission> perms) {
            locationChanged(t, url);
        }

        public void onLocationChange(GeckoSession s, String url,
                                     List<GeckoSession.PermissionDelegate.ContentPermission> perms,
                                     Boolean hasUserGesture) {
            locationChanged(t, url);
        }

        public void onCanGoBack(GeckoSession s, boolean can) {
            t.canBack = can;
            if (t == current) updateToolbar();
        }

        public void onCanGoForward(GeckoSession s, boolean can) {
            t.canFwd = can;
            if (t == current) updateToolbar();
        }

        public GeckoResult<AllowOrDeny> onLoadRequest(GeckoSession s, LoadRequest r) {
            final Uri u = Uri.parse(r.uri);
            String sc = u.getScheme();
            if (sc == null) return GeckoResult.fromValue(AllowOrDeny.ALLOW);
            sc = sc.toLowerCase(Locale.ROOT);
            // Google dışı bir siteye tıklanınca o sekme hızlı motora geçer.
            if ((sc.equals("http") || sc.equals("https")) && r.hasUserGesture && !r.isRedirect
                    && r.target == TARGET_WINDOW_CURRENT && !useGeckoFor(r.uri)) {
                final String target = r.uri;
                ui.post(() -> load(t, target));
                return GeckoResult.fromValue(AllowOrDeny.DENY);
            }
            switch (sc) {
                case "http": case "https": case "about": case "data": case "blob": case "file":
                case "resource": case "moz-extension": case "javascript": case "view-source":
                    return GeckoResult.fromValue(AllowOrDeny.ALLOW);
                default:
                    ui.post(() -> openSpecial(u));
                    return GeckoResult.fromValue(AllowOrDeny.DENY);
            }
        }

        public GeckoResult<GeckoSession> onNewSession(GeckoSession s, String uri) {
            Tab nt = new Tab();
            nt.isNewTab = false;
            nt.gecko = true;
            nt.url = uri;
            nt.geckoUrl = uri;
            nt.session = createSession(nt, false);
            int idx = current != null ? tabs.indexOf(current) + 1 : tabs.size();
            tabs.add(idx, nt);
            buildTabView(nt);
            tabStrip.addView(nt.view, idx);
            selectTab(nt);
            return GeckoResult.fromValue(nt.session);
        }

        public GeckoResult<String> onLoadError(GeckoSession s, String uri, WebRequestError error) {
            String html = "<!DOCTYPE html><html lang='tr'><head><meta charset='utf-8'>"
                    + "<meta name='viewport' content='width=device-width,initial-scale=1'>"
                    + "<title>Sayfa açılamadı</title><style>body{font-family:sans-serif;background:#1c1c1f;"
                    + "color:#ededf0;display:flex;align-items:center;justify-content:center;height:90vh;margin:0}"
                    + "div{max-width:560px;padding:24px}h1{font-weight:300;font-size:34px}"
                    + "p{color:#9c9ca5;line-height:1.5}</style></head><body><div><h1>Sayfa açılamadı</h1>"
                    + "<p>İnternet bağlantını ve adresi kontrol edip ↻ düğmesiyle yeniden dene.</p></div></body></html>";
            return GeckoResult.fromValue("data:text/html;charset=utf-8," + Uri.encode(html));
        }
    }

    class Prog implements GeckoSession.ProgressDelegate {
        final Tab t;

        Prog(Tab t) { this.t = t; }

        public void onPageStart(GeckoSession s, String url) {
            if (url != null && !url.equals("about:blank")) t.geckoUrl = url;
            if (!t.gecko) return;
            t.blocked.set(0);
            t.progress = 5;
            if (t.loadStart == 0 && url != null && !url.equals("about:blank")) startTimer(t);
            if (url != null && !url.equals("about:blank")) t.url = url;
            if (t == current) updateToolbar();
        }

        public void onPageStop(GeckoSession s, boolean success) {
            if (!t.gecko) return;
            t.progress = 100;
            if (success && t.url != null && t.url.startsWith("http")) addHistory(t.title, t.url);
            if (t == current) updateToolbar();
        }

        public void onProgressChange(GeckoSession s, int p) {
            if (!t.gecko) return;
            t.progress = p;
            if (t == current && !t.isNewTab) {
                progress.setProgress(p);
                progress.setVisibility(p < 100 ? View.VISIBLE : View.INVISIBLE);
            }
        }
    }

    class Content implements GeckoSession.ContentDelegate {
        final Tab t;

        Content(Tab t) { this.t = t; }

        public void onFirstContentfulPaint(GeckoSession s) {
            firstPaint();
        }

        void firstPaint() {
            if (t.gecko) stopTimer(t, "Firefox motoru");
            if (t.geckoPainted) return;
            t.geckoPainted = true;
            if (t == current) showContent();
        }

        public void onTitleChange(GeckoSession s, String title) {
            t.geckoTitle = title;
            if (!t.gecko) return;
            t.title = title;
            refreshTabViews();
            if (t.url != null && t.url.startsWith("http") && title != null && !title.isEmpty()) {
                addHistory(title, t.url);
            }
        }

        public void onFullScreen(GeckoSession s, boolean fullScreen) {
            t.fullscreen = fullScreen;
            if (t == current) applyChrome();
        }

        public void onContextMenu(GeckoSession s, int screenX, int screenY, ContextElement e) {
            String link = e.linkUri;
            String img = e.type == ContextElement.TYPE_IMAGE ? e.srcUri : null;
            if (link != null || img != null) linkMenu(link, img);
        }

        public void onExternalResponse(GeckoSession s, WebResponse response) {
            requestGeckoResponse(response);
        }

        public void onCloseRequest(GeckoSession s) {
            ui.post(() -> closeTab(t));
        }

        public void onCrash(GeckoSession s) {
            ui.post(() -> recreateSession(t));
        }

        public void onKill(GeckoSession s) {
            ui.post(() -> recreateSession(t));
        }
    }

    class Blocking implements ContentBlocking.Delegate {
        final Tab t;

        Blocking(Tab t) { this.t = t; }

        public void onContentBlocked(GeckoSession s, ContentBlocking.BlockEvent event) {
            if (!t.gecko) return;
            t.blocked.incrementAndGet();
            if (t == current) updateShield();
        }
    }

    class Perms implements GeckoSession.PermissionDelegate {
        public GeckoResult<Integer> onContentPermissionRequest(GeckoSession s, ContentPermission perm) {
            int p = perm.permission;
            boolean allow = p == PERMISSION_AUTOPLAY_AUDIBLE || p == PERMISSION_AUTOPLAY_INAUDIBLE
                    || p == PERMISSION_PERSISTENT_STORAGE || p == PERMISSION_STORAGE_ACCESS
                    || p == PERMISSION_MEDIA_KEY_SYSTEM_ACCESS;
            return GeckoResult.fromValue(allow ? ContentPermission.VALUE_ALLOW : ContentPermission.VALUE_DENY);
        }
    }

    // ------------------------------------------------------------------ sitelerin açtığı pencereler (seçim kutuları, uyarılar…)

    static class Once {
        final GeckoResult<PromptResponse> r;
        boolean done;

        Once(GeckoResult<PromptResponse> r) { this.r = r; }

        void finish(PromptResponse v) {
            if (done) return;
            done = true;
            r.complete(v);
        }
    }

    class Prompts implements GeckoSession.PromptDelegate {

        public GeckoResult<PromptResponse> onAlertPrompt(GeckoSession s, AlertPrompt p) {
            GeckoResult<PromptResponse> r = new GeckoResult<>();
            final Once o = new Once(r);
            dlg().setTitle(nz(p.title, "Sayfadan mesaj"))
                    .setMessage(nz(p.message, ""))
                    .setPositiveButton("Tamam", (d, w) -> o.finish(p.dismiss()))
                    .setOnDismissListener(d -> o.finish(p.dismiss()))
                    .show();
            return r;
        }

        public GeckoResult<PromptResponse> onButtonPrompt(GeckoSession s, ButtonPrompt p) {
            GeckoResult<PromptResponse> r = new GeckoResult<>();
            final Once o = new Once(r);
            dlg().setTitle(nz(p.title, "Sayfadan soru"))
                    .setMessage(nz(p.message, ""))
                    .setPositiveButton("Tamam", (d, w) -> o.finish(p.confirm(ButtonPrompt.Type.POSITIVE)))
                    .setNegativeButton("İptal", (d, w) -> o.finish(p.confirm(ButtonPrompt.Type.NEGATIVE)))
                    .setOnDismissListener(d -> o.finish(p.dismiss()))
                    .show();
            return r;
        }

        public GeckoResult<PromptResponse> onTextPrompt(GeckoSession s, TextPrompt p) {
            GeckoResult<PromptResponse> r = new GeckoResult<>();
            final Once o = new Once(r);
            final EditText et = new EditText(MainActivity.this);
            et.setSingleLine(true);
            et.setText(nz(p.defaultValue, ""));
            FrameLayout box = new FrameLayout(MainActivity.this);
            box.setPadding(dp(20), dp(8), dp(20), 0);
            box.addView(et);
            dlg().setTitle(nz(p.title, "Sayfadan soru"))
                    .setMessage(nz(p.message, ""))
                    .setView(box)
                    .setPositiveButton("Tamam", (d, w) -> o.finish(p.confirm(et.getText().toString())))
                    .setNegativeButton("İptal", (d, w) -> o.finish(p.dismiss()))
                    .setOnDismissListener(d -> o.finish(p.dismiss()))
                    .show();
            return r;
        }

        public GeckoResult<PromptResponse> onAuthPrompt(GeckoSession s, AuthPrompt p) {
            GeckoResult<PromptResponse> r = new GeckoResult<>();
            final Once o = new Once(r);
            LinearLayout box = new LinearLayout(MainActivity.this);
            box.setOrientation(LinearLayout.VERTICAL);
            box.setPadding(dp(20), dp(8), dp(20), 0);
            final EditText user = new EditText(MainActivity.this);
            user.setHint("Kullanıcı adı");
            user.setSingleLine(true);
            final EditText pass = new EditText(MainActivity.this);
            pass.setHint("Şifre");
            pass.setSingleLine(true);
            pass.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
            box.addView(user);
            box.addView(pass);
            dlg().setTitle(nz(p.title, "Giriş gerekli"))
                    .setMessage(nz(p.message, ""))
                    .setView(box)
                    .setPositiveButton("Giriş", (d, w) -> o.finish(
                            p.confirm(user.getText().toString(), pass.getText().toString())))
                    .setNegativeButton("İptal", (d, w) -> o.finish(p.dismiss()))
                    .setOnDismissListener(d -> o.finish(p.dismiss()))
                    .show();
            return r;
        }

        public GeckoResult<PromptResponse> onChoicePrompt(GeckoSession s, ChoicePrompt p) {
            GeckoResult<PromptResponse> r = new GeckoResult<>();
            final Once o = new Once(r);
            final ArrayList<ChoicePrompt.Choice> flat = new ArrayList<>();
            flatten(p.choices, flat, "");
            if (flat.isEmpty()) {
                o.finish(p.dismiss());
                return r;
            }
            String[] labels = new String[flat.size()];
            for (int i = 0; i < flat.size(); i++) labels[i] = nz(flat.get(i).label, " ");
            AlertDialog.Builder b = dlg();
            if (p.title != null && !p.title.isEmpty()) b.setTitle(p.title);
            if (p.type == ChoicePrompt.Type.MULTIPLE) {
                final boolean[] checked = new boolean[flat.size()];
                for (int i = 0; i < flat.size(); i++) checked[i] = flat.get(i).selected;
                b.setMultiChoiceItems(labels, checked, (d, which, isChecked) -> checked[which] = isChecked)
                        .setPositiveButton("Tamam", (d, w) -> {
                            ArrayList<String> ids = new ArrayList<>();
                            for (int i = 0; i < flat.size(); i++) if (checked[i]) ids.add(flat.get(i).id);
                            o.finish(p.confirm(ids.toArray(new String[0])));
                        })
                        .setNegativeButton("İptal", (d, w) -> o.finish(p.dismiss()));
            } else {
                int sel = -1;
                for (int i = 0; i < flat.size(); i++) if (flat.get(i).selected) sel = i;
                b.setSingleChoiceItems(labels, sel, (d, which) -> {
                    o.finish(p.confirm(flat.get(which).id));
                    d.dismiss();
                });
            }
            b.setOnDismissListener(d -> o.finish(p.dismiss())).show();
            return r;
        }

        public GeckoResult<PromptResponse> onFilePrompt(GeckoSession s, FilePrompt p) {
            GeckoResult<PromptResponse> r = new GeckoResult<>();
            if (pendingFile != null && pendingFileResult != null) {
                pendingFileResult.complete(pendingFile.dismiss());
            }
            Intent i = new Intent(Intent.ACTION_GET_CONTENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            String[] mimes = p.mimeTypes;
            if (mimes != null && mimes.length == 1 && mimes[0] != null && !mimes[0].isEmpty()) {
                i.setType(mimes[0]);
            } else {
                i.setType("*/*");
                if (mimes != null && mimes.length > 1) i.putExtra(Intent.EXTRA_MIME_TYPES, mimes);
            }
            if (p.type == FilePrompt.Type.MULTIPLE) i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
            pendingFile = p;
            pendingFileResult = r;
            try {
                startActivityForResult(i, REQ_FILE);
            } catch (Exception e) {
                pendingFile = null;
                pendingFileResult = null;
                r.complete(p.dismiss());
            }
            return r;
        }
    }

    void flatten(ChoicePrompt.Choice[] in, ArrayList<ChoicePrompt.Choice> out, String prefix) {
        if (in == null) return;
        for (ChoicePrompt.Choice c : in) {
            if (c == null || c.separator) continue;
            if (c.items != null && c.items.length > 0) {
                flatten(c.items, out, prefix);
            } else if (!c.disabled) {
                out.add(c);
            }
        }
    }

    void openSpecial(Uri u) {
        try {
            String sc = u.getScheme() == null ? "" : u.getScheme().toLowerCase(Locale.ROOT);
            if (sc.equals("intent")) {
                Intent in = Intent.parseUri(u.toString(), Intent.URI_INTENT_SCHEME);
                in.addCategory(Intent.CATEGORY_BROWSABLE);
                in.setComponent(null);
                in.setSelector(null);
                try {
                    startActivity(in);
                } catch (Exception e) {
                    String fb = in.getStringExtra("browser_fallback_url");
                    if (fb != null && fb.startsWith("http")) load(current, fb);
                    else toast("Bu bağlantıyı açacak uygulama yok");
                }
                return;
            }
            Intent in = new Intent(Intent.ACTION_VIEW, u);
            in.addCategory(Intent.CATEGORY_BROWSABLE);
            startActivity(in);
        } catch (Exception e) {
            toast("Bu bağlantıyı açacak uygulama yok");
        }
    }

    void linkMenu(final String link, final String img) {
        ArrayList<String> labels = new ArrayList<>();
        ArrayList<Runnable> acts = new ArrayList<>();
        if (link != null) {
            labels.add("Yeni sekmede aç");
            acts.add(() -> newTab(link, true, true));
            labels.add("Arka planda yeni sekmede aç");
            acts.add(() -> newTab(link, false, true));
            labels.add("Bağlantıyı kopyala");
            acts.add(() -> copy(link));
        }
        if (img != null) {
            labels.add("Resmi yeni sekmede aç");
            acts.add(() -> newTab(img, true, true));
            labels.add("Resmi indir");
            acts.add(() -> {
                boolean g = current != null && current.gecko;
                requestDownload(img, null, null, null, -1, current != null ? current.url() : null, g, null, null);
            });
        }
        String title = link != null ? link : img;
        if (title.length() > 90) title = title.substring(0, 90) + "…";
        dlg().setTitle(title)
                .setItems(labels.toArray(new String[0]), (d, which) -> acts.get(which).run())
                .show();
    }

    void copy(String s) {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("bağlantı", s));
        toast("Kopyalandı");
    }

    void openExternal(String url) {
        if (url == null || url.isEmpty()) {
            toast("Açılacak bir sayfa yok");
            return;
        }
        Intent chooser = Intent.createChooser(new Intent(Intent.ACTION_VIEW, Uri.parse(url)),
                "Hangi tarayıcıda açılsın?");
        chooser.putExtra(Intent.EXTRA_EXCLUDE_COMPONENTS,
                new ComponentName[]{new ComponentName(this, MainActivity.class)});
        try {
            startActivity(chooser);
        } catch (Exception e) {
            toast("Başka bir tarayıcı bulunamadı");
        }
    }

    // ------------------------------------------------------------------ menü

    void showMenu(View anchor) {
        PopupMenu pm = new PopupMenu(this, anchor);
        Menu m = pm.getMenu();
        m.add(0, 1, 0, "Yeni sekme");
        m.add(0, 2, 1, "Yer imleri");
        m.add(0, 3, 2, "Geçmiş");
        m.add(0, 4, 3, "İndirilenler");
        MenuItem ab = m.add(0, 5, 4, "Reklam engelleyici");
        ab.setCheckable(true);
        ab.setChecked(adBlock);
        m.add(0, 8, 5, "Sayfa yakınlaştırma (%" + zoom + ")");
        m.add(0, 10, 5, "Hız ayarları");
        m.add(0, 9, 6, "Bu sayfayı başka tarayıcıda aç");
        m.add(0, 6, 7, "Çerezleri ve site verilerini temizle");
        m.add(0, 7, 8, "Klavye kısayolları");
        pm.setOnMenuItemClickListener(it -> {
            switch (it.getItemId()) {
                case 1: newTab(null, true, false); break;
                case 2: bookmarksDialog(); break;
                case 3: historyDialog(); break;
                case 4: downloadsPanel(); break;
                case 5: setAdBlock(!adBlock); break;
                case 6: clearDataDialog(); break;
                case 7: shortcutsDialog(); break;
                case 8: zoomDialog(); break;
                case 9: openExternal(current == null ? "" : current.url()); break;
                case 10: speedDialog(); break;
                default: break;
            }
            return true;
        });
        pm.show();
    }

    void shortcutsDialog() {
        dlg().setTitle("Klavye kısayolları")
                .setMessage("Ctrl+T  Yeni sekme\nCtrl+W  Sekmeyi kapat\nCtrl+Tab  Sonraki sekme\n"
                        + "Ctrl+Shift+Tab  Önceki sekme\nCtrl+L  Adres çubuğu\nCtrl+R veya F5  Yenile\n"
                        + "Ctrl+D  Yer imi ekle/kaldır\nCtrl+H  Geçmiş\nCtrl+J  İndirilenler\n"
                        + "Alt+Sol/Sağ ok  Geri/İleri")
                .setPositiveButton("Tamam", null).show();
    }

    void clearDataDialog() {
        dlg().setTitle("Çerezleri ve site verilerini temizle")
                .setMessage("Tüm sitelerden çıkış yapılır ve kayıtlı site verileri silinir. Yer imleri, "
                        + "geçmiş ve yeni sekme kutucukları korunur.")
                .setPositiveButton("Temizle", (d, w) -> {
                    if (runtime != null) runtime.getStorageController().clearData(StorageController.ClearFlags.ALL);
                    CookieManager.getInstance().removeAllCookies(null);
                    WebStorage.getInstance().deleteAllData();
                    for (Tab t : tabs) if (t.web != null) t.web.clearCache(true);
                    toast("Çerezler ve site verileri temizlendi");
                })
                .setNegativeButton("İptal", null).show();
    }

    void zoomDialog() {
        String[] labels = new String[ZOOMS.length];
        int checked = 0;
        for (int i = 0; i < ZOOMS.length; i++) {
            labels[i] = "%" + ZOOMS[i] + (ZOOMS[i] == 100 ? "  (önerilen)" : "");
            if (ZOOMS[i] == zoom) checked = i;
        }
        dlg().setTitle("Sayfa yakınlaştırma")
                .setSingleChoiceItems(labels, checked, (d, which) -> {
                    d.dismiss();
                    zoom = ZOOMS[which];
                    prefs.edit().putInt("zoom_v2", zoom).apply();
                    applyViewportAll();
                    toast("Yakınlaştırma: %" + zoom);
                })
                .setNegativeButton("Kapat", null).show();
    }

    // ------------------------------------------------------------------ reklam engelleyici

    void adBlockDialog() {
        int n = current == null ? 0 : current.blocked.get();
        dlg().setTitle("Reklam engelleyici")
                .setMessage(adBlock
                        ? "Açık. Bu sayfada " + n + " reklam ve izleyici engellendi."
                        : "Kapalı. Reklamlar ve izleyiciler engellenmiyor.")
                .setPositiveButton(adBlock ? "Kapat" : "Aç", (d, w) -> setAdBlock(!adBlock))
                .setNegativeButton("Tamam", null).show();
    }

    void setAdBlock(boolean on) {
        adBlock = on;
        prefs.edit().putBoolean("adblock", on).apply();
        if (runtime != null) try {
            ContentBlocking.Settings cb = runtime.getSettings().getContentBlocking();
            cb.setAntiTracking(on ? AT_ON : ContentBlocking.AntiTracking.NONE);
            cb.setEnhancedTrackingProtectionLevel(on ? ContentBlocking.EtpLevel.DEFAULT
                    : ContentBlocking.EtpLevel.NONE);
        } catch (Exception ignored) { }
        for (Tab t : tabs) {
            if (t.session != null) t.session.getSettings().setUseTrackingProtection(on);
        }
        setExtEnabled(on);
        dropPreloads();
        toast(on ? "Reklam engelleyici açıldı" : "Reklam engelleyici kapatıldı");
        if (current != null && !current.isNewTab) reload();
        updateShield();
    }

    // ------------------------------------------------------------------ kayıtlı veriler

    JSONArray getArr(String key) {
        try {
            return new JSONArray(prefs.getString(key, "[]"));
        } catch (JSONException e) {
            return new JSONArray();
        }
    }

    void putArr(String key, JSONArray a) {
        prefs.edit().putString(key, a.toString()).apply();
    }

    String fmtTime(long ms) {
        return new SimpleDateFormat("d MMM HH:mm", new Locale("tr", "TR")).format(new Date(ms));
    }

    void saveSession() {
        JSONArray a = new JSONArray();
        int sel = 0;
        for (Tab t : tabs) {
            String u = t.url();
            if (u.isEmpty()) u = "newtab";
            if (t == current) sel = a.length();
            JSONObject o = new JSONObject();
            try {
                o.put("u", u);
                o.put("t", t.title == null ? "" : t.title);
            } catch (JSONException ignored) { }
            a.put(o);
        }
        prefs.edit().putString("session", a.toString()).putInt("sessionIdx", sel).apply();
    }

    void restoreSession() {
        JSONArray a = getArr("session");
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o == null) continue;
            String u = o.optString("u");
            if (u.isEmpty()) continue;
            Tab t = newTab(null, false, false);
            if (!u.equals("newtab") && !u.startsWith("https://accounts.google.com/")) {
                t.pendingUrl = u;
                t.isNewTab = false;
                t.url = u;
                t.title = o.optString("t", u);
            }
        }
        if (tabs.isEmpty()) {
            newTab(null, true, false);
        } else {
            int idx = Math.min(Math.max(prefs.getInt("sessionIdx", 0), 0), tabs.size() - 1);
            selectTab(tabs.get(idx));
        }
    }

    // Geçmiş

    void addHistory(String title, String url) {
        JSONArray a = getArr("history");
        JSONArray n = new JSONArray();
        JSONObject o = new JSONObject();
        try {
            o.put("t", (title == null || title.isEmpty()) ? url : title);
            o.put("u", url);
            o.put("time", System.currentTimeMillis());
        } catch (JSONException ignored) { }
        n.put(o);
        for (int i = 0; i < a.length() && n.length() < 500; i++) {
            JSONObject x = a.optJSONObject(i);
            if (x != null && !url.equals(x.optString("u"))) n.put(x);
        }
        putArr("history", n);
    }

    void historyDialog() {
        final JSONArray a = getArr("history");
        if (a.length() == 0) {
            toast("Geçmiş boş");
            return;
        }
        String[] items = new String[a.length()];
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            items[i] = o == null ? "" : o.optString("t") + "\n" + fmtTime(o.optLong("time"))
                    + "   " + o.optString("u");
        }
        dlg().setTitle("Geçmiş")
                .setItems(items, (d, which) -> {
                    JSONObject o = a.optJSONObject(which);
                    if (o != null) load(current, o.optString("u"));
                })
                .setNeutralButton("Geçmişi temizle", (d, w) -> {
                    putArr("history", new JSONArray());
                    toast("Geçmiş temizlendi");
                })
                .setNegativeButton("Kapat", null).show();
    }

    // Yer imleri

    int bookmarkIndex(String url) {
        JSONArray a = getArr("bookmarks");
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o != null && url.equals(o.optString("u"))) return i;
        }
        return -1;
    }

    void toggleBookmark() {
        if (current == null) return;
        String url = current.url();
        if (url.isEmpty()) {
            toast("Yeni sekme sayfası yer imlerine eklenemez");
            return;
        }
        int idx = bookmarkIndex(url);
        if (idx >= 0) {
            removeBookmark(idx);
            toast("Yer imi kaldırıldı");
            return;
        }
        editBookmark(-1, tabTitle(current), url);
    }

    void removeBookmark(int idx) {
        JSONArray a = getArr("bookmarks");
        if (idx >= 0 && idx < a.length()) a.remove(idx);
        putArr("bookmarks", a);
        refreshBookmarkBar();
        updateToolbar();
    }

    void editBookmark(final int idx, String title, String url) {
        formDialog(idx < 0 ? "Yer imi ekle" : "Yer imini düzenle", title, url, (nm, u) -> {
            JSONArray a = getArr("bookmarks");
            JSONObject o = new JSONObject();
            try {
                o.put("t", nm);
                o.put("u", u);
                if (idx >= 0 && idx < a.length()) a.put(idx, o); else a.put(o);
            } catch (JSONException ignored) { }
            putArr("bookmarks", a);
            refreshBookmarkBar();
            updateToolbar();
            toast(idx < 0 ? "Yer imlerine eklendi" : "Yer imi kaydedildi");
        });
    }

    void bookmarkMenu(final int idx) {
        final JSONObject o = getArr("bookmarks").optJSONObject(idx);
        if (o == null) return;
        final String u = o.optString("u");
        dlg().setTitle(o.optString("t"))
                .setItems(new String[]{"Aç", "Yeni sekmede aç", "Düzenle", "Sil"}, (d, which) -> {
                    if (which == 0) load(current, u);
                    else if (which == 1) newTab(u, true, true);
                    else if (which == 2) editBookmark(idx, o.optString("t"), u);
                    else removeBookmark(idx);
                }).show();
    }

    void bookmarksDialog() {
        JSONArray a = getArr("bookmarks");
        if (a.length() == 0) {
            toast("Henüz yer imi yok. Eklemek için ☆ simgesine dokunun.");
            return;
        }
        String[] items = new String[a.length()];
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            items[i] = o == null ? "" : o.optString("t") + "\n" + o.optString("u");
        }
        dlg().setTitle("Yer imleri")
                .setItems(items, (d, which) -> bookmarkMenu(which))
                .setNegativeButton("Kapat", null).show();
    }

    void refreshBookmarkBar() {
        bookmarkStrip.removeAllViews();
        JSONArray a = getArr("bookmarks");
        if (a.length() == 0) {
            TextView h = new TextView(this);
            h.setText("Yer imi eklemek için adres çubuğundaki ☆ simgesine dokunun");
            h.setTextColor(C_DIM);
            h.setTextSize(12);
            h.setPadding(dp(6), 0, 0, 0);
            bookmarkStrip.addView(h);
            return;
        }
        for (int i = 0; i < a.length(); i++) {
            final JSONObject o = a.optJSONObject(i);
            if (o == null) continue;
            final int idx = i;
            TextView c = new TextView(this);
            c.setText(o.optString("t"));
            c.setTextColor(C_TEXT);
            c.setTextSize(13);
            c.setSingleLine(true);
            c.setEllipsize(TextUtils.TruncateAt.END);
            c.setMaxWidth(dp(180));
            c.setGravity(Gravity.CENTER_VERTICAL);
            c.setPadding(dp(10), 0, dp(10), 0);
            c.setBackground(ripple(false));
            c.setOnTouchListener((v, ev) -> {
                if (ev.getAction() == MotionEvent.ACTION_DOWN) preconnect(o.optString("u"));
                return false;
            });
            c.setOnClickListener(v -> load(current, o.optString("u")));
            c.setOnLongClickListener(v -> { bookmarkMenu(idx); return true; });
            c.setOnContextClickListener(v -> { bookmarkMenu(idx); return true; });
            bookmarkStrip.addView(c, new LinearLayout.LayoutParams(-2, dp(28)));
        }
    }

    // ------------------------------------------------------------------ indirme yöneticisi

    static final int DL_RUN = 0, DL_DONE = 1, DL_FAIL = 2, DL_PAUSE = 3;
    static final int REQ_DL_DIR = 14;
    final ArrayList<Task> tasks = new ArrayList<>();
    TextView pendingFolderLabel;
    long lastTaskSave;

    /** Bir indirme: duraklatılabilir, devam ettirilebilir, iptal edilebilir. */
    class Task {
        long id, size = -1, time;
        volatile long done;
        String url, name, mime, referer, ua, dest, err;
        volatile int state, pct = -1;
        boolean gecko, hls;
        volatile boolean pauseReq, cancelReq;
        InputStream initial;
        Variant variant;
        int quality;
        volatile double speed;
        long speedMark, speedBytes;

        JSONObject toJson() {
            JSONObject o = new JSONObject();
            try {
                o.put("id", id).put("size", size).put("done", done).put("time", time)
                        .put("url", url).put("name", name).put("mime", mime).put("ref", referer)
                        .put("ua", ua).put("dest", dest).put("err", err).put("state", state)
                        .put("gecko", gecko).put("hls", hls).put("pct", pct);
            } catch (JSONException ignored) { }
            return o;
        }
    }

    Task taskFrom(JSONObject o) {
        Task k = new Task();
        k.id = o.optLong("id");
        k.size = o.optLong("size", -1);
        k.done = o.optLong("done");
        k.time = o.optLong("time");
        k.url = o.has("url") ? o.optString("url") : null;
        k.name = o.optString("name", "dosya");
        k.mime = o.optString("mime", "application/octet-stream");
        k.referer = o.has("ref") ? o.optString("ref") : null;
        k.ua = o.has("ua") ? o.optString("ua") : null;
        k.dest = o.has("dest") ? o.optString("dest") : null;
        k.err = o.has("err") ? o.optString("err") : null;
        k.state = o.optInt("state");
        k.gecko = o.optBoolean("gecko");
        k.hls = o.optBoolean("hls");
        k.pct = o.optInt("pct", -1);
        return k;
    }

    void loadTasks() {
        tasks.clear();
        JSONArray a = getArr("dl_tasks");
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o == null) continue;
            Task k = taskFrom(o);
            if (k.state == DL_RUN || k.state == DL_PAUSE) {
                if (k.hls) {
                    k.state = DL_FAIL;
                    k.err = "Uygulama kapandığı için yarıda kaldı";
                } else {
                    if (k.state == DL_RUN) k.err = "Kesildi, devam ettirebilirsin";
                    k.state = DL_PAUSE;
                }
            }
            tasks.add(k);
        }
    }

    void saveTasks(boolean force) {
        long now = SystemClock.elapsedRealtime();
        if (!force && now - lastTaskSave < 1500) return;
        lastTaskSave = now;
        JSONArray a = new JSONArray();
        for (int i = 0; i < tasks.size() && i < 200; i++) a.put(tasks.get(i).toJson());
        putArr("dl_tasks", a);
    }

    static void closeQuiet(java.io.Closeable c) {
        if (c == null) return;
        try { c.close(); } catch (Exception ignored) { }
    }

    static String sanitizeName(String n) {
        String r = n.replaceAll("[\\\\/:*?\"<>|\\n\\r\\t]", "_").trim();
        return r.isEmpty() ? "dosya" : r;
    }

    static String fmtSize(double b) {
        Locale tr = new Locale("tr", "TR");
        if (b >= 1073741824.0) return String.format(tr, "%.2f GB", b / 1073741824.0);
        if (b >= 1048576.0) return String.format(tr, "%.2f MB", b / 1048576.0);
        if (b >= 1024.0) return String.format(tr, "%.0f KB", b / 1024.0);
        return String.format(tr, "%.0f B", b);
    }

    /** Sitenin indirme isteği: önce nereye ve hangi adla kaydedileceği sorulur. */
    void requestDownload(String url, String ua, String cd, String mime, long size, String referer,
                         boolean gecko, InputStream initial, String forcedName) {
        boolean http = url != null && (url.startsWith("http://") || url.startsWith("https://"));
        if (!http && initial == null) {
            toast("Bu dosya bu şekilde indirilemiyor");
            return;
        }
        final Task k = new Task();
        k.id = System.currentTimeMillis();
        k.time = k.id;
        k.url = url;
        k.gecko = gecko;
        k.ua = ua != null ? ua : (gecko ? desktopUa : CHROME_UA);
        k.mime = (mime == null || mime.trim().isEmpty()) ? "application/octet-stream" : mime.split(";")[0].trim();
        k.size = size;
        k.referer = referer;
        k.initial = initial;
        k.name = sanitizeName(forcedName != null ? forcedName : URLUtil.guessFileName(url, cd, mime));
        confirmDownload(k);
    }

    void requestGeckoResponse(WebResponse r) {
        if (r == null) return;
        String cd = header(r.headers, "Content-Disposition");
        String ct = header(r.headers, "Content-Type");
        String cl = header(r.headers, "Content-Length");
        long size = -1;
        try { if (cl != null) size = Long.parseLong(cl.trim()); } catch (Exception ignored) { }
        requestDownload(r.uri, desktopUa, cd, ct, size, current != null ? current.url() : null, true, r.body, null);
    }

    void requestHls(Tab t, Variant v, String referer, int quality) {
        final Task k = new Task();
        k.id = System.currentTimeMillis();
        k.time = k.id;
        k.url = v.uri;
        k.hls = true;
        k.variant = v;
        k.quality = quality;
        k.referer = referer;
        k.mime = "video/mp4";
        k.name = videoFileName(t, quality, "mp4");
        confirmDownload(k);
    }

    String folderLabel() {
        return prefs.getString("dl_tree_name", "İndirilenler");
    }

    void confirmDownload(final Task k) {
        if (prefs.getBoolean("dl_noask", false)) {
            startTask(k);
            return;
        }
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(24), dp(2), dp(24), 0);

        TextView size = new TextView(this);
        size.setText(k.size > 0 ? fmtSize(k.size) : (k.hls ? "Video akışı" : "Boyut bilinmiyor"));
        size.setTextColor(C_DIM);
        size.setTextSize(15);
        box.addView(size);

        LinearLayout r1 = new LinearLayout(this);
        r1.setGravity(Gravity.CENTER_VERTICAL);
        TextView i1 = new TextView(this);
        i1.setText("📄");
        i1.setTextSize(20);
        r1.addView(i1, new LinearLayout.LayoutParams(dp(40), -2));
        final EditText name = new EditText(this);
        name.setSingleLine(true);
        name.setText(k.name);
        r1.addView(name, new LinearLayout.LayoutParams(0, -2, 1f));
        LinearLayout.LayoutParams r1lp = new LinearLayout.LayoutParams(-1, -2);
        r1lp.topMargin = dp(12);
        box.addView(r1, r1lp);

        LinearLayout r2 = new LinearLayout(this);
        r2.setGravity(Gravity.CENTER_VERTICAL);
        TextView i2 = new TextView(this);
        i2.setText("📁");
        i2.setTextSize(20);
        r2.addView(i2, new LinearLayout.LayoutParams(dp(40), -2));
        final TextView folder = new TextView(this);
        folder.setText(folderLabel() + "  ▾");
        folder.setTextColor(C_TEXT);
        folder.setTextSize(17);
        folder.setPadding(dp(4), dp(10), dp(4), dp(10));
        folder.setBackground(ripple(false));
        folder.setOnClickListener(v -> folderMenu(folder));
        r2.addView(folder, new LinearLayout.LayoutParams(0, -2, 1f));
        box.addView(r2);

        final CheckBox noAsk = new CheckBox(this);
        noAsk.setText("Bir daha gösterme");
        LinearLayout.LayoutParams cblp = new LinearLayout.LayoutParams(-2, -2);
        cblp.topMargin = dp(8);
        box.addView(noAsk, cblp);

        pendingFolderLabel = folder;
        AlertDialog d = dlg().setTitle("Nereye indirileceğini seçin")
                .setView(box)
                .setPositiveButton("İndir", (dd, w) -> {
                    String nm = name.getText().toString().trim();
                    if (!nm.isEmpty()) k.name = sanitizeName(nm);
                    if (noAsk.isChecked()) prefs.edit().putBoolean("dl_noask", true).apply();
                    startTask(k);
                })
                .setNegativeButton("İptal", (dd, w) -> closeQuiet(k.initial))
                .setOnCancelListener(dd -> closeQuiet(k.initial))
                .show();
        d.setOnDismissListener(dd -> pendingFolderLabel = null);
    }

    void folderMenu(final TextView label) {
        dlg().setTitle("Kaydedilecek klasör")
                .setItems(new String[]{"İndirilenler (varsayılan)", "Başka bir klasör seç…"}, (d, which) -> {
                    if (which == 0) {
                        prefs.edit().remove("dl_tree").remove("dl_tree_name").apply();
                        label.setText(folderLabel() + "  ▾");
                    } else {
                        try {
                            startActivityForResult(new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE), REQ_DL_DIR);
                        } catch (Exception e) {
                            toast("Klasör seçici açılamadı");
                        }
                    }
                }).show();
    }

    void onFolderPicked(Uri tree) {
        try {
            getContentResolver().takePersistableUriPermission(tree,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        } catch (Exception ignored) { }
        String id = DocumentsContract.getTreeDocumentId(tree);
        String nm = id.contains(":") ? id.substring(id.indexOf(':') + 1) : id;
        if (nm.contains("/")) nm = nm.substring(nm.lastIndexOf('/') + 1);
        if (nm.isEmpty()) nm = "Dahili depolama";
        prefs.edit().putString("dl_tree", tree.toString()).putString("dl_tree_name", nm).apply();
        if (pendingFolderLabel != null) pendingFolderLabel.setText(nm + "  ▾");
    }

    Uri createDest(Task k) throws Exception {
        String tree = prefs.getString("dl_tree", null);
        if (tree != null) {
            try {
                Uri t = Uri.parse(tree);
                Uri parent = DocumentsContract.buildDocumentUriUsingTree(t, DocumentsContract.getTreeDocumentId(t));
                Uri u = DocumentsContract.createDocument(getContentResolver(), parent, k.mime, k.name);
                if (u != null) return u;
            } catch (Exception ignored) { }
        }
        ContentValues cv = new ContentValues();
        cv.put(MediaStore.Downloads.DISPLAY_NAME, k.name);
        cv.put(MediaStore.Downloads.MIME_TYPE, k.mime);
        cv.put(MediaStore.Downloads.IS_PENDING, 1);
        Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
        if (u == null) throw new Exception("!İndirilenler klasörüne yazılamadı");
        return u;
    }

    boolean isMediaStore(Task k) {
        return k.dest != null && MediaStore.AUTHORITY.equals(Uri.parse(k.dest).getAuthority());
    }

    void startTask(Task k) {
        tasks.add(0, k);
        toast("İndiriliyor: " + k.name);
        runTask(k);
    }

    void runTask(final Task k) {
        k.pauseReq = false;
        k.cancelReq = false;
        k.state = DL_RUN;
        k.err = null;
        k.speed = 0;
        saveTasks(true);
        refreshPanel();
        new Thread(() -> {
            try {
                if (k.dest == null) k.dest = createDest(k).toString();
                if (k.hls) runHls(k);
                else download(k);
            } catch (Exception e) {
                failTask(k, e);
            }
        }).start();
    }

    void tickSpeed(Task k) {
        long now = SystemClock.elapsedRealtime();
        if (k.speedMark == 0) {
            k.speedMark = now;
            k.speedBytes = k.done;
            return;
        }
        long dt = now - k.speedMark;
        if (dt >= 700) {
            k.speed = (k.done - k.speedBytes) * 1000.0 / dt;
            k.speedMark = now;
            k.speedBytes = k.done;
            if (k.size > 0) k.pct = (int) (k.done * 100 / k.size);
            ui.post(() -> saveTasks(false));
        }
    }

    void ensureRuntimeBlocking() throws Exception {
        if (runtime != null) return;
        final CountDownLatch latch = new CountDownLatch(1);
        ui.post(() -> {
            try { ensureRuntime(); } catch (Exception ignored) { }
            latch.countDown();
        });
        latch.await(10, TimeUnit.SECONDS);
        if (runtime == null) throw new Exception("!İndirme başlatılamadı");
    }

    static long totalFrom(int code, String contentRange, long contentLength, long done) {
        if (code == 206 && contentRange != null && contentRange.contains("/")) {
            try {
                return Long.parseLong(contentRange.substring(contentRange.lastIndexOf('/') + 1).trim());
            } catch (Exception ignored) { }
        }
        if (contentLength > 0) return code == 206 ? done + contentLength : contentLength;
        return -1;
    }

    /** Dosyayı indirir; duraklatılırsa kaldığı yerden (Range isteğiyle) devam eder. */
    void download(Task k) throws Exception {
        InputStream in = null;
        HttpURLConnection c = null;
        int code;
        long total;
        try {
            if (k.initial != null && k.done == 0) {
                in = k.initial;
                k.initial = null;
                code = 200;
                total = k.size;
            } else if (k.gecko) {
                if (k.url == null || !k.url.startsWith("http")) throw new Exception("!Bu indirme devam ettirilemiyor");
                ensureRuntimeBlocking();
                if (executor == null) executor = new GeckoWebExecutor(runtime);
                WebRequest.Builder b = new WebRequest.Builder(k.url)
                        .header("User-Agent", k.ua != null ? k.ua : desktopUa);
                if (k.referer != null) b.header("Referer", k.referer);
                if (k.done > 0) b.header("Range", "bytes=" + k.done + "-");
                WebResponse r;
                try {
                    r = executor.fetch(b.build()).poll(60000);
                } catch (Throwable th) {
                    throw new Exception("!Sunucuya bağlanılamadı");
                }
                code = r.statusCode;
                in = r.body;
                long cl = -1;
                try { cl = Long.parseLong(nz(header(r.headers, "Content-Length"), "-1").trim()); } catch (Exception ignored) { }
                total = totalFrom(code, header(r.headers, "Content-Range"), cl, k.done);
            } else {
                c = (HttpURLConnection) new URL(k.url).openConnection();
                c.setInstanceFollowRedirects(true);
                c.setConnectTimeout(20000);
                c.setReadTimeout(60000);
                c.setRequestProperty("User-Agent", k.ua != null ? k.ua : CHROME_UA);
                if (k.referer != null) c.setRequestProperty("Referer", k.referer);
                String cookie = CookieManager.getInstance().getCookie(k.url);
                if (cookie != null) c.setRequestProperty("Cookie", cookie);
                if (k.done > 0) c.setRequestProperty("Range", "bytes=" + k.done + "-");
                code = c.getResponseCode();
                if (code == 416 && k.size > 0 && k.done >= k.size) {
                    finishTask(k);
                    return;
                }
                if (code >= 400) throw new Exception("!Sunucu indirmeyi reddetti (" + code + ")");
                in = c.getInputStream();
                total = totalFrom(code, c.getHeaderField("Content-Range"), c.getContentLengthLong(), k.done);
            }
            if (code >= 400 || in == null) throw new Exception("!Sunucu indirmeyi reddetti (" + code + ")");
            boolean append = k.done > 0 && code == 206;
            if (!append) k.done = 0;
            if (total > 0) k.size = total;
            k.speedMark = 0;
            byte[] buf = new byte[65536];
            try (OutputStream o = getContentResolver().openOutputStream(Uri.parse(k.dest), append ? "wa" : "wt")) {
                if (o == null) throw new Exception("!Dosya yazılamadı");
                int n;
                while ((n = in.read(buf)) > 0) {
                    o.write(buf, 0, n);
                    k.done += n;
                    tickSpeed(k);
                    if (k.cancelReq || k.pauseReq) break;
                }
            }
            if (k.cancelReq) {
                cancelCleanup(k);
                return;
            }
            if (k.pauseReq) {
                k.state = DL_PAUSE;
                k.speed = 0;
                ui.post(() -> { saveTasks(true); refreshPanel(); });
                return;
            }
            if (k.size > 0 && k.done < k.size) throw new Exception("!Bağlantı kesildi");
            finishTask(k);
        } finally {
            closeQuiet(in);
            if (c != null) c.disconnect();
        }
    }

    void runHls(Task k) throws Exception {
        File dir = new File(getCacheDir(), "hls" + k.id);
        //noinspection ResultOfMethodCallIgnored
        dir.mkdirs();
        try {
            Variant v = k.variant;
            if (v == null) throw new Exception("!Bu indirme devam ettirilemiyor");
            boolean sepAudio = v.audioUri != null;
            File vf = new File(dir, "v.bin");
            boolean fmp4 = fetchSegments(k, v.uri, k.referer, vf, 0, sepAudio ? 75 : 95);
            File af = null;
            if (sepAudio) {
                af = new File(dir, "a.bin");
                fetchSegments(k, v.audioUri, k.referer, af, 75, 95);
            }
            File out = new File(dir, "out.mp4");
            boolean muxed = remux(vf, af, out);
            File fin = muxed ? out : vf;
            if (!muxed && !fmp4) renameDest(k, k.name.replaceAll("\\.mp4$", ".ts"), "video/mp2t");
            try (InputStream in = new java.io.FileInputStream(fin);
                 OutputStream o = getContentResolver().openOutputStream(Uri.parse(k.dest), "wt")) {
                if (o == null) throw new Exception("!Dosya yazılamadı");
                byte[] buf = new byte[65536];
                int n;
                while ((n = in.read(buf)) > 0) o.write(buf, 0, n);
            }
            k.size = fin.length();
            k.done = k.size;
            k.pct = 100;
            finishTask(k);
        } catch (Exception e) {
            if (k.cancelReq) cancelCleanup(k);
            else throw e;
        } finally {
            deleteDir(dir);
        }
    }

    void renameDest(Task k, String newName, String mime) {
        try {
            Uri u = Uri.parse(k.dest);
            if (isMediaStore(k)) {
                ContentValues cv = new ContentValues();
                cv.put(MediaStore.Downloads.DISPLAY_NAME, newName);
                cv.put(MediaStore.Downloads.MIME_TYPE, mime);
                getContentResolver().update(u, cv, null, null);
            } else {
                Uri r = DocumentsContract.renameDocument(getContentResolver(), u, newName);
                if (r != null) k.dest = r.toString();
            }
            k.name = newName;
            k.mime = mime;
        } catch (Exception ignored) { }
    }

    void finishTask(final Task k) {
        if (isMediaStore(k)) {
            try {
                ContentValues done = new ContentValues();
                done.put(MediaStore.Downloads.IS_PENDING, 0);
                getContentResolver().update(Uri.parse(k.dest), done, null, null);
            } catch (Exception ignored) { }
        }
        k.state = DL_DONE;
        k.err = null;
        k.speed = 0;
        k.pct = 100;
        ui.post(() -> {
            saveTasks(true);
            refreshPanel();
            toast("İndirme tamamlandı: " + k.name);
        });
    }

    void failTask(final Task k, Exception e) {
        if (k.cancelReq) {
            cancelCleanup(k);
            return;
        }
        String m = e.getMessage();
        k.err = (m != null && m.startsWith("!")) ? m.substring(1) : "Bağlantı kesildi";
        k.state = DL_FAIL;
        k.speed = 0;
        ui.post(() -> {
            saveTasks(true);
            refreshPanel();
            toast("İndirme durdu: " + k.name + " (" + k.err + ")");
        });
    }

    void deleteDest(Task k) {
        if (k.dest == null) return;
        try {
            Uri u = Uri.parse(k.dest);
            if (isMediaStore(k)) getContentResolver().delete(u, null, null);
            else DocumentsContract.deleteDocument(getContentResolver(), u);
        } catch (Exception ignored) { }
    }

    void cancelCleanup(final Task k) {
        deleteDest(k);
        ui.post(() -> {
            tasks.remove(k);
            saveTasks(true);
            refreshPanel();
            toast("İndirme iptal edildi: " + k.name);
        });
    }

    void pauseTask(Task k) {
        if (k.state == DL_RUN) {
            k.pauseReq = true;
            if (k.hls) {
                k.state = DL_PAUSE;
                refreshPanel();
            }
        }
    }

    void resumeTask(Task k) {
        if (k.hls && k.state == DL_PAUSE) {
            k.pauseReq = false;
            k.state = DL_RUN;
            refreshPanel();
            return;
        }
        if (k.state == DL_PAUSE || k.state == DL_FAIL) runTask(k);
    }

    void cancelTask(final Task k) {
        k.cancelReq = true;
        boolean active = k.state == DL_RUN || (k.hls && k.state == DL_PAUSE);
        if (!active) new Thread(() -> cancelCleanup(k)).start();
    }

    void openTask(Task k) {
        if (k.dest == null) return;
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setDataAndType(Uri.parse(k.dest), k.mime == null ? "*/*" : k.mime);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            startActivity(i);
        } catch (Exception e) {
            toast("Bu dosyayı açacak uygulama yok");
        }
    }

    // İndirilenler paneli

    AlertDialog panel;
    LinearLayout panelList;
    String panelSig = "";
    final HashMap<Long, TextView> rowStatus = new HashMap<>();
    final HashMap<Long, ProgressBar> rowBar = new HashMap<>();

    final Runnable panelTick = new Runnable() {
        @Override
        public void run() {
            if (panel == null) return;
            refreshPanel();
            ui.postDelayed(this, 700);
        }
    };

    void downloadsPanel() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), 0, dp(20), 0);
        final CheckBox ask = new CheckBox(this);
        ask.setText("İndirmeden önce nereye kaydedileceğini sor");
        ask.setChecked(!prefs.getBoolean("dl_noask", false));
        ask.setOnCheckedChangeListener((b, on) -> prefs.edit().putBoolean("dl_noask", !on).apply());
        root.addView(ask);
        ScrollView sv = new ScrollView(this);
        panelList = new LinearLayout(this);
        panelList.setOrientation(LinearLayout.VERTICAL);
        sv.addView(panelList);
        int h = (int) (getResources().getDisplayMetrics().heightPixels * 0.55f);
        root.addView(sv, new LinearLayout.LayoutParams(-1, h));
        panelSig = "";
        panel = dlg().setTitle("İndirilenler")
                .setView(root)
                .setNeutralButton("Klasörü aç", (d, w) -> {
                    try {
                        startActivity(new Intent(DownloadManager.ACTION_VIEW_DOWNLOADS)
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                    } catch (Exception e) {
                        toast("İndirilenler klasörü açılamadı");
                    }
                })
                .setPositiveButton("Kapat", null)
                .show();
        panel.setOnDismissListener(d -> {
            panel = null;
            ui.removeCallbacks(panelTick);
        });
        refreshPanel();
        ui.postDelayed(panelTick, 700);
    }

    void refreshPanel() {
        if (panel == null || panelList == null) return;
        StringBuilder sig = new StringBuilder();
        for (Task k : tasks) sig.append(k.id).append(':').append(k.state).append(';');
        if (!sig.toString().equals(panelSig)) {
            panelSig = sig.toString();
            panelList.removeAllViews();
            rowStatus.clear();
            rowBar.clear();
            if (tasks.isEmpty()) {
                TextView e = new TextView(this);
                e.setText("Henüz bir şey indirmediniz.");
                e.setTextColor(C_DIM);
                e.setPadding(0, dp(24), 0, dp(24));
                panelList.addView(e);
            }
            for (Task k : tasks) panelList.addView(buildRow(k));
        }
        for (Task k : tasks) {
            TextView st = rowStatus.get(k.id);
            ProgressBar bar = rowBar.get(k.id);
            if (st != null) st.setText(statusText(k));
            if (bar != null) {
                int p = k.size > 0 ? (int) (k.done * 1000 / Math.max(1, k.size)) : (k.pct >= 0 ? k.pct * 10 : -1);
                bar.setIndeterminate(p < 0 && k.state == DL_RUN);
                if (p >= 0) bar.setProgress(p);
            }
        }
    }

    String statusText(Task k) {
        String sizes = fmtSize(k.done) + (k.size > 0 ? " / " + fmtSize(k.size) : "");
        String pct = k.size > 0 ? " · %" + (int) (k.done * 100 / Math.max(1, k.size)) : (k.pct >= 0 ? " · %" + k.pct : "");
        switch (k.state) {
            case DL_RUN:
                return sizes + pct + (k.speed > 0 ? " · " + fmtSize(k.speed) + "/sn" : "");
            case DL_PAUSE:
                return "Duraklatıldı · " + sizes + pct + (k.err != null ? " · " + k.err : "");
            case DL_FAIL:
                return "Durdu: " + (k.err != null ? k.err : "bilinmeyen hata") + " · " + sizes;
            default:
                return "✓ " + fmtSize(k.size > 0 ? k.size : k.done) + " · " + fmtTime(k.time)
                        + " · " + (isMediaStore(k) ? "İndirilenler" : folderLabel());
        }
    }

    TextView smallBtn(String text, View.OnClickListener l) {
        TextView b = new TextView(this);
        b.setText(text);
        b.setTextColor(C_ACCENT);
        b.setTextSize(14);
        b.setPadding(dp(12), dp(8), dp(12), dp(8));
        b.setBackground(ripple(false));
        b.setOnClickListener(l);
        return b;
    }

    View buildRow(final Task k) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.VERTICAL);
        row.setPadding(0, dp(10), 0, dp(6));
        TextView nm = new TextView(this);
        nm.setText(k.name);
        nm.setTextColor(C_TEXT);
        nm.setTextSize(15);
        nm.setTypeface(Typeface.DEFAULT_BOLD);
        nm.setSingleLine(true);
        nm.setEllipsize(TextUtils.TruncateAt.MIDDLE);
        row.addView(nm);
        if (k.state != DL_DONE) {
            ProgressBar bar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
            bar.setMax(1000);
            bar.setProgressTintList(ColorStateList.valueOf(C_ACCENT));
            bar.setIndeterminateTintList(ColorStateList.valueOf(C_ACCENT));
            LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(-1, dp(8));
            blp.topMargin = dp(6);
            row.addView(bar, blp);
            rowBar.put(k.id, bar);
        }
        TextView st = new TextView(this);
        st.setTextColor(C_DIM);
        st.setTextSize(12);
        st.setText(statusText(k));
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(-2, -2);
        slp.topMargin = dp(4);
        row.addView(st, slp);
        rowStatus.put(k.id, st);

        LinearLayout btns = new LinearLayout(this);
        btns.setOrientation(LinearLayout.HORIZONTAL);
        if (k.state == DL_RUN) {
            btns.addView(smallBtn("⏸ Duraklat", v -> pauseTask(k)));
            btns.addView(smallBtn("✕ İptal", v -> cancelTask(k)));
        } else if (k.state == DL_PAUSE) {
            btns.addView(smallBtn("▶ Devam", v -> resumeTask(k)));
            btns.addView(smallBtn("✕ İptal", v -> cancelTask(k)));
        } else if (k.state == DL_FAIL) {
            if (!k.hls && k.url != null && k.url.startsWith("http")) {
                btns.addView(smallBtn("↻ Kaldığı yerden dene", v -> resumeTask(k)));
            }
            btns.addView(smallBtn("✕ Sil", v -> cancelTask(k)));
        } else {
            btns.addView(smallBtn("Aç", v -> openTask(k)));
            btns.addView(smallBtn("Listeden kaldır", v -> {
                tasks.remove(k);
                saveTasks(true);
                refreshPanel();
            }));
        }
        row.addView(btns);
        View line = new View(this);
        line.setBackgroundColor(0x22FFFFFF);
        row.addView(line, new LinearLayout.LayoutParams(-1, 1));
        return row;
    }

    // İndirmeler (İndirilenler klasörüne kaydedilir)

    static String header(Map<String, String> h, String key) {
        if (h == null) return null;
        for (Map.Entry<String, String> e : h.entrySet()) {
            if (e.getKey() != null && e.getKey().equalsIgnoreCase(key)) return e.getValue();
        }
        return null;
    }

    // ------------------------------------------------------------------ video indirici

    static final Pattern VIDEO_PATH = Pattern.compile("\\.(mp4|m4v|webm|mov|m3u8)$", Pattern.CASE_INSENSITIVE);
    static final Pattern QUALITY_IN_URL = Pattern.compile("(?<!\\d)(2160|1440|1080|720|540|480|360|240)(?!\\d)");
    static final String DETECT_JS =
            "(function(){var out=[];function add(u,h,l){if(!u||u.indexOf('blob:')===0||u.indexOf('data:')===0)return;"
            + "out.push({u:u,h:h||0,l:l||''});}"
            + "document.querySelectorAll('video').forEach(function(v){add(v.currentSrc||v.src,v.videoHeight,'');"
            + "v.querySelectorAll('source').forEach(function(s){var lab=s.getAttribute('label')||s.getAttribute('res')"
            + "||s.getAttribute('size')||s.getAttribute('data-res')||s.getAttribute('data-quality')||'';"
            + "add(s.src,parseInt(lab)||0,lab);});});return JSON.stringify(out);})()";

    static class VideoCand {
        String url, label;
        int height;
        boolean hls;
    }

    static class Variant {
        String uri, audioUri;
        int height;
        long bw;
    }

    static boolean isBlockedVideoSite(String url) {
        String h = hostOf(url);
        return h.endsWith("youtube.com") || h.endsWith("youtu.be") || h.endsWith("google.com")
                || h.endsWith("netflix.com") || h.endsWith("disneyplus.com") || h.endsWith("primevideo.com")
                || h.endsWith("blutv.com") || h.endsWith("exxen.com") || h.endsWith("tabii.com");
    }

    static int heightFromUrl(String url) {
        Matcher m = QUALITY_IN_URL.matcher(url);
        int best = 0;
        while (m.find()) best = Math.max(best, Integer.parseInt(m.group(1)));
        return best;
    }

    static int category(int h) {
        if (h >= 2000) return 2160;
        if (h >= 1300) return 1440;
        if (h >= 1000) return 1080;
        if (h >= 700) return 720;
        return h;
    }

    static String qualityName(int c) {
        switch (c) {
            case 2160: return "2160p (4K)";
            case 1440: return "1440p (2K)";
            case 1080: return "1080p (Full HD)";
            case 720: return "720p (HD)";
            case 0: return "Kaynak kalitesi";
            default: return c + "p";
        }
    }

    String videoFileName(Tab t, int quality, String ext) {
        String base = t.title == null ? "" : t.title.replaceAll("^\\(\\d+\\)\\s*", "");
        base = base.replaceAll("[\\\\/:*?\"<>|\\n\\r\\t]", " ").replaceAll("\\s+", " ").trim();
        if (base.isEmpty()) base = "video";
        if (base.length() > 60) base = base.substring(0, 60).trim();
        return base + (quality > 0 ? " " + quality + "p" : "") + "." + ext;
    }

    void videoButton() {
        final Tab t = current;
        if (t == null || t.isNewTab) return;
        if (t.gecko || isBlockedVideoSite(t.url())) {
            dlg().setTitle("Bu sitede video indirilemez")
                    .setMessage("YouTube, Google ve Netflix gibi platformlar videolarını kopyalamaya karşı korumalı "
                            + "biçimde yayınlıyor; bu koruma aşılmaz. YouTube Premium üyeliğinle videoları YouTube "
                            + "uygulamasındaki İndir düğmesiyle çevrimdışı izleyebilirsin.")
                    .setPositiveButton("Tamam", null).show();
            return;
        }
        if (t.web == null) return;
        t.web.evaluateJavascript(DETECT_JS, res -> collectVideos(t, res));
    }

    void collectVideos(Tab t, String res) {
        ArrayList<VideoCand> list = new ArrayList<>();
        ArrayList<String> seen = new ArrayList<>();
        try {
            Object v = new JSONTokener(res == null ? "\"[]\"" : res).nextValue();
            JSONArray a = new JSONArray(v.toString());
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                String u = o.optString("u");
                if (!u.startsWith("http") || seen.contains(u)) continue;
                seen.add(u);
                VideoCand c = new VideoCand();
                c.url = u;
                c.hls = u.toLowerCase(Locale.ROOT).contains(".m3u8");
                c.height = o.optInt("h") > 0 ? o.optInt("h") : heightFromUrl(u);
                c.label = o.optString("l");
                list.add(c);
            }
        } catch (Exception ignored) { }
        synchronized (t.netVideos) {
            for (String u : t.netVideos) {
                if (seen.contains(u)) continue;
                seen.add(u);
                VideoCand c = new VideoCand();
                c.url = u;
                c.hls = u.toLowerCase(Locale.ROOT).contains(".m3u8");
                c.height = heightFromUrl(u);
                list.add(c);
            }
        }
        if (list.isEmpty()) {
            dlg().setTitle("Video bulunamadı")
                    .setMessage("Bu sayfada indirilebilir bir video bulunamadı. Videoyu birkaç saniye oynatıp "
                            + "⬇ düğmesine tekrar bas.\n\nŞifreli yayın yapan sitelerdeki videolar indirilemez.")
                    .setPositiveButton("Tamam", null).show();
            return;
        }
        if (list.size() == 1) {
            chooseQuality(t, list.get(0), list);
            return;
        }
        String[] labels = new String[list.size()];
        for (int i = 0; i < list.size(); i++) {
            VideoCand c = list.get(i);
            labels[i] = "Video " + (i + 1) + " · " + (c.hls ? "akış (çoklu kalite)" : "MP4")
                    + (c.height > 0 ? " · " + c.height + "p" : "")
                    + "\n" + (c.url.length() > 70 ? c.url.substring(0, 70) + "…" : c.url);
        }
        dlg().setTitle("Hangi video?")
                .setItems(labels, (d, which) -> chooseQuality(t, list.get(which), list))
                .setNegativeButton("İptal", null).show();
    }

    /** Aynı videonun farklı kalitedeki MP4 dosyaları (adında kalite yazanlar) bir aile sayılır. */
    static String familyKey(String url) {
        String noQuery = url.split("[?#]")[0];
        return QUALITY_IN_URL.matcher(noQuery).replaceAll("Q");
    }

    void chooseQuality(final Tab t, final VideoCand c, ArrayList<VideoCand> all) {
        final String referer = t.url();
        if (!c.hls) {
            ArrayList<Variant> vars = new ArrayList<>();
            String fam = familyKey(c.url);
            for (VideoCand o : all) {
                if (o.hls || !familyKey(o.url).equals(fam)) continue;
                Variant v = new Variant();
                v.uri = o.url;
                v.height = o.height;
                vars.add(v);
            }
            showQualityDialog(t, vars, referer, false);
            return;
        }
        toast("Video kaliteleri alınıyor…");
        new Thread(() -> {
            ArrayList<Variant> vars = new ArrayList<>();
            String err = null;
            try {
                vars = parseMaster(httpText(c.url, referer), c.url);
            } catch (Exception e) {
                err = "Video bilgisi alınamadı";
            }
            final ArrayList<Variant> fv = vars;
            final String fe = err;
            ui.post(() -> {
                if (fe != null || fv.isEmpty()) toast(fe != null ? fe : "Video bilgisi alınamadı");
                else showQualityDialog(t, fv, referer, true);
            });
        }).start();
    }

    void showQualityDialog(final Tab t, ArrayList<Variant> vars, final String referer, final boolean hls) {
        // Her kalite basamağı için en yüksek bit hızlı seçenek
        final HashMap<Integer, Variant> byCat = new HashMap<>();
        for (Variant v : vars) {
            int c = category(v.height);
            Variant old = byCat.get(c);
            if (old == null || v.bw > old.bw) byCat.put(c, v);
        }
        final ArrayList<Integer> rows = new ArrayList<>();
        for (int c : new int[]{720, 1080, 1440, 2160}) rows.add(c);
        ArrayList<Integer> extra = new ArrayList<>();
        for (int c : byCat.keySet()) if (!rows.contains(c)) extra.add(c);
        Collections.sort(extra, Collections.reverseOrder());
        rows.addAll(extra);
        String[] labels = new String[rows.size()];
        for (int i = 0; i < rows.size(); i++) {
            int c = rows.get(i);
            Variant v = byCat.get(c);
            labels[i] = qualityName(c) + (v == null ? "   — bu videoda yok"
                    : (v.audioUri != null ? "   ✓ (görüntü ve ses birleştirilir)" : "   ✓"));
        }
        dlg().setTitle("İndirme kalitesi")
                .setItems(labels, (d, which) -> {
                    int c = rows.get(which);
                    Variant v = byCat.get(c);
                    if (v == null) {
                        toast("Bu video " + qualityName(c) + " kalitesinde yayınlanmamış");
                        showQualityDialog(t, vars, referer, hls);
                        return;
                    }
                    if (hls) requestHls(t, v, referer, c);
                    else requestDownload(v.uri, CHROME_UA, null, "video/mp4", -1, referer, false, null,
                            videoFileName(t, c, "mp4"));
                })
                .setNegativeButton("İptal", null).show();
    }

    static HashMap<String, String> parseAttrs(String s) {
        HashMap<String, String> m = new HashMap<>();
        Matcher mm = Pattern.compile("([A-Z0-9-]+)=(\"[^\"]*\"|[^,]*)").matcher(s);
        while (mm.find()) {
            String v = mm.group(2);
            if (v.startsWith("\"") && v.endsWith("\"") && v.length() >= 2) v = v.substring(1, v.length() - 1);
            m.put(mm.group(1), v);
        }
        return m;
    }

    static String resolve(String base, String rel) {
        try {
            return new URL(new URL(base), rel.trim()).toString();
        } catch (Exception e) {
            return rel;
        }
    }

    static ArrayList<Variant> parseMaster(String text, String base) {
        ArrayList<Variant> out = new ArrayList<>();
        HashMap<String, String> audio = new HashMap<>();
        String[] lines = text.split("\\r?\\n");
        for (String line : lines) {
            if (line.startsWith("#EXT-X-MEDIA:")) {
                HashMap<String, String> a = parseAttrs(line.substring(13));
                if ("AUDIO".equals(a.get("TYPE")) && a.get("URI") != null) {
                    String g = a.get("GROUP-ID");
                    if (!audio.containsKey(g) || "YES".equals(a.get("DEFAULT"))) audio.put(g, resolve(base, a.get("URI")));
                }
            }
        }
        for (int i = 0; i < lines.length; i++) {
            if (!lines[i].startsWith("#EXT-X-STREAM-INF:")) continue;
            HashMap<String, String> a = parseAttrs(lines[i].substring(18));
            String uri = null;
            for (int j = i + 1; j < lines.length; j++) {
                String l = lines[j].trim();
                if (l.isEmpty() || l.startsWith("#")) continue;
                uri = l;
                break;
            }
            if (uri == null) continue;
            Variant v = new Variant();
            v.uri = resolve(base, uri);
            String res = a.get("RESOLUTION");
            if (res != null && res.contains("x")) {
                try { v.height = Integer.parseInt(res.substring(res.indexOf('x') + 1).trim()); } catch (Exception ignored) { }
            }
            try { v.bw = Long.parseLong(a.containsKey("BANDWIDTH") ? a.get("BANDWIDTH") : "0"); } catch (Exception ignored) { }
            if (a.get("AUDIO") != null) v.audioUri = audio.get(a.get("AUDIO"));
            out.add(v);
        }
        if (out.isEmpty() && text.contains("#EXTINF")) {
            Variant v = new Variant();
            v.uri = base;
            v.height = heightFromUrl(base);
            out.add(v);
        }
        return out;
    }

    HttpURLConnection httpOpen(String url, String referer) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setInstanceFollowRedirects(true);
        c.setConnectTimeout(15000);
        c.setReadTimeout(30000);
        c.setRequestProperty("User-Agent", CHROME_UA);
        if (referer != null) c.setRequestProperty("Referer", referer);
        String cookie = CookieManager.getInstance().getCookie(url);
        if (cookie != null) c.setRequestProperty("Cookie", cookie);
        return c;
    }

    String httpText(String url, String referer) throws Exception {
        HttpURLConnection c = httpOpen(url, referer);
        try (InputStream in = c.getInputStream()) {
            java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
            byte[] buf = new byte[16384];
            int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            return bo.toString("UTF-8");
        } finally {
            c.disconnect();
        }
    }

    /** Akışın parçalarını sırayla indirip tek dosyada birleştirir. Parçalar MP4 türündeyse true döner. */
    boolean fetchSegments(Task k, String url, String referer, File out, int pFrom, int pTo) throws Exception {
        String text = httpText(url, referer);
        if (text.contains("#EXT-X-STREAM-INF")) {
            ArrayList<Variant> inner = parseMaster(text, url);
            if (inner.isEmpty()) throw new Exception("!Video bilgisi alınamadı");
            url = inner.get(0).uri;
            text = httpText(url, referer);
        }
        for (String line : text.split("\\r?\\n")) {
            if (line.startsWith("#EXT-X-KEY") && !line.contains("METHOD=NONE")) {
                throw new Exception("!Bu video şifreli yayınlanıyor, indirilemez");
            }
        }
        if (!text.contains("#EXT-X-ENDLIST")) throw new Exception("!Canlı yayınlar indirilemez");
        String init = null;
        ArrayList<String> segs = new ArrayList<>();
        for (String raw : text.split("\\r?\\n")) {
            String line = raw.trim();
            if (line.startsWith("#EXT-X-MAP:")) {
                String u = parseAttrs(line.substring(11)).get("URI");
                if (u != null) init = resolve(url, u);
            } else if (!line.isEmpty() && !line.startsWith("#")) {
                segs.add(resolve(url, line));
            }
        }
        if (segs.isEmpty()) throw new Exception("!Video parçaları bulunamadı");
        byte[] buf = new byte[65536];
        try (FileOutputStream fo = new FileOutputStream(out)) {
            ArrayList<String> all = new ArrayList<>();
            if (init != null) all.add(init);
            all.addAll(segs);
            int lastP = -1;
            for (int i = 0; i < all.size(); i++) {
                while (k.pauseReq && !k.cancelReq) {
                    k.state = DL_PAUSE;
                    Thread.sleep(300);
                }
                if (k.cancelReq) throw new Exception("!iptal");
                k.state = DL_RUN;
                HttpURLConnection c = httpOpen(all.get(i), referer);
                try (InputStream in = c.getInputStream()) {
                    int n;
                    while ((n = in.read(buf)) > 0) {
                        fo.write(buf, 0, n);
                        k.done += n;
                        tickSpeed(k);
                    }
                } finally {
                    c.disconnect();
                }
                int p = pFrom + (pTo - pFrom) * (i + 1) / all.size();
                if (p != lastP) {
                    lastP = p;
                    k.pct = p;
                }
            }
        }
        return init != null;
    }

    /** Görüntü ve sesi telefonların oynatabildiği tek bir MP4 dosyasında birleştirir. */
    boolean remux(File video, File audio, File out) {
        MediaMuxer mux = null;
        ArrayList<MediaExtractor> exs = new ArrayList<>();
        ArrayList<Integer> idx = new ArrayList<>();
        boolean started = false;
        try {
            mux = new MediaMuxer(out.getAbsolutePath(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
            boolean haveV = false, haveA = false;
            File[] files = audio != null ? new File[]{video, audio} : new File[]{video};
            for (File f : files) {
                MediaExtractor probe = new MediaExtractor();
                probe.setDataSource(f.getAbsolutePath());
                for (int i = 0; i < probe.getTrackCount(); i++) {
                    MediaFormat fmt = probe.getTrackFormat(i);
                    String mime = fmt.getString(MediaFormat.KEY_MIME);
                    if (mime == null) continue;
                    boolean isV = mime.startsWith("video/");
                    boolean isA = mime.startsWith("audio/") && (audio == null || f == audio);
                    if ((isV && !haveV) || (isA && !haveA)) {
                        MediaExtractor ex = new MediaExtractor();
                        ex.setDataSource(f.getAbsolutePath());
                        ex.selectTrack(i);
                        exs.add(ex);
                        idx.add(mux.addTrack(fmt));
                        if (isV) haveV = true; else haveA = true;
                    }
                }
                probe.release();
            }
            if (!haveV) return false;
            mux.start();
            started = true;
            ByteBuffer buf = ByteBuffer.allocateDirect(8 * 1024 * 1024);
            MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
            for (int k = 0; k < exs.size(); k++) {
                MediaExtractor ex = exs.get(k);
                int mi = idx.get(k);
                while (true) {
                    buf.clear();
                    int size = ex.readSampleData(buf, 0);
                    if (size < 0) break;
                    info.offset = 0;
                    info.size = size;
                    info.presentationTimeUs = Math.max(0, ex.getSampleTime());
                    info.flags = (ex.getSampleFlags() & MediaExtractor.SAMPLE_FLAG_SYNC) != 0
                            ? MediaCodec.BUFFER_FLAG_KEY_FRAME : 0;
                    mux.writeSampleData(mi, buf, info);
                    ex.advance();
                }
            }
            mux.stop();
            started = false;
            return true;
        } catch (Exception e) {
            return false;
        } finally {
            for (MediaExtractor ex : exs) {
                try { ex.release(); } catch (Exception ignored) { }
            }
            if (mux != null) {
                try { if (started) mux.stop(); } catch (Exception ignored) { }
                try { mux.release(); } catch (Exception ignored) { }
            }
        }
    }

    static void deleteDir(File d) {
        File[] fs = d.listFiles();
        if (fs != null) for (File f : fs) {
            //noinspection ResultOfMethodCallIgnored
            f.delete();
        }
        //noinspection ResultOfMethodCallIgnored
        d.delete();
    }

    // ------------------------------------------------------------------ sonuçlar

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_DL_DIR) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) onFolderPicked(data.getData());
            return;
        }
        if (requestCode == REQ_FILE_WEB) {
            if (webFileCb == null) return;
            Uri[] out = null;
            if (resultCode == RESULT_OK && data != null) {
                if (data.getClipData() != null) {
                    int n = data.getClipData().getItemCount();
                    out = new Uri[n];
                    for (int i = 0; i < n; i++) out[i] = data.getClipData().getItemAt(i).getUri();
                } else if (data.getData() != null) {
                    out = new Uri[]{data.getData()};
                }
            }
            webFileCb.onReceiveValue(out);
            webFileCb = null;
            return;
        }
        if (requestCode == REQ_FILE) {
            FilePrompt p = pendingFile;
            GeckoResult<PromptResponse> r = pendingFileResult;
            pendingFile = null;
            pendingFileResult = null;
            if (p == null || r == null) return;
            if (resultCode != RESULT_OK || data == null) {
                r.complete(p.dismiss());
                return;
            }
            try {
                if (data.getClipData() != null && data.getClipData().getItemCount() > 0) {
                    int n = data.getClipData().getItemCount();
                    Uri[] uris = new Uri[n];
                    for (int i = 0; i < n; i++) uris[i] = data.getClipData().getItemAt(i).getUri();
                    r.complete(n == 1 && p.type != FilePrompt.Type.MULTIPLE
                            ? p.confirm(this, uris[0]) : p.confirm(this, uris));
                } else if (data.getData() != null) {
                    r.complete(p.type == FilePrompt.Type.MULTIPLE
                            ? p.confirm(this, new Uri[]{data.getData()}) : p.confirm(this, data.getData()));
                } else {
                    r.complete(p.dismiss());
                }
            } catch (Exception e) {
                r.complete(p.dismiss());
            }
        } else if (requestCode == REQ_BG && resultCode == RESULT_OK && data != null && data.getData() != null) {
            saveBackground(data.getData());
        }
    }

    // ------------------------------------------------------------------ tuşlar

    @Override
    public boolean dispatchKeyEvent(KeyEvent e) {
        if (e.getAction() == KeyEvent.ACTION_DOWN && current != null) {
            int k = e.getKeyCode();
            if (e.isCtrlPressed()) {
                switch (k) {
                    case KeyEvent.KEYCODE_T: newTab(null, true, false); return true;
                    case KeyEvent.KEYCODE_W: closeTab(current); return true;
                    case KeyEvent.KEYCODE_L:
                        address.requestFocus();
                        address.selectAll();
                        return true;
                    case KeyEvent.KEYCODE_R: reload(); return true;
                    case KeyEvent.KEYCODE_D: toggleBookmark(); return true;
                    case KeyEvent.KEYCODE_H: historyDialog(); return true;
                    case KeyEvent.KEYCODE_J: downloadsPanel(); return true;
                    case KeyEvent.KEYCODE_TAB: {
                        int i = tabs.indexOf(current), n = tabs.size();
                        selectTab(tabs.get(e.isShiftPressed() ? (i - 1 + n) % n : (i + 1) % n));
                        return true;
                    }
                    default: break;
                }
            }
            if (k == KeyEvent.KEYCODE_F5) {
                reload();
                return true;
            }
            if (e.isAltPressed() && k == KeyEvent.KEYCODE_DPAD_LEFT) {
                goBack();
                return true;
            }
            if (e.isAltPressed() && k == KeyEvent.KEYCODE_DPAD_RIGHT) {
                goForward();
                return true;
            }
        }
        return super.dispatchKeyEvent(e);
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (customView != null) {
            hideFullscreen();
            return;
        }
        if (current != null && current.fullscreen && current.session != null) {
            current.session.exitFullScreen();
            return;
        }
        if (address.hasFocus()) {
            address.clearFocus();
            hideKeyboard(address);
            updateToolbar();
            return;
        }
        if (current != null) {
            boolean back = canGoBack(current);
            if (back) {
                goBack();
                return;
            }
        }
        super.onBackPressed();
    }
}
