browser.webRequest.onBeforeRequest.addListener(function (d) {
  if (d.type === "main_frame") return {};
  try {
    var h = new URL(d.url).hostname;
    while (h) {
      if (HOSTS.has(h)) return { cancel: true };
      var i = h.indexOf(".");
      if (i < 0) break;
      h = h.slice(i + 1);
    }
  } catch (e) { }
  return {};
}, { urls: ["<all_urls>"] }, ["blocking"]);
